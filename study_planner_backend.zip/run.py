"""Application entry point for running the Study Planner Flask backend.

Usage (from project root):
    python run.py
"""

from __future__ import annotations

import os

from backend.app import create_app

env_name = os.getenv("FLASK_ENV", "development")
app = create_app(env_name)

if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=app.config.get("DEBUG", True))
