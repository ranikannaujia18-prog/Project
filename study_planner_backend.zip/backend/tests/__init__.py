"""API test suite for the Study Planner and Task Tracker Flask backend."""
