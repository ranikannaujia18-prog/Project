"""Pytest fixtures for isolated in-memory SQLite API testing."""

from __future__ import annotations

import pytest

from backend.app import create_app
from backend.app.utils.auth_decorators import clear_revoked_tokens
from backend.database.db import Base, SessionLocal, engine


@pytest.fixture()
def app():
    """Create a fresh Flask app backed by an in-memory SQLite database."""
    clear_revoked_tokens()
    flask_app = create_app("testing")
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield flask_app
    SessionLocal.remove()
    Base.metadata.drop_all(bind=engine)


@pytest.fixture()
def client(app):
    return app.test_client()


@pytest.fixture()
def auth_headers(client):
    """Register a demo student and return Authorization headers for protected routes."""
    resp = client.post(
        "/api/auth/register",
        json={
            "name": "Test Student",
            "email": "student@college.edu",
            "password": "Password123!",
        },
    )
    assert resp.status_code == 201
    token = resp.get_json()["data"]["token"]
    return {"Authorization": f"Bearer {token}"}
