"""End-to-end API tests covering all 14 REST Blueprints and health check."""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone


def test_health_check(client):
    resp = client.get("/api/health")
    assert resp.status_code == 200
    assert resp.get_json()["data"]["database"] == "connected"


def test_auth_register_login_logout(client):
    # Register
    reg = client.post(
        "/api/auth/register",
        json={"name": "Priya", "email": "priya@college.edu", "password": "StrongPass1!"},
    )
    assert reg.status_code == 201
    body = reg.get_json()["data"]
    assert "password_hash" not in body["student"]
    token = body["token"]

    # Duplicate email prevented (409)
    dup = client.post(
        "/api/auth/register",
        json={"name": "Priya 2", "email": "PRIYA@college.edu", "password": "StrongPass1!"},
    )
    assert dup.status_code == 409

    # Login
    login = client.post(
        "/api/auth/login",
        json={"email": "priya@college.edu", "password": "StrongPass1!"},
    )
    assert login.status_code == 200

    # Wrong password rejected (401)
    bad = client.post(
        "/api/auth/login",
        json={"email": "priya@college.edu", "password": "WrongPassword"},
    )
    assert bad.status_code == 401

    # Logout revokes token
    headers = {"Authorization": f"Bearer {token}"}
    assert client.post("/api/auth/logout", headers=headers).status_code == 200
    assert client.get("/api/auth/me", headers=headers).status_code == 401


def test_full_study_workflow_across_all_modules(client, auth_headers):
    now = datetime.now(timezone.utc)
    today = date.today()

    # 1. Subject CRUD
    sub_resp = client.post(
        "/api/subjects",
        headers=auth_headers,
        json={"subject_name": "Database Systems", "subject_code": "CS301", "color": "#2563EB"},
    )
    assert sub_resp.status_code == 201
    subject_id = sub_resp.get_json()["data"]["id"]

    # 2. Topic CRUD & Syllabus Coverage
    topic_resp = client.post(
        "/api/topics",
        headers=auth_headers,
        json={
            "subject_id": subject_id,
            "topic_name": "B+ Trees",
            "difficulty_level": "hard",
            "status": "in_progress",
            "confidence_level": 2,
            "completion_percentage": 40,
        },
    )
    assert topic_resp.status_code == 201
    topic_id = topic_resp.get_json()["data"]["id"]

    cov = client.get("/api/topics/coverage", headers=auth_headers)
    assert cov.status_code == 200
    assert cov.get_json()["data"]["overall_completion_percentage"] == 40.0

    # 3. Tasks (overdue + upcoming + complete/pending)
    overdue_task = client.post(
        "/api/tasks",
        headers=auth_headers,
        json={
            "subject_id": subject_id,
            "topic_id": topic_id,
            "title": "Finish B+ Tree Lab",
            "priority": "urgent",
            "due_date": (now - timedelta(days=2)).isoformat(),
            "estimated_minutes": 45,
        },
    )
    assert overdue_task.status_code == 201
    task_id = overdue_task.get_json()["data"]["id"]

    overdue_list = client.get("/api/tasks/overdue", headers=auth_headers)
    assert overdue_list.status_code == 200
    assert len(overdue_list.get_json()["data"]) == 1

    assert client.patch(f"/api/tasks/{task_id}/complete", headers=auth_headers).status_code == 200
    assert client.patch(f"/api/tasks/{task_id}/pending", headers=auth_headers).status_code == 200

    # 4. Study Sessions (start -> end + invalid duration rejected)
    start = client.post(
        "/api/study-sessions/start",
        headers=auth_headers,
        json={
            "subject_id": subject_id,
            "topic_id": topic_id,
            "task_id": task_id,
            "start_time": (now - timedelta(minutes=30)).isoformat(),
            "session_type": "pomodoro",
        },
    )
    assert start.status_code == 201
    session_id = start.get_json()["data"]["id"]

    end = client.post(
        f"/api/study-sessions/{session_id}/end",
        headers=auth_headers,
        json={"end_time": now.isoformat()},
    )
    assert end.status_code == 200
    assert end.get_json()["data"]["duration_minutes"] == 30

    invalid_sess = client.post(
        "/api/study-sessions",
        headers=auth_headers,
        json={
            "subject_id": subject_id,
            "topic_id": topic_id,
            "start_time": now.isoformat(),
            "end_time": (now - timedelta(minutes=10)).isoformat(),
        },
    )
    assert invalid_sess.status_code == 400

    # 5. Revisions (auto-schedule + today + complete)
    auto_rev = client.post(
        "/api/revisions/auto-schedule",
        headers=auth_headers,
        json={"topic_id": topic_id, "intervals": [1, 3, 7], "save": True},
    )
    assert auto_rev.status_code == 201
    assert len(auto_rev.get_json()["data"]["revisions"]) == 3

    # 6. Exams (create + score + upcoming)
    exam_resp = client.post(
        "/api/exams",
        headers=auth_headers,
        json={
            "subject_id": subject_id,
            "exam_name": "DBMS Midterm",
            "exam_date": (now + timedelta(days=5)).isoformat(),
            "total_marks": 100,
        },
    )
    assert exam_resp.status_code == 201
    exam_id = exam_resp.get_json()["data"]["id"]
    score_resp = client.patch(
        f"/api/exams/{exam_id}/score",
        headers=auth_headers,
        json={"obtained_marks": 62},
    )
    assert score_resp.status_code == 200
    assert score_resp.get_json()["data"]["percentage"] == 62.0

    # 7. Notes & Resources
    note_resp = client.post(
        "/api/notes",
        headers=auth_headers,
        json={
            "subject_id": subject_id,
            "topic_id": topic_id,
            "title": "B+ Tree Splitting Rules",
            "content": "Split leaf nodes when keys exceed order-1.",
            "resource_url": "https://www.postgresql.org/docs/",
        },
    )
    assert note_resp.status_code == 201

    # 8. Daily Goals & Settings
    goal_resp = client.post(
        "/api/goals",
        headers=auth_headers,
        json={"goal_date": today.isoformat(), "target_minutes": 120, "target_tasks": 3},
    )
    assert goal_resp.status_code == 201
    assert client.get("/api/goals/today", headers=auth_headers).status_code == 200

    # 9. Dashboard, Weak Topics, Backlog Planner, Analytics, Recommendations
    dash = client.get("/api/dashboard", headers=auth_headers)
    assert dash.status_code == 200
    assert dash.get_json()["data"]["total_subjects"] == 1

    weak = client.get("/api/weak-topics", headers=auth_headers)
    assert weak.status_code == 200
    assert len(weak.get_json()["data"]["weak_topics"]) == 1

    backlog = client.get("/api/backlog/recovery-plan?daily_minutes=90&days=5", headers=auth_headers)
    assert backlog.status_code == 200
    assert backlog.get_json()["data"]["modifies_existing_tasks"] is False
    assert backlog.get_json()["data"]["summary"]["overdue_tasks"] == 1

    analytics = client.get("/api/analytics", headers=auth_headers)
    assert analytics.status_code == 200
    assert analytics.get_json()["data"]["study_streaks"]["current_streak_days"] >= 1

    recs = client.get("/api/recommendations", headers=auth_headers)
    assert recs.status_code == 200
    assert recs.get_json()["data"]["next_topic_to_study"]["topic_id"] == topic_id
