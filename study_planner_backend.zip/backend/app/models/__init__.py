"""Re-exports the SQLAlchemy ORM models from backend.database.models.

Keeping a single source of truth in backend/database/models.py prevents schema
drift between CLI scripts (init_db.py, seed.py) and Flask routes/services.
"""

from backend.database.models import (
    DailyGoal,
    Exam,
    Note,
    RevisionSchedule,
    Student,
    StudySession,
    Subject,
    Task,
    Topic,
    UserSetting,
    VALID_DIFFICULTIES,
    VALID_REVISION_STATUSES,
    VALID_SESSION_TYPES,
    VALID_TASK_PRIORITIES,
    VALID_TASK_STATUSES,
    VALID_THEMES,
    VALID_TOPIC_STATUSES,
    utc_now,
)

__all__ = [
    "Student",
    "Subject",
    "Topic",
    "Task",
    "StudySession",
    "Exam",
    "RevisionSchedule",
    "DailyGoal",
    "Note",
    "UserSetting",
    "VALID_DIFFICULTIES",
    "VALID_REVISION_STATUSES",
    "VALID_SESSION_TYPES",
    "VALID_TASK_PRIORITIES",
    "VALID_TASK_STATUSES",
    "VALID_THEMES",
    "VALID_TOPIC_STATUSES",
    "utc_now",
]
