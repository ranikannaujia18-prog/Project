"""Consistent JSON response helpers for all Flask blueprints."""

from __future__ import annotations

from typing import Any

from flask import jsonify


def success_response(
    data: Any = None,
    message: str = "Success",
    status_code: int = 200,
):
    """Return a uniform JSON envelope for successful API responses."""
    payload: dict[str, Any] = {
        "status": "success",
        "message": message,
        "data": data,
    }
    return jsonify(payload), status_code
