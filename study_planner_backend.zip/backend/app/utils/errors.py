"""Custom API exception hierarchy and global Flask JSON error handlers."""

from __future__ import annotations

from flask import jsonify
from sqlalchemy.exc import IntegrityError
from werkzeug.exceptions import HTTPException


class APIError(Exception):
    """Base application exception that maps cleanly to an HTTP JSON response."""

    status_code: int = 400

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        details: dict | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        if status_code is not None:
            self.status_code = status_code
        self.details = details


class ValidationError(APIError):
    status_code = 400


class UnauthorizedError(APIError):
    status_code = 401


class ForbiddenError(APIError):
    status_code = 403


class NotFoundError(APIError):
    status_code = 404


class ConflictError(APIError):
    status_code = 409


def register_error_handlers(app) -> None:
    """Register JSON error handlers on the Flask application."""

    @app.errorhandler(APIError)
    def handle_api_error(err: APIError):
        payload: dict[str, object] = {"status": "error", "message": err.message}
        if err.details:
            payload["details"] = err.details
        return jsonify(payload), err.status_code

    @app.errorhandler(ValueError)
    def handle_value_error(err: ValueError):
        return jsonify({"status": "error", "message": str(err)}), 400

    @app.errorhandler(IntegrityError)
    def handle_integrity_error(_err: IntegrityError):
        return (
            jsonify(
                {
                    "status": "error",
                    "message": "Database constraint violation (duplicate or invalid reference).",
                }
            ),
            409,
        )

    @app.errorhandler(HTTPException)
    def handle_http_exception(err: HTTPException):
        return (
            jsonify(
                {
                    "status": "error",
                    "message": err.description or err.name,
                }
            ),
            err.code or 500,
        )

    @app.errorhandler(Exception)
    def handle_unexpected_error(err: Exception):
        app.logger.exception("Unhandled server error: %s", err)
        return (
            jsonify(
                {
                    "status": "error",
                    "message": "An unexpected internal server error occurred.",
                }
            ),
            500,
        )
