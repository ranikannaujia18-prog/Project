"""Shared utility modules for responses, validation, errors, serialization, and auth."""
