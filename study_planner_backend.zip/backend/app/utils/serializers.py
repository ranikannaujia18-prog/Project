"""Model-to-dict serializers.

Centralizing serialization guarantees consistent JSON payloads and ensures
sensitive fields like Student.password_hash are NEVER included in responses.
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

from backend.app.models import (
    DailyGoal,
    Exam,
    Note,
    RevisionSchedule,
    Student,
    StudySession,
    Subject,
    Task,
    Topic,
    UserSetting,
    utc_now,
)
from backend.app.utils.validators import ensure_utc


def _iso(value: datetime | date | None) -> str | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return ensure_utc(value).isoformat()
    return value.isoformat()


def serialize_student(student: Student) -> dict[str, Any]:
    """Serialize a Student without ever exposing password_hash."""
    return {
        "id": student.id,
        "name": student.name,
        "email": student.email,
        "created_at": _iso(student.created_at),
    }


def serialize_settings(settings: UserSetting) -> dict[str, Any]:
    return {
        "id": settings.id,
        "student_id": settings.student_id,
        "daily_study_target": settings.daily_study_target,
        "pomodoro_duration": settings.pomodoro_duration,
        "break_duration": settings.break_duration,
        "theme": settings.theme,
    }


def serialize_subject(subject: Subject) -> dict[str, Any]:
    return {
        "id": subject.id,
        "student_id": subject.student_id,
        "subject_name": subject.subject_name,
        "subject_code": subject.subject_code,
        "color": subject.color,
        "description": subject.description,
    }


def serialize_topic(topic: Topic) -> dict[str, Any]:
    return {
        "id": topic.id,
        "subject_id": topic.subject_id,
        "topic_name": topic.topic_name,
        "difficulty_level": topic.difficulty_level,
        "status": topic.status,
        "confidence_level": topic.confidence_level,
        "completion_percentage": topic.completion_percentage,
        "last_revised_at": _iso(topic.last_revised_at),
        "notes": topic.notes,
    }


def serialize_task(task: Task) -> dict[str, Any]:
    now = utc_now()
    due = ensure_utc(task.due_date)
    is_overdue = bool(
        due is not None and due < now and task.status not in ("completed", "cancelled")
    )
    return {
        "id": task.id,
        "student_id": task.student_id,
        "subject_id": task.subject_id,
        "topic_id": task.topic_id,
        "title": task.title,
        "description": task.description,
        "priority": task.priority,
        "status": task.status,
        "due_date": _iso(task.due_date),
        "is_overdue": is_overdue,
        "estimated_minutes": task.estimated_minutes,
        "actual_minutes": task.actual_minutes,
        "created_at": _iso(task.created_at),
        "completed_at": _iso(task.completed_at),
    }


def serialize_study_session(session: StudySession) -> dict[str, Any]:
    return {
        "id": session.id,
        "student_id": session.student_id,
        "subject_id": session.subject_id,
        "topic_id": session.topic_id,
        "task_id": session.task_id,
        "start_time": _iso(session.start_time),
        "end_time": _iso(session.end_time),
        "duration_minutes": session.duration_minutes,
        "session_type": session.session_type,
        "notes": session.notes,
        "is_active": session.end_time is None,
    }


def serialize_exam(exam: Exam) -> dict[str, Any]:
    now = utc_now()
    exam_dt = ensure_utc(exam.exam_date)
    days_remaining = (exam_dt.date() - now.date()).days if exam_dt else None
    return {
        "id": exam.id,
        "student_id": exam.student_id,
        "subject_id": exam.subject_id,
        "exam_name": exam.exam_name,
        "exam_date": _iso(exam.exam_date),
        "days_remaining": days_remaining,
        "total_marks": exam.total_marks,
        "obtained_marks": exam.obtained_marks,
        "percentage": exam.percentage,
    }


def serialize_revision(rev: RevisionSchedule) -> dict[str, Any]:
    today = date.today()
    is_overdue = rev.scheduled_date < today and rev.status == "scheduled"
    return {
        "id": rev.id,
        "student_id": rev.student_id,
        "topic_id": rev.topic_id,
        "scheduled_date": _iso(rev.scheduled_date),
        "revision_number": rev.revision_number,
        "status": rev.status,
        "is_overdue": is_overdue,
        "notes": rev.notes,
    }


def serialize_daily_goal(goal: DailyGoal) -> dict[str, Any]:
    time_pct = (
        round((goal.completed_minutes / goal.target_minutes) * 100, 1)
        if goal.target_minutes > 0
        else 100.0
    )
    task_pct = (
        round((goal.completed_tasks / goal.target_tasks) * 100, 1)
        if goal.target_tasks > 0
        else 100.0
    )
    overall_pct = round(min(100.0, (min(time_pct, 100.0) + min(task_pct, 100.0)) / 2), 1)
    return {
        "id": goal.id,
        "student_id": goal.student_id,
        "goal_date": _iso(goal.goal_date),
        "target_minutes": goal.target_minutes,
        "completed_minutes": goal.completed_minutes,
        "target_tasks": goal.target_tasks,
        "completed_tasks": goal.completed_tasks,
        "time_completion_percentage": min(time_pct, 100.0),
        "task_completion_percentage": min(task_pct, 100.0),
        "overall_completion_percentage": overall_pct,
    }


def serialize_note(note: Note) -> dict[str, Any]:
    return {
        "id": note.id,
        "student_id": note.student_id,
        "subject_id": note.subject_id,
        "topic_id": note.topic_id,
        "title": note.title,
        "content": note.content,
        "resource_url": note.resource_url,
        "created_at": _iso(note.created_at),
        "updated_at": _iso(note.updated_at),
    }
