"""Signed Bearer token authentication using Flask's built-in itsdangerous library.

Why this approach for a college REST API?
- Zero extra third-party JWT libraries needed (itsdangerous ships with Flask).
- Works cleanly with Postman, curl, and any frontend via Authorization: Bearer <token>.
- Tokens are cryptographically signed with SECRET_KEY, expire automatically, and
  can be invalidated on logout via an in-memory blocklist.
"""

from __future__ import annotations

from functools import wraps
from typing import Callable

from flask import current_app, g, request
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

from backend.app.models import Student
from backend.app.utils.errors import UnauthorizedError
from backend.database.db import SessionLocal

TOKEN_SALT = "study-planner-auth-token"

# Stores logged-out tokens in memory (reset on restart; swap for Redis/DB in production)
_REVOKED_TOKENS: set[str] = set()


def _get_serializer() -> URLSafeTimedSerializer:
    return URLSafeTimedSerializer(current_app.config["SECRET_KEY"])


def generate_auth_token(student_id: int) -> str:
    """Create a signed, time-limited authentication token for a student."""
    serializer = _get_serializer()
    return serializer.dumps({"student_id": student_id}, salt=TOKEN_SALT)


def revoke_auth_token(token: str) -> None:
    """Invalidate a token when the student logs out."""
    _REVOKED_TOKENS.add(token)


def clear_revoked_tokens() -> None:
    """Clear revoked tokens (helper for isolated unit tests)."""
    _REVOKED_TOKENS.clear()


def extract_bearer_token() -> str:
    """Read the Bearer token from the Authorization header."""
    auth_header = request.headers.get("Authorization", "").strip()
    if not auth_header.startswith("Bearer "):
        raise UnauthorizedError("Missing or invalid Authorization header. Expected 'Bearer <token>'.")
    token = auth_header[len("Bearer "):].strip()
    if not token:
        raise UnauthorizedError("Authentication token is empty.")
    return token


def verify_auth_token(token: str) -> int:
    """Verify signature, expiration, and revocation status; return student_id."""
    if token in _REVOKED_TOKENS:
        raise UnauthorizedError("Token has been logged out. Please log in again.")

    max_age = current_app.config.get("AUTH_TOKEN_MAX_AGE", 7 * 24 * 3600)
    serializer = _get_serializer()
    try:
        payload = serializer.loads(token, salt=TOKEN_SALT, max_age=max_age)
    except SignatureExpired as exc:
        raise UnauthorizedError("Session expired. Please log in again.") from exc
    except BadSignature as exc:
        raise UnauthorizedError("Invalid authentication token.") from exc

    student_id = payload.get("student_id")
    if not isinstance(student_id, int):
        raise UnauthorizedError("Malformed authentication token.")
    return student_id


def login_required(view_func: Callable) -> Callable:
    """Decorator that protects a route and attaches g.current_student & g.auth_token."""

    @wraps(view_func)
    def wrapped(*args, **kwargs):
        token = extract_bearer_token()
        student_id = verify_auth_token(token)

        student = SessionLocal.get(Student, student_id)
        if student is None:
            raise UnauthorizedError("Authenticated student account no longer exists.")

        g.current_student = student
        g.auth_token = token
        return view_func(*args, **kwargs)

    return wrapped
