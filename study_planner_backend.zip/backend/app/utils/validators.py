"""Input parsing and validation helpers used across services and routes."""

from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Any

from flask import request

from backend.app.utils.errors import ValidationError


def get_json_body(required_fields: list[str] | None = None) -> dict[str, Any]:
    """Parse JSON request body and verify any required fields are present."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise ValidationError("Request body must be a valid JSON object.")

    if required_fields:
        missing = [
            f for f in required_fields if f not in data or data[f] is None or data[f] == ""
        ]
        if missing:
            raise ValidationError(
                f"Missing required field(s): {', '.join(missing)}",
                details={"missing_fields": missing},
            )
    return data


def parse_iso_datetime(value: Any, field_name: str = "datetime") -> datetime | None:
    """Parse an ISO-8601 datetime string (e.g., '2026-11-30T14:00:00Z') to UTC datetime."""
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if not isinstance(value, str):
        raise ValidationError(f"'{field_name}' must be an ISO-8601 datetime string.")

    raw = value.strip()
    if raw.endswith("Z"):
        raw = raw[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(raw)
    except ValueError as exc:
        raise ValidationError(
            f"Invalid ISO-8601 format for '{field_name}': {value!r}. "
            "Example: '2026-12-01T10:30:00Z'."
        ) from exc

    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def parse_iso_date(value: Any, field_name: str = "date") -> date | None:
    """Parse a 'YYYY-MM-DD' date string into a Python date object."""
    if value is None or value == "":
        return None
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if not isinstance(value, str):
        raise ValidationError(f"'{field_name}' must be a 'YYYY-MM-DD' date string.")
    try:
        return date.fromisoformat(value.strip())
    except ValueError as exc:
        raise ValidationError(
            f"Invalid date format for '{field_name}': {value!r}. Expected 'YYYY-MM-DD'."
        ) from exc


def parse_positive_int(
    value: Any,
    field_name: str,
    allow_zero: bool = False,
    allow_none: bool = False,
) -> int | None:
    """Validate and convert an integer field with optional zero/None allowance."""
    if value is None:
        if allow_none:
            return None
        raise ValidationError(f"'{field_name}' is required.")
    if isinstance(value, bool):
        raise ValidationError(f"'{field_name}' must be an integer.")
    try:
        num = int(value)
    except (TypeError, ValueError) as exc:
        raise ValidationError(f"'{field_name}' must be an integer.") from exc

    if allow_zero and num < 0:
        raise ValidationError(f"'{field_name}' must be >= 0.")
    if not allow_zero and num <= 0:
        raise ValidationError(f"'{field_name}' must be > 0.")
    return num


def parse_float(
    value: Any,
    field_name: str,
    min_value: float | None = None,
    max_value: float | None = None,
    allow_none: bool = False,
) -> float | None:
    """Validate and convert a float field with optional range bounds."""
    if value is None:
        if allow_none:
            return None
        raise ValidationError(f"'{field_name}' is required.")
    if isinstance(value, bool):
        raise ValidationError(f"'{field_name}' must be a number.")
    try:
        num = float(value)
    except (TypeError, ValueError) as exc:
        raise ValidationError(f"'{field_name}' must be a number.") from exc

    if min_value is not None and num < min_value:
        raise ValidationError(f"'{field_name}' must be >= {min_value}.")
    if max_value is not None and num > max_value:
        raise ValidationError(f"'{field_name}' must be <= {max_value}.")
    return num


def ensure_utc(dt: datetime | None) -> datetime | None:
    """Normalize naive datetimes returned by SQLite back to timezone-aware UTC."""
    if dt is None:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
