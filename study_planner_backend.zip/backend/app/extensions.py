"""Flask extension instances (initialized inside create_app)."""

from __future__ import annotations

from flask_cors import CORS

cors = CORS()
