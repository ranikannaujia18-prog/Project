"""Dashboard summary REST API routes (/api/dashboard)."""

from __future__ import annotations

from flask import Blueprint, g

from backend.app.services import dashboard_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response

dashboard_bp = Blueprint("dashboard", __name__, url_prefix="/api/dashboard")


@dashboard_bp.get("")
@login_required
def get_dashboard():
    result = dashboard_service.get_dashboard_summary(g.current_student.id)
    return success_response(result, message="Dashboard summary retrieved.")
