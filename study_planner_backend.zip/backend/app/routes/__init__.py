"""Central Blueprint registry for all 14 REST API modules."""

from __future__ import annotations

from backend.app.routes.analytics_routes import analytics_bp
from backend.app.routes.auth_routes import auth_bp
from backend.app.routes.backlog_routes import backlog_bp
from backend.app.routes.dashboard_routes import dashboard_bp
from backend.app.routes.exam_routes import exam_bp
from backend.app.routes.goal_routes import goal_bp
from backend.app.routes.note_routes import note_bp
from backend.app.routes.recommendation_routes import recommendation_bp
from backend.app.routes.revision_routes import revision_bp
from backend.app.routes.study_session_routes import study_session_bp
from backend.app.routes.subject_routes import subject_bp
from backend.app.routes.task_routes import task_bp
from backend.app.routes.topic_routes import topic_bp
from backend.app.routes.weak_topic_routes import weak_topic_bp

ALL_BLUEPRINTS = [
    auth_bp,
    dashboard_bp,
    subject_bp,
    topic_bp,
    task_bp,
    study_session_bp,
    revision_bp,
    exam_bp,
    note_bp,
    goal_bp,
    analytics_bp,
    weak_topic_bp,
    backlog_bp,
    recommendation_bp,
]


def register_blueprints(app) -> None:
    """Attach all API Blueprints to the Flask app instance."""
    for bp in ALL_BLUEPRINTS:
        app.register_blueprint(bp)
