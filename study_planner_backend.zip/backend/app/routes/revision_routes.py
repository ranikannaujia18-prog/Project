"""Revision Scheduler REST API routes (/api/revisions)."""

from __future__ import annotations

from flask import Blueprint, g, request

from backend.app.services import revision_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response
from backend.app.utils.validators import get_json_body, parse_positive_int

revision_bp = Blueprint("revisions", __name__, url_prefix="/api/revisions")


@revision_bp.post("")
@login_required
def create_revision():
    body = get_json_body(required_fields=["topic_id", "scheduled_date"])
    result = revision_service.create_revision(g.current_student.id, body)
    return success_response(result, message="Revision scheduled.", status_code=201)


@revision_bp.post("/auto-schedule")
@login_required
def auto_schedule():
    body = get_json_body(required_fields=["topic_id"])
    result = revision_service.auto_schedule_revisions(g.current_student.id, body)
    status_code = 201 if result.get("saved") else 200
    return success_response(
        result, message="Revision schedule generated.", status_code=status_code
    )


@revision_bp.get("")
@login_required
def list_revisions():
    topic_id = request.args.get("topic_id")
    result = revision_service.list_revisions(
        g.current_student.id,
        topic_id=parse_positive_int(topic_id, "topic_id") if topic_id else None,
        status=request.args.get("status"),
    )
    return success_response(result, message="Revisions retrieved.")


@revision_bp.get("/today")
@login_required
def today_revisions():
    result = revision_service.list_revisions(g.current_student.id, only_today=True)
    return success_response(result, message="Today's revisions retrieved.")


@revision_bp.get("/overdue")
@login_required
def overdue_revisions():
    result = revision_service.list_revisions(g.current_student.id, only_overdue=True)
    return success_response(result, message="Overdue revisions retrieved.")


@revision_bp.put("/<int:revision_id>")
@login_required
def update_revision(revision_id: int):
    body = get_json_body()
    result = revision_service.update_revision(g.current_student.id, revision_id, body)
    return success_response(result, message="Revision updated.")


@revision_bp.patch("/<int:revision_id>/complete")
@login_required
def complete_revision(revision_id: int):
    body = request.get_json(silent=True) or {}
    result = revision_service.complete_revision(
        g.current_student.id, revision_id, notes=body.get("notes")
    )
    return success_response(result, message="Revision marked as completed.")


@revision_bp.delete("/<int:revision_id>")
@login_required
def delete_revision(revision_id: int):
    result = revision_service.delete_revision(g.current_student.id, revision_id)
    return success_response(result, message="Revision deleted.")
