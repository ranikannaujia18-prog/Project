"""Syllabus coverage & topic REST API routes (/api/topics)."""

from __future__ import annotations

from flask import Blueprint, g, request

from backend.app.services import topic_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response
from backend.app.utils.validators import get_json_body, parse_positive_int

topic_bp = Blueprint("topics", __name__, url_prefix="/api/topics")


@topic_bp.post("")
@login_required
def create_topic():
    body = get_json_body(required_fields=["subject_id", "topic_name"])
    result = topic_service.create_topic(g.current_student.id, body)
    return success_response(result, message="Topic created.", status_code=201)


@topic_bp.get("")
@login_required
def list_topics():
    subject_id = request.args.get("subject_id")
    parsed_sub = parse_positive_int(subject_id, "subject_id") if subject_id else None
    result = topic_service.list_topics(
        g.current_student.id,
        subject_id=parsed_sub,
        status=request.args.get("status"),
        difficulty_level=request.args.get("difficulty_level"),
    )
    return success_response(result, message="Topics retrieved.")


@topic_bp.get("/coverage")
@login_required
def syllabus_coverage():
    subject_id = request.args.get("subject_id")
    parsed_sub = parse_positive_int(subject_id, "subject_id") if subject_id else None
    result = topic_service.get_syllabus_coverage(
        g.current_student.id, subject_id=parsed_sub
    )
    return success_response(result, message="Syllabus coverage report generated.")


@topic_bp.get("/<int:topic_id>")
@login_required
def get_topic(topic_id: int):
    result = topic_service.get_topic_detail(g.current_student.id, topic_id)
    return success_response(result, message="Topic retrieved.")


@topic_bp.put("/<int:topic_id>")
@login_required
def update_topic(topic_id: int):
    body = get_json_body()
    result = topic_service.update_topic(g.current_student.id, topic_id, body)
    return success_response(result, message="Topic updated.")


@topic_bp.delete("/<int:topic_id>")
@login_required
def delete_topic(topic_id: int):
    result = topic_service.delete_topic(g.current_student.id, topic_id)
    return success_response(result, message="Topic deleted.")
