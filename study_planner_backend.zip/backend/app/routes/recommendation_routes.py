"""Study Recommendations REST API routes (/api/recommendations)."""

from __future__ import annotations

from flask import Blueprint, g

from backend.app.services import recommendation_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response

recommendation_bp = Blueprint(
    "recommendations", __name__, url_prefix="/api/recommendations"
)


@recommendation_bp.get("")
@login_required
def get_recommendations():
    result = recommendation_service.get_study_recommendations(g.current_student.id)
    return success_response(result, message="Study recommendations generated.")
