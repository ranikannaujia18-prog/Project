"""Daily Goals & Study Settings REST API routes (/api/goals)."""

from __future__ import annotations

from flask import Blueprint, g, request

from backend.app.services import goal_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response
from backend.app.utils.validators import get_json_body, parse_positive_int

goal_bp = Blueprint("goals", __name__, url_prefix="/api/goals")


@goal_bp.post("")
@login_required
def set_goal():
    body = get_json_body()
    result = goal_service.set_daily_goal(g.current_student.id, body)
    return success_response(result, message="Daily goal saved.", status_code=201)


@goal_bp.get("/today")
@login_required
def today_goal():
    result = goal_service.get_today_goal(g.current_student.id)
    return success_response(result, message="Today's goal retrieved.")


@goal_bp.get("")
@login_required
def list_goals():
    limit_param = request.args.get("limit")
    limit = parse_positive_int(limit_param, "limit") if limit_param else 30
    result = goal_service.list_daily_goals(g.current_student.id, limit=limit)
    return success_response(result, message="Daily goals retrieved.")


@goal_bp.put("/<int:goal_id>")
@login_required
def update_goal(goal_id: int):
    body = get_json_body()
    result = goal_service.update_daily_goal(g.current_student.id, goal_id, body)
    return success_response(result, message="Daily goal updated.")


@goal_bp.put("/settings")
@login_required
def update_settings():
    body = get_json_body()
    result = goal_service.update_user_settings(g.current_student.id, body)
    return success_response(result, message="User study settings updated.")
