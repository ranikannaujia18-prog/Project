"""Study Session Tracker REST API routes (/api/study-sessions)."""

from __future__ import annotations

from flask import Blueprint, g, request

from backend.app.services import study_session_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response
from backend.app.utils.validators import get_json_body, parse_positive_int

study_session_bp = Blueprint(
    "study_sessions", __name__, url_prefix="/api/study-sessions"
)


@study_session_bp.post("/start")
@login_required
def start_session():
    body = get_json_body(required_fields=["subject_id", "topic_id"])
    result = study_session_service.start_session(g.current_student.id, body)
    return success_response(result, message="Study session started.", status_code=201)


@study_session_bp.post("/<int:session_id>/end")
@login_required
def end_session(session_id: int):
    body = request.get_json(silent=True) or {}
    result = study_session_service.end_session(g.current_student.id, session_id, body)
    return success_response(result, message="Study session ended.")


@study_session_bp.post("")
@login_required
def save_session():
    body = get_json_body(
        required_fields=["subject_id", "topic_id", "start_time", "end_time"]
    )
    result = study_session_service.create_completed_session(g.current_student.id, body)
    return success_response(result, message="Study session saved.", status_code=201)


@study_session_bp.get("")
@login_required
def list_sessions():
    subject_id = request.args.get("subject_id")
    topic_id = request.args.get("topic_id")
    result = study_session_service.list_sessions(
        g.current_student.id,
        subject_id=parse_positive_int(subject_id, "subject_id") if subject_id else None,
        topic_id=parse_positive_int(topic_id, "topic_id") if topic_id else None,
        session_type=request.args.get("session_type"),
        date_str=request.args.get("date"),
    )
    return success_response(result, message="Study sessions retrieved.")


@study_session_bp.get("/active")
@login_required
def active_session():
    result = study_session_service.get_active_session(g.current_student.id)
    return success_response(result, message="Active session status retrieved.")


@study_session_bp.get("/summary")
@login_required
def session_summary():
    result = study_session_service.get_session_summary(g.current_student.id)
    return success_response(result, message="Study time summary retrieved.")
