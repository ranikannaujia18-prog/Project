"""Notes & Resources REST API routes (/api/notes)."""

from __future__ import annotations

from flask import Blueprint, g, request

from backend.app.services import note_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response
from backend.app.utils.validators import get_json_body, parse_positive_int

note_bp = Blueprint("notes", __name__, url_prefix="/api/notes")


@note_bp.post("")
@login_required
def create_note():
    body = get_json_body(required_fields=["subject_id", "topic_id", "title", "content"])
    result = note_service.create_note(g.current_student.id, body)
    return success_response(result, message="Note created.", status_code=201)


@note_bp.get("")
@login_required
def list_notes():
    subject_id = request.args.get("subject_id")
    topic_id = request.args.get("topic_id")
    result = note_service.list_notes(
        g.current_student.id,
        subject_id=parse_positive_int(subject_id, "subject_id") if subject_id else None,
        topic_id=parse_positive_int(topic_id, "topic_id") if topic_id else None,
        search=request.args.get("q"),
    )
    return success_response(result, message="Notes retrieved.")


@note_bp.get("/<int:note_id>")
@login_required
def get_note(note_id: int):
    result = note_service.get_note_detail(g.current_student.id, note_id)
    return success_response(result, message="Note retrieved.")


@note_bp.put("/<int:note_id>")
@login_required
def update_note(note_id: int):
    body = get_json_body()
    result = note_service.update_note(g.current_student.id, note_id, body)
    return success_response(result, message="Note updated.")


@note_bp.delete("/<int:note_id>")
@login_required
def delete_note(note_id: int):
    result = note_service.delete_note(g.current_student.id, note_id)
    return success_response(result, message="Note deleted.")
