"""Authentication REST API routes (/api/auth)."""

from __future__ import annotations

from flask import Blueprint, g

from backend.app.services import auth_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response
from backend.app.utils.validators import get_json_body

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")


@auth_bp.post("/register")
def register():
    body = get_json_body(required_fields=["name", "email", "password"])
    result = auth_service.register_student(
        name=body["name"],
        email=body["email"],
        password=body["password"],
    )
    return success_response(result, message="Student registered successfully.", status_code=201)


@auth_bp.post("/login")
def login():
    body = get_json_body(required_fields=["email", "password"])
    result = auth_service.login_student(
        email=body["email"],
        password=body["password"],
    )
    return success_response(result, message="Login successful.")


@auth_bp.post("/logout")
@login_required
def logout():
    result = auth_service.logout_student(g.auth_token)
    return success_response(result, message="Logged out successfully.")


@auth_bp.get("/me")
@login_required
def me():
    result = auth_service.get_current_profile(g.current_student)
    return success_response(result, message="Profile retrieved.")
