"""Productivity Analytics REST API routes (/api/analytics)."""

from __future__ import annotations

from flask import Blueprint, g

from backend.app.services import analytics_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response

analytics_bp = Blueprint("analytics", __name__, url_prefix="/api/analytics")


@analytics_bp.get("")
@login_required
def get_analytics():
    result = analytics_service.get_productivity_analytics(g.current_student.id)
    return success_response(result, message="Productivity analytics retrieved.")
