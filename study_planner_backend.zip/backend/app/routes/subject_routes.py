"""Subject management REST API routes (/api/subjects)."""

from __future__ import annotations

from flask import Blueprint, g

from backend.app.services import subject_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response
from backend.app.utils.validators import get_json_body

subject_bp = Blueprint("subjects", __name__, url_prefix="/api/subjects")


@subject_bp.post("")
@login_required
def create_subject():
    body = get_json_body(required_fields=["subject_name"])
    result = subject_service.create_subject(g.current_student.id, body)
    return success_response(result, message="Subject created.", status_code=201)


@subject_bp.get("")
@login_required
def list_subjects():
    result = subject_service.list_subjects(g.current_student.id)
    return success_response(result, message="Subjects retrieved.")


@subject_bp.get("/stats")
@login_required
def list_subject_stats():
    result = subject_service.get_all_subject_stats(g.current_student.id)
    return success_response(result, message="Subject-wise statistics retrieved.")


@subject_bp.get("/<int:subject_id>")
@login_required
def get_subject(subject_id: int):
    result = subject_service.get_subject_detail(g.current_student.id, subject_id)
    return success_response(result, message="Subject retrieved.")


@subject_bp.get("/<int:subject_id>/stats")
@login_required
def get_subject_stats(subject_id: int):
    result = subject_service.get_subject_stats(g.current_student.id, subject_id)
    return success_response(result, message="Subject statistics retrieved.")


@subject_bp.put("/<int:subject_id>")
@login_required
def update_subject(subject_id: int):
    body = get_json_body()
    result = subject_service.update_subject(g.current_student.id, subject_id, body)
    return success_response(result, message="Subject updated.")


@subject_bp.delete("/<int:subject_id>")
@login_required
def delete_subject(subject_id: int):
    result = subject_service.delete_subject(g.current_student.id, subject_id)
    return success_response(result, message="Subject deleted.")
