"""Smart Backlog Recovery Planner REST API routes (/api/backlog)."""

from __future__ import annotations

from flask import Blueprint, g, request

from backend.app.services import backlog_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response
from backend.app.utils.validators import get_json_body, parse_positive_int

backlog_bp = Blueprint("backlog", __name__, url_prefix="/api/backlog")


@backlog_bp.get("/recovery-plan")
@login_required
def get_recovery_plan():
    daily_param = request.args.get("daily_minutes")
    days_param = request.args.get("days")
    result = backlog_service.generate_backlog_recovery_plan(
        g.current_student.id,
        daily_minutes=parse_positive_int(daily_param, "daily_minutes") if daily_param else None,
        horizon_days=parse_positive_int(days_param, "days") if days_param else 7,
    )
    return success_response(result, message="Backlog recovery plan generated.")


@backlog_bp.post("/recovery-plan")
@login_required
def post_recovery_plan():
    body = get_json_body()
    result = backlog_service.generate_backlog_recovery_plan(
        g.current_student.id,
        daily_minutes=body.get("daily_minutes"),
        horizon_days=body.get("days", 7),
    )
    return success_response(result, message="Custom backlog recovery plan generated.")
