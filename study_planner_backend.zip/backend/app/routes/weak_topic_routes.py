"""Weak Topic Detector REST API routes (/api/weak-topics)."""

from __future__ import annotations

from flask import Blueprint, g, request

from backend.app.services import weak_topic_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response
from backend.app.utils.validators import get_json_body

weak_topic_bp = Blueprint("weak_topics", __name__, url_prefix="/api/weak-topics")


@weak_topic_bp.get("")
@login_required
def get_weak_topics():
    custom_weights = {}
    for key in weak_topic_service.DEFAULT_WEIGHTS:
        raw = request.args.get(f"w_{key}")
        if raw is not None:
            custom_weights[key] = raw

    result = weak_topic_service.analyze_weak_topics(
        g.current_student.id,
        custom_weights=custom_weights or None,
    )
    return success_response(result, message="Weak topic analysis completed.")


@weak_topic_bp.post("/analyze")
@login_required
def analyze_with_custom_weights():
    body = get_json_body()
    result = weak_topic_service.analyze_weak_topics(
        g.current_student.id,
        custom_weights=body.get("weights"),
        weak_threshold=float(body.get("weak_threshold", 55.0)),
        high_risk_threshold=float(body.get("high_risk_threshold", 70.0)),
    )
    return success_response(
        result, message="Custom-weighted weak topic analysis completed."
    )
