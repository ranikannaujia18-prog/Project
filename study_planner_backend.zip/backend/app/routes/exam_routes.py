"""Exam Management REST API routes (/api/exams)."""

from __future__ import annotations

from flask import Blueprint, g, request

from backend.app.services import exam_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response
from backend.app.utils.validators import get_json_body, parse_positive_int

exam_bp = Blueprint("exams", __name__, url_prefix="/api/exams")


@exam_bp.post("")
@login_required
def create_exam():
    body = get_json_body(
        required_fields=["subject_id", "exam_name", "exam_date", "total_marks"]
    )
    result = exam_service.create_exam(g.current_student.id, body)
    return success_response(result, message="Exam added.", status_code=201)


@exam_bp.get("")
@login_required
def list_exams():
    subject_id = request.args.get("subject_id")
    result = exam_service.list_exams(
        g.current_student.id,
        subject_id=parse_positive_int(subject_id, "subject_id") if subject_id else None,
        upcoming_only=request.args.get("upcoming", "").lower() == "true",
    )
    return success_response(result, message="Exams retrieved.")


@exam_bp.get("/upcoming")
@login_required
def upcoming_exams():
    result = exam_service.list_exams(g.current_student.id, upcoming_only=True)
    return success_response(result, message="Upcoming exams retrieved.")


@exam_bp.get("/<int:exam_id>")
@login_required
def get_exam(exam_id: int):
    result = exam_service.get_exam_detail(g.current_student.id, exam_id)
    return success_response(result, message="Exam retrieved.")


@exam_bp.put("/<int:exam_id>")
@login_required
def update_exam(exam_id: int):
    body = get_json_body()
    result = exam_service.update_exam(g.current_student.id, exam_id, body)
    return success_response(result, message="Exam updated.")


@exam_bp.patch("/<int:exam_id>/score")
@login_required
def save_score(exam_id: int):
    body = get_json_body(required_fields=["obtained_marks"])
    result = exam_service.save_exam_score(
        g.current_student.id, exam_id, body["obtained_marks"]
    )
    return success_response(result, message="Exam score saved.")


@exam_bp.delete("/<int:exam_id>")
@login_required
def delete_exam(exam_id: int):
    result = exam_service.delete_exam(g.current_student.id, exam_id)
    return success_response(result, message="Exam deleted.")
