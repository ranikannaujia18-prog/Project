"""Task management REST API routes (/api/tasks)."""

from __future__ import annotations

from flask import Blueprint, g, request

from backend.app.services import task_service
from backend.app.utils.auth_decorators import login_required
from backend.app.utils.responses import success_response
from backend.app.utils.validators import get_json_body, parse_positive_int

task_bp = Blueprint("tasks", __name__, url_prefix="/api/tasks")


@task_bp.post("")
@login_required
def create_task():
    body = get_json_body(required_fields=["subject_id", "title"])
    result = task_service.create_task(g.current_student.id, body)
    return success_response(result, message="Task created.", status_code=201)


@task_bp.get("")
@login_required
def list_tasks():
    subject_id = request.args.get("subject_id")
    topic_id = request.args.get("topic_id")
    result = task_service.list_tasks(
        g.current_student.id,
        subject_id=parse_positive_int(subject_id, "subject_id") if subject_id else None,
        topic_id=parse_positive_int(topic_id, "topic_id") if topic_id else None,
        status=request.args.get("status"),
        priority=request.args.get("priority"),
        due_date_str=request.args.get("date"),
        overdue_only=request.args.get("overdue", "").lower() == "true",
        sort_by_priority=request.args.get("sort", "").lower() == "priority",
    )
    return success_response(result, message="Tasks retrieved.")


@task_bp.get("/overdue")
@login_required
def list_overdue_tasks():
    result = task_service.list_tasks(
        g.current_student.id, overdue_only=True, sort_by_priority=True
    )
    return success_response(result, message="Overdue tasks retrieved.")


@task_bp.get("/<int:task_id>")
@login_required
def get_task(task_id: int):
    result = task_service.get_task_detail(g.current_student.id, task_id)
    return success_response(result, message="Task retrieved.")


@task_bp.put("/<int:task_id>")
@login_required
def update_task(task_id: int):
    body = get_json_body()
    result = task_service.update_task(g.current_student.id, task_id, body)
    return success_response(result, message="Task updated.")


@task_bp.patch("/<int:task_id>/complete")
@login_required
def complete_task(task_id: int):
    body = request.get_json(silent=True) or {}
    result = task_service.mark_task_completed(
        g.current_student.id, task_id, actual_minutes=body.get("actual_minutes")
    )
    return success_response(result, message="Task marked as completed.")


@task_bp.patch("/<int:task_id>/pending")
@login_required
def reopen_task(task_id: int):
    result = task_service.mark_task_pending(g.current_student.id, task_id)
    return success_response(result, message="Task marked as pending.")


@task_bp.delete("/<int:task_id>")
@login_required
def delete_task(task_id: int):
    result = task_service.delete_task(g.current_student.id, task_id)
    return success_response(result, message="Task deleted.")
