"""Subject management and subject-wise statistics service."""

from __future__ import annotations

from backend.app.models import Exam, StudySession, Subject, Task, Topic
from backend.app.utils.errors import ConflictError, NotFoundError, ValidationError
from backend.app.utils.serializers import serialize_subject
from backend.database.db import SessionLocal


def get_student_subject(student_id: int, subject_id: int) -> Subject:
    """Fetch a subject owned by the student or raise 404."""
    subject = (
        SessionLocal.query(Subject)
        .filter_by(id=subject_id, student_id=student_id)
        .first()
    )
    if not subject:
        raise NotFoundError(f"Subject with id={subject_id} not found.")
    return subject


def create_subject(student_id: int, data: dict) -> dict:
    name = (data.get("subject_name") or "").strip()
    if not name:
        raise ValidationError("'subject_name' cannot be empty.")

    code = data.get("subject_code")
    cleaned_code = code.strip().upper() if isinstance(code, str) and code.strip() else None

    if SessionLocal.query(Subject).filter_by(student_id=student_id, subject_name=name).first():
        raise ConflictError(f"Subject '{name}' already exists.")
    if cleaned_code and SessionLocal.query(Subject).filter_by(
        student_id=student_id, subject_code=cleaned_code
    ).first():
        raise ConflictError(f"Subject code '{cleaned_code}' already exists.")

    subject = Subject(
        student_id=student_id,
        subject_name=name,
        subject_code=cleaned_code,
        color=data.get("color") or "#4A90E2",
        description=data.get("description"),
    )
    SessionLocal.add(subject)
    SessionLocal.commit()
    return serialize_subject(subject)


def list_subjects(student_id: int) -> list[dict]:
    subjects = (
        SessionLocal.query(Subject)
        .filter_by(student_id=student_id)
        .order_by(Subject.subject_name.asc())
        .all()
    )
    return [serialize_subject(s) for s in subjects]


def get_subject_detail(student_id: int, subject_id: int) -> dict:
    subject = get_student_subject(student_id, subject_id)
    return serialize_subject(subject)


def update_subject(student_id: int, subject_id: int, data: dict) -> dict:
    subject = get_student_subject(student_id, subject_id)

    if "subject_name" in data and data["subject_name"] is not None:
        new_name = str(data["subject_name"]).strip()
        if not new_name:
            raise ValidationError("'subject_name' cannot be empty.")
        conflict = (
            SessionLocal.query(Subject)
            .filter(
                Subject.student_id == student_id,
                Subject.subject_name == new_name,
                Subject.id != subject_id,
            )
            .first()
        )
        if conflict:
            raise ConflictError(f"Subject '{new_name}' already exists.")
        subject.subject_name = new_name

    if "subject_code" in data:
        new_code = data["subject_code"]
        cleaned_code = (
            new_code.strip().upper() if isinstance(new_code, str) and new_code.strip() else None
        )
        if cleaned_code:
            conflict = (
                SessionLocal.query(Subject)
                .filter(
                    Subject.student_id == student_id,
                    Subject.subject_code == cleaned_code,
                    Subject.id != subject_id,
                )
                .first()
            )
            if conflict:
                raise ConflictError(f"Subject code '{cleaned_code}' already exists.")
        subject.subject_code = cleaned_code

    if "color" in data and data["color"] is not None:
        subject.color = data["color"]
    if "description" in data:
        subject.description = data["description"]

    SessionLocal.commit()
    return serialize_subject(subject)


def delete_subject(student_id: int, subject_id: int) -> dict:
    subject = get_student_subject(student_id, subject_id)
    SessionLocal.delete(subject)
    SessionLocal.commit()
    return {"deleted_id": subject_id}


def compute_subject_stats(subject: Subject) -> dict:
    """Compute topic, task, study-time, and exam statistics for one subject."""
    topics = SessionLocal.query(Topic).filter_by(subject_id=subject.id).all()
    tasks = SessionLocal.query(Task).filter_by(subject_id=subject.id).all()
    sessions = SessionLocal.query(StudySession).filter_by(subject_id=subject.id).all()
    exams = SessionLocal.query(Exam).filter_by(subject_id=subject.id).all()

    total_topics = len(topics)
    completed_topics = sum(1 for t in topics if t.status == "completed")
    in_progress_topics = sum(1 for t in topics if t.status == "in_progress")
    pending_topics = sum(1 for t in topics if t.status == "not_started")
    syllabus_pct = (
        round(sum(t.completion_percentage for t in topics) / total_topics, 1)
        if total_topics
        else 0.0
    )

    total_tasks = len(tasks)
    completed_tasks = sum(1 for t in tasks if t.status == "completed")
    pending_tasks = sum(1 for t in tasks if t.status in ("pending", "in_progress"))

    total_study_minutes = sum(s.duration_minutes or 0 for s in sessions)

    scored_exams = [e.percentage for e in exams if e.percentage is not None]
    avg_exam_pct = (
        round(sum(scored_exams) / len(scored_exams), 1) if scored_exams else None
    )

    return {
        **serialize_subject(subject),
        "stats": {
            "total_topics": total_topics,
            "completed_topics": completed_topics,
            "in_progress_topics": in_progress_topics,
            "pending_topics": pending_topics,
            "syllabus_completion_percentage": syllabus_pct,
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "pending_tasks": pending_tasks,
            "total_study_minutes": total_study_minutes,
            "exam_count": len(exams),
            "average_exam_percentage": avg_exam_pct,
        },
    }


def get_subject_stats(student_id: int, subject_id: int) -> dict:
    subject = get_student_subject(student_id, subject_id)
    return compute_subject_stats(subject)


def get_all_subject_stats(student_id: int) -> list[dict]:
    subjects = (
        SessionLocal.query(Subject)
        .filter_by(student_id=student_id)
        .order_by(Subject.subject_name.asc())
        .all()
    )
    return [compute_subject_stats(s) for s in subjects]
