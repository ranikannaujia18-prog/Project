"""Syllabus coverage & topic management service."""

from __future__ import annotations

from backend.app.models import Subject, Topic
from backend.app.services.subject_service import get_student_subject
from backend.app.utils.errors import ConflictError, NotFoundError, ValidationError
from backend.app.utils.serializers import serialize_topic
from backend.app.utils.validators import parse_float, parse_iso_datetime, parse_positive_int
from backend.database.db import SessionLocal


def get_student_topic(student_id: int, topic_id: int) -> Topic:
    """Fetch a topic belonging to one of the student's subjects or raise 404."""
    topic = (
        SessionLocal.query(Topic)
        .join(Subject, Topic.subject_id == Subject.id)
        .filter(Topic.id == topic_id, Subject.student_id == student_id)
        .first()
    )
    if not topic:
        raise NotFoundError(f"Topic with id={topic_id} not found.")
    return topic


def create_topic(student_id: int, data: dict) -> dict:
    subject_id = parse_positive_int(data.get("subject_id"), "subject_id")
    get_student_subject(student_id, subject_id)

    topic_name = (data.get("topic_name") or "").strip()
    if not topic_name:
        raise ValidationError("'topic_name' cannot be empty.")

    if SessionLocal.query(Topic).filter_by(subject_id=subject_id, topic_name=topic_name).first():
        raise ConflictError(f"Topic '{topic_name}' already exists in this subject.")

    status = data.get("status", "not_started")
    completion = parse_float(
        data.get("completion_percentage", 100.0 if status == "completed" else 0.0),
        "completion_percentage",
        min_value=0.0,
        max_value=100.0,
    )
    confidence = parse_positive_int(data.get("confidence_level", 1), "confidence_level")

    topic = Topic(
        subject_id=subject_id,
        topic_name=topic_name,
        difficulty_level=data.get("difficulty_level", "medium"),
        status=status,
        confidence_level=confidence,
        completion_percentage=completion,
        last_revised_at=parse_iso_datetime(data.get("last_revised_at"), "last_revised_at"),
        notes=data.get("notes"),
    )
    SessionLocal.add(topic)
    SessionLocal.commit()
    return serialize_topic(topic)


def list_topics(
    student_id: int,
    subject_id: int | None = None,
    status: str | None = None,
    difficulty_level: str | None = None,
) -> list[dict]:
    query = (
        SessionLocal.query(Topic)
        .join(Subject, Topic.subject_id == Subject.id)
        .filter(Subject.student_id == student_id)
    )
    if subject_id is not None:
        query = query.filter(Topic.subject_id == subject_id)
    if status:
        query = query.filter(Topic.status == status)
    if difficulty_level:
        query = query.filter(Topic.difficulty_level == difficulty_level)

    topics = query.order_by(Topic.subject_id.asc(), Topic.topic_name.asc()).all()
    return [serialize_topic(t) for t in topics]


def get_topic_detail(student_id: int, topic_id: int) -> dict:
    return serialize_topic(get_student_topic(student_id, topic_id))


def update_topic(student_id: int, topic_id: int, data: dict) -> dict:
    topic = get_student_topic(student_id, topic_id)

    if "topic_name" in data and data["topic_name"] is not None:
        new_name = str(data["topic_name"]).strip()
        if not new_name:
            raise ValidationError("'topic_name' cannot be empty.")
        conflict = (
            SessionLocal.query(Topic)
            .filter(
                Topic.subject_id == topic.subject_id,
                Topic.topic_name == new_name,
                Topic.id != topic_id,
            )
            .first()
        )
        if conflict:
            raise ConflictError(f"Topic '{new_name}' already exists in this subject.")
        topic.topic_name = new_name

    if "difficulty_level" in data and data["difficulty_level"] is not None:
        topic.difficulty_level = data["difficulty_level"]
    if "status" in data and data["status"] is not None:
        topic.status = data["status"]
        # Keep completion_percentage sensible when marking completed without explicit %
        if data["status"] == "completed" and "completion_percentage" not in data:
            topic.completion_percentage = 100.0
    if "confidence_level" in data and data["confidence_level"] is not None:
        topic.confidence_level = parse_positive_int(
            data["confidence_level"], "confidence_level"
        )
    if "completion_percentage" in data and data["completion_percentage"] is not None:
        pct = parse_float(
            data["completion_percentage"],
            "completion_percentage",
            min_value=0.0,
            max_value=100.0,
        )
        topic.completion_percentage = pct
        if "status" not in data:
            if pct == 100.0:
                topic.status = "completed"
            elif pct > 0.0:
                topic.status = "in_progress"
            else:
                topic.status = "not_started"
    if "last_revised_at" in data:
        topic.last_revised_at = parse_iso_datetime(
            data["last_revised_at"], "last_revised_at"
        )
    if "notes" in data:
        topic.notes = data["notes"]

    SessionLocal.commit()
    return serialize_topic(topic)


def delete_topic(student_id: int, topic_id: int) -> dict:
    topic = get_student_topic(student_id, topic_id)
    SessionLocal.delete(topic)
    SessionLocal.commit()
    return {"deleted_id": topic_id}


def get_syllabus_coverage(student_id: int, subject_id: int | None = None) -> dict:
    """Return overall syllabus completion percentage, grouped topics, and subject reports."""
    subjects_query = SessionLocal.query(Subject).filter_by(student_id=student_id)
    if subject_id is not None:
        subjects_query = subjects_query.filter_by(id=subject_id)
    subjects = subjects_query.order_by(Subject.subject_name.asc()).all()

    all_topics: list[Topic] = []
    subject_reports: list[dict] = []

    for sub in subjects:
        topics = (
            SessionLocal.query(Topic)
            .filter_by(subject_id=sub.id)
            .order_by(Topic.topic_name.asc())
            .all()
        )
        all_topics.extend(topics)

        total = len(topics)
        completed = [t for t in topics if t.status == "completed"]
        ongoing = [t for t in topics if t.status == "in_progress"]
        pending = [t for t in topics if t.status == "not_started"]
        avg_pct = (
            round(sum(t.completion_percentage for t in topics) / total, 1)
            if total
            else 0.0
        )
        subject_reports.append(
            {
                "subject_id": sub.id,
                "subject_name": sub.subject_name,
                "subject_code": sub.subject_code,
                "color": sub.color,
                "total_topics": total,
                "completed_count": len(completed),
                "ongoing_count": len(ongoing),
                "pending_count": len(pending),
                "completion_percentage": avg_pct,
            }
        )

    total_all = len(all_topics)
    overall_pct = (
        round(sum(t.completion_percentage for t in all_topics) / total_all, 1)
        if total_all
        else 0.0
    )

    return {
        "overall_completion_percentage": overall_pct,
        "summary": {
            "total_topics": total_all,
            "completed": sum(1 for t in all_topics if t.status == "completed"),
            "ongoing": sum(1 for t in all_topics if t.status == "in_progress"),
            "pending": sum(1 for t in all_topics if t.status == "not_started"),
        },
        "grouped_topics": {
            "completed": [serialize_topic(t) for t in all_topics if t.status == "completed"],
            "ongoing": [serialize_topic(t) for t in all_topics if t.status == "in_progress"],
            "pending": [serialize_topic(t) for t in all_topics if t.status == "not_started"],
        },
        "subject_reports": subject_reports,
    }
