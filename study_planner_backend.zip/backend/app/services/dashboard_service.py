"""Dashboard summary service aggregating subjects, topics, tasks, study time, and exams."""

from __future__ import annotations

from datetime import date, timedelta

from backend.app.models import Exam, StudySession, Subject, Task, Topic, utc_now
from backend.app.utils.serializers import serialize_exam, serialize_task
from backend.app.utils.validators import ensure_utc
from backend.database.db import SessionLocal


def get_dashboard_summary(student_id: int) -> dict:
    """Return all key overview metrics needed by the main student dashboard."""
    now = utc_now()
    today = date.today()
    week_start = today - timedelta(days=6)
    deadline_horizon = now + timedelta(days=7)

    subjects = SessionLocal.query(Subject).filter_by(student_id=student_id).all()
    topics = (
        SessionLocal.query(Topic)
        .join(Subject, Topic.subject_id == Subject.id)
        .filter(Subject.student_id == student_id)
        .all()
    )
    tasks = SessionLocal.query(Task).filter_by(student_id=student_id).all()
    sessions = (
        SessionLocal.query(StudySession)
        .filter(
            StudySession.student_id == student_id,
            StudySession.duration_minutes.is_not(None),
        )
        .all()
    )
    exams = (
        SessionLocal.query(Exam)
        .filter_by(student_id=student_id)
        .order_by(Exam.exam_date.asc())
        .all()
    )

    total_topics = len(topics)
    completed_topics = sum(1 for t in topics if t.status == "completed")
    pending_topics = total_topics - completed_topics
    study_completion_pct = (
        round(sum(t.completion_percentage for t in topics) / total_topics, 1)
        if total_topics
        else 0.0
    )

    total_tasks = len(tasks)
    completed_tasks = sum(1 for t in tasks if t.status == "completed")
    pending_tasks = sum(1 for t in tasks if t.status in ("pending", "in_progress"))
    overdue_tasks = [
        t
        for t in tasks
        if t.due_date is not None
        and ensure_utc(t.due_date) < now
        and t.status not in ("completed", "cancelled")
    ]

    upcoming_deadlines = sorted(
        [
            t
            for t in tasks
            if t.due_date is not None
            and now <= ensure_utc(t.due_date) <= deadline_horizon
            and t.status not in ("completed", "cancelled")
        ],
        key=lambda t: ensure_utc(t.due_date),
    )

    today_study_minutes = sum(
        s.duration_minutes or 0
        for s in sessions
        if ensure_utc(s.start_time).date() == today
    )
    weekly_study_minutes = sum(
        s.duration_minutes or 0
        for s in sessions
        if ensure_utc(s.start_time).date() >= week_start
    )

    upcoming_exams = [e for e in exams if ensure_utc(e.exam_date) >= now][:5]

    return {
        "total_subjects": len(subjects),
        "total_topics": total_topics,
        "completed_topics": completed_topics,
        "pending_topics": pending_topics,
        "total_tasks": total_tasks,
        "completed_tasks": completed_tasks,
        "pending_tasks": pending_tasks,
        "overdue_tasks_count": len(overdue_tasks),
        "today_study_minutes": today_study_minutes,
        "weekly_study_minutes": weekly_study_minutes,
        "study_completion_percentage": study_completion_pct,
        "upcoming_exams": [serialize_exam(e) for e in upcoming_exams],
        "upcoming_deadlines": [serialize_task(t) for t in upcoming_deadlines[:10]],
    }
