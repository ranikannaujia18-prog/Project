"""Notes and external study resources service."""

from __future__ import annotations

from backend.app.models import Note
from backend.app.services.subject_service import get_student_subject
from backend.app.services.topic_service import get_student_topic
from backend.app.utils.errors import NotFoundError, ValidationError
from backend.app.utils.serializers import serialize_note
from backend.app.utils.validators import parse_positive_int
from backend.database.db import SessionLocal


def get_student_note(student_id: int, note_id: int) -> Note:
    note = SessionLocal.query(Note).filter_by(id=note_id, student_id=student_id).first()
    if not note:
        raise NotFoundError(f"Note with id={note_id} not found.")
    return note


def create_note(student_id: int, data: dict) -> dict:
    subject_id = parse_positive_int(data.get("subject_id"), "subject_id")
    topic_id = parse_positive_int(data.get("topic_id"), "topic_id")
    get_student_subject(student_id, subject_id)
    topic = get_student_topic(student_id, topic_id)
    if topic.subject_id != subject_id:
        raise ValidationError("Topic does not belong to the selected subject.")

    title = (data.get("title") or "").strip()
    content = (data.get("content") or "").strip()
    if not title or not content:
        raise ValidationError("'title' and 'content' cannot be empty.")

    note = Note(
        student_id=student_id,
        subject_id=subject_id,
        topic_id=topic_id,
        title=title,
        content=content,
        resource_url=data.get("resource_url"),
    )
    SessionLocal.add(note)
    SessionLocal.commit()
    return serialize_note(note)


def list_notes(
    student_id: int,
    subject_id: int | None = None,
    topic_id: int | None = None,
    search: str | None = None,
) -> list[dict]:
    query = SessionLocal.query(Note).filter_by(student_id=student_id)
    if subject_id is not None:
        query = query.filter(Note.subject_id == subject_id)
    if topic_id is not None:
        query = query.filter(Note.topic_id == topic_id)
    if search:
        pattern = f"%{search.strip()}%"
        query = query.filter(Note.title.ilike(pattern) | Note.content.ilike(pattern))

    rows = query.order_by(Note.updated_at.desc()).all()
    return [serialize_note(n) for n in rows]


def get_note_detail(student_id: int, note_id: int) -> dict:
    return serialize_note(get_student_note(student_id, note_id))


def update_note(student_id: int, note_id: int, data: dict) -> dict:
    note = get_student_note(student_id, note_id)

    if "subject_id" in data and data["subject_id"] is not None:
        new_sub_id = parse_positive_int(data["subject_id"], "subject_id")
        get_student_subject(student_id, new_sub_id)
        note.subject_id = new_sub_id

    if "topic_id" in data and data["topic_id"] is not None:
        new_topic_id = parse_positive_int(data["topic_id"], "topic_id")
        topic = get_student_topic(student_id, new_topic_id)
        if topic.subject_id != note.subject_id:
            raise ValidationError("Topic does not belong to the note's subject.")
        note.topic_id = new_topic_id

    if "title" in data and data["title"] is not None:
        title = str(data["title"]).strip()
        if not title:
            raise ValidationError("'title' cannot be empty.")
        note.title = title

    if "content" in data and data["content"] is not None:
        content = str(data["content"]).strip()
        if not content:
            raise ValidationError("'content' cannot be empty.")
        note.content = content

    if "resource_url" in data:
        note.resource_url = data["resource_url"]

    SessionLocal.commit()
    return serialize_note(note)


def delete_note(student_id: int, note_id: int) -> dict:
    note = get_student_note(student_id, note_id)
    SessionLocal.delete(note)
    SessionLocal.commit()
    return {"deleted_id": note_id}
