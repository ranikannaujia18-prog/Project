"""Productivity analytics service (daily/weekly/monthly stats, streaks, trends)."""

from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta

from backend.app.models import Exam, StudySession, Subject, Task, Topic
from backend.app.utils.validators import ensure_utc
from backend.database.db import SessionLocal


def calculate_study_streaks(study_dates: set[date], today: date | None = None) -> dict:
    """Compute current consecutive-day streak and longest historical streak."""
    if not study_dates:
        return {"current_streak_days": 0, "longest_streak_days": 0}

    ref_today = today or date.today()
    sorted_days = sorted(study_dates)

    longest = 1
    run = 1
    for i in range(1, len(sorted_days)):
        if (sorted_days[i] - sorted_days[i - 1]).days == 1:
            run += 1
            longest = max(longest, run)
        else:
            run = 1

    # Current streak counts backward from today (or yesterday if user hasn't studied yet today)
    current = 0
    cursor = ref_today if ref_today in study_dates else ref_today - timedelta(days=1)
    while cursor in study_dates:
        current += 1
        cursor -= timedelta(days=1)

    return {"current_streak_days": current, "longest_streak_days": longest}


def get_productivity_analytics(student_id: int) -> dict:
    """Return comprehensive study, task, syllabus, exam, streak, and trend analytics."""
    today = date.today()

    sessions = (
        SessionLocal.query(StudySession)
        .filter(
            StudySession.student_id == student_id,
            StudySession.duration_minutes.is_not(None),
        )
        .all()
    )
    subjects = {
        s.id: s.subject_name
        for s in SessionLocal.query(Subject).filter_by(student_id=student_id).all()
    }
    topics = (
        SessionLocal.query(Topic)
        .join(Subject, Topic.subject_id == Subject.id)
        .filter(Subject.student_id == student_id)
        .all()
    )
    tasks = SessionLocal.query(Task).filter_by(student_id=student_id).all()
    exams = (
        SessionLocal.query(Exam)
        .filter_by(student_id=student_id)
        .order_by(Exam.exam_date.asc())
        .all()
    )

    minutes_by_day: dict[date, int] = defaultdict(int)
    minutes_by_subject: dict[int, int] = defaultdict(int)
    minutes_by_month: dict[str, int] = defaultdict(int)

    for s in sessions:
        mins = s.duration_minutes or 0
        s_day = ensure_utc(s.start_time).date()
        minutes_by_day[s_day] += mins
        minutes_by_subject[s.subject_id] += mins
        minutes_by_month[s_day.strftime("%Y-%m")] += mins

    # Daily statistics (last 7 days)
    daily_stats = []
    for offset in range(6, -1, -1):
        d = today - timedelta(days=offset)
        daily_stats.append({"date": d.isoformat(), "minutes": minutes_by_day.get(d, 0)})

    # Weekly statistics (last 4 rolling 7-day windows)
    weekly_stats = []
    for w in range(3, -1, -1):
        end_d = today - timedelta(days=w * 7)
        start_d = end_d - timedelta(days=6)
        mins = sum(
            m for d, m in minutes_by_day.items() if start_d <= d <= end_d
        )
        weekly_stats.append(
            {
                "week_start": start_d.isoformat(),
                "week_end": end_d.isoformat(),
                "minutes": mins,
            }
        )

    # Monthly statistics (last 6 calendar months)
    monthly_stats = [
        {"month": month_key, "minutes": mins}
        for month_key, mins in sorted(minutes_by_month.items())[-6:]
    ]

    # Productivity trend (current 7 days vs previous 7 days)
    this_week_mins = weekly_stats[-1]["minutes"]
    prev_week_mins = weekly_stats[-2]["minutes"] if len(weekly_stats) >= 2 else 0
    if prev_week_mins > 0:
        trend_pct = round(((this_week_mins - prev_week_mins) / prev_week_mins) * 100, 1)
    else:
        trend_pct = 100.0 if this_week_mins > 0 else 0.0

    # Tasks completed & rate
    total_tasks = len(tasks)
    completed_tasks = sum(1 for t in tasks if t.status == "completed")
    task_completion_rate = (
        round((completed_tasks / total_tasks) * 100, 1) if total_tasks else 0.0
    )

    # Syllabus completion
    total_topics = len(topics)
    syllabus_completion_pct = (
        round(sum(t.completion_percentage for t in topics) / total_topics, 1)
        if total_topics
        else 0.0
    )

    # Exam performance
    graded_exams = [e for e in exams if e.percentage is not None]
    avg_exam_pct = (
        round(sum(e.percentage for e in graded_exams) / len(graded_exams), 1)
        if graded_exams
        else None
    )

    # Streaks
    streaks = calculate_study_streaks(set(minutes_by_day.keys()), today=today)

    return {
        "daily_study_stats": daily_stats,
        "weekly_study_stats": weekly_stats,
        "monthly_study_stats": monthly_stats,
        "study_time_by_subject": [
            {
                "subject_id": sid,
                "subject_name": subjects.get(sid, "Unknown"),
                "minutes": mins,
            }
            for sid, mins in sorted(minutes_by_subject.items(), key=lambda x: -x[1])
        ],
        "task_metrics": {
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "task_completion_rate": task_completion_rate,
        },
        "syllabus_completion": {
            "total_topics": total_topics,
            "completed_topics": sum(1 for t in topics if t.status == "completed"),
            "completion_percentage": syllabus_completion_pct,
        },
        "exam_performance": {
            "graded_exam_count": len(graded_exams),
            "average_percentage": avg_exam_pct,
            "history": [
                {
                    "exam_id": e.id,
                    "exam_name": e.exam_name,
                    "subject_name": subjects.get(e.subject_id, "Unknown"),
                    "percentage": e.percentage,
                }
                for e in graded_exams
            ],
        },
        "study_streaks": streaks,
        "productivity_trends": {
            "this_week_minutes": this_week_mins,
            "previous_week_minutes": prev_week_mins,
            "week_over_week_change_percentage": trend_pct,
            "direction": (
                "up" if trend_pct > 0 else ("down" if trend_pct < 0 else "flat")
            ),
        },
    }
