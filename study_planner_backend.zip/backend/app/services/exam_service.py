"""Exam management business logic (CRUD, upcoming countdown, scores)."""

from __future__ import annotations

from backend.app.models import Exam, utc_now
from backend.app.services.subject_service import get_student_subject
from backend.app.utils.errors import NotFoundError, ValidationError
from backend.app.utils.serializers import serialize_exam
from backend.app.utils.validators import (
    ensure_utc,
    parse_float,
    parse_iso_datetime,
    parse_positive_int,
)
from backend.database.db import SessionLocal


def get_student_exam(student_id: int, exam_id: int) -> Exam:
    exam = SessionLocal.query(Exam).filter_by(id=exam_id, student_id=student_id).first()
    if not exam:
        raise NotFoundError(f"Exam with id={exam_id} not found.")
    return exam


def create_exam(student_id: int, data: dict) -> dict:
    subject_id = parse_positive_int(data.get("subject_id"), "subject_id")
    get_student_subject(student_id, subject_id)

    name = (data.get("exam_name") or "").strip()
    if not name:
        raise ValidationError("'exam_name' cannot be empty.")

    exam_date = parse_iso_datetime(data.get("exam_date"), "exam_date")
    if exam_date is None:
        raise ValidationError("'exam_date' is required.")

    total_marks = parse_float(data.get("total_marks"), "total_marks", min_value=0.01)
    obtained_marks = parse_float(
        data.get("obtained_marks"),
        "obtained_marks",
        min_value=0.0,
        max_value=total_marks,
        allow_none=True,
    )

    exam = Exam(
        student_id=student_id,
        subject_id=subject_id,
        exam_name=name,
        exam_date=exam_date,
        total_marks=total_marks,
        obtained_marks=obtained_marks,
    )
    SessionLocal.add(exam)
    SessionLocal.commit()
    return serialize_exam(exam)


def list_exams(
    student_id: int,
    subject_id: int | None = None,
    upcoming_only: bool = False,
) -> list[dict]:
    query = SessionLocal.query(Exam).filter_by(student_id=student_id)
    if subject_id is not None:
        query = query.filter(Exam.subject_id == subject_id)
    exams = query.order_by(Exam.exam_date.asc()).all()

    if upcoming_only:
        now = utc_now()
        exams = [e for e in exams if ensure_utc(e.exam_date) >= now]

    return [serialize_exam(e) for e in exams]


def get_exam_detail(student_id: int, exam_id: int) -> dict:
    return serialize_exam(get_student_exam(student_id, exam_id))


def update_exam(student_id: int, exam_id: int, data: dict) -> dict:
    exam = get_student_exam(student_id, exam_id)

    if "subject_id" in data and data["subject_id"] is not None:
        new_sub_id = parse_positive_int(data["subject_id"], "subject_id")
        get_student_subject(student_id, new_sub_id)
        exam.subject_id = new_sub_id

    if "exam_name" in data and data["exam_name"] is not None:
        name = str(data["exam_name"]).strip()
        if not name:
            raise ValidationError("'exam_name' cannot be empty.")
        exam.exam_name = name

    if "exam_date" in data and data["exam_date"] is not None:
        exam.exam_date = parse_iso_datetime(data["exam_date"], "exam_date")

    if "total_marks" in data and data["total_marks"] is not None:
        exam.total_marks = parse_float(
            data["total_marks"], "total_marks", min_value=0.01
        )

    if "obtained_marks" in data:
        exam.obtained_marks = parse_float(
            data["obtained_marks"],
            "obtained_marks",
            min_value=0.0,
            max_value=exam.total_marks,
            allow_none=True,
        )

    if exam.obtained_marks is not None and exam.obtained_marks > exam.total_marks:
        raise ValidationError("obtained_marks cannot exceed total_marks.")

    SessionLocal.commit()
    return serialize_exam(exam)


def save_exam_score(student_id: int, exam_id: int, obtained_marks: float) -> dict:
    exam = get_student_exam(student_id, exam_id)
    exam.obtained_marks = parse_float(
        obtained_marks,
        "obtained_marks",
        min_value=0.0,
        max_value=exam.total_marks,
    )
    SessionLocal.commit()
    return serialize_exam(exam)


def delete_exam(student_id: int, exam_id: int) -> dict:
    exam = get_student_exam(student_id, exam_id)
    SessionLocal.delete(exam)
    SessionLocal.commit()
    return {"deleted_id": exam_id}
