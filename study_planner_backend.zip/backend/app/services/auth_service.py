"""Authentication business logic (register, login, logout, profile)."""

from __future__ import annotations

from backend.app.models import Student, UserSetting
from backend.app.utils.auth_decorators import generate_auth_token, revoke_auth_token
from backend.app.utils.errors import ConflictError, UnauthorizedError, ValidationError
from backend.app.utils.serializers import serialize_settings, serialize_student
from backend.database.db import SessionLocal


def register_student(name: str, email: str, password: str) -> dict:
    """Create a new student with hashed password and default settings."""
    cleaned_email = (email or "").strip().lower()
    if not cleaned_email:
        raise ValidationError("Email is required.")

    existing = SessionLocal.query(Student).filter_by(email=cleaned_email).first()
    if existing:
        raise ConflictError("An account with this email already exists.")

    student = Student(name=name, email=cleaned_email)
    student.set_password(password)

    SessionLocal.add(student)
    SessionLocal.flush()

    settings = UserSetting(student_id=student.id)
    SessionLocal.add(settings)
    SessionLocal.commit()

    token = generate_auth_token(student.id)
    return {
        "student": serialize_student(student),
        "settings": serialize_settings(settings),
        "token": token,
    }


def login_student(email: str, password: str) -> dict:
    """Validate credentials and return a signed Bearer token."""
    cleaned_email = (email or "").strip().lower()
    student = SessionLocal.query(Student).filter_by(email=cleaned_email).first()
    if not student or not student.check_password(password or ""):
        raise UnauthorizedError("Invalid email or password.")

    token = generate_auth_token(student.id)
    return {
        "student": serialize_student(student),
        "token": token,
    }


def logout_student(token: str) -> dict:
    """Revoke the current Bearer token."""
    revoke_auth_token(token)
    return {"logged_out": True}


def get_current_profile(student: Student) -> dict:
    """Return the authenticated student profile and settings."""
    settings = student.settings
    if settings is None:
        settings = UserSetting(student_id=student.id)
        SessionLocal.add(settings)
        SessionLocal.commit()
    return {
        "student": serialize_student(student),
        "settings": serialize_settings(settings),
    }
