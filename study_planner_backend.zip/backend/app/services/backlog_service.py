"""Smart Backlog Recovery Planner service.

Detects overdue tasks, unfinished tasks, and pending topics, prioritizes them
using urgency + exam proximity, and allocates them across upcoming days without
exceeding the student's configured daily study time. Never overwrites existing tasks.
"""

from __future__ import annotations

from datetime import date, timedelta

from backend.app.models import Exam, Subject, Task, Topic, UserSetting, utc_now
from backend.app.utils.validators import ensure_utc, parse_positive_int
from backend.database.db import SessionLocal

PRIORITY_POINTS = {"urgent": 40, "high": 30, "medium": 18, "low": 8}
DIFFICULTY_MINUTES = {"easy": 30, "medium": 45, "hard": 60}


def build_daily_schedule(
    backlog_items: list[dict],
    daily_minutes: int,
    horizon_days: int = 7,
    start_date: date | None = None,
) -> tuple[list[dict], list[dict]]:
    """Pack prioritized backlog items into day buckets without overloading any day."""
    begin = start_date or date.today()
    days: list[dict] = [
        {
            "date": (begin + timedelta(days=i)).isoformat(),
            "planned_minutes": 0,
            "remaining_minutes": daily_minutes,
            "items": [],
        }
        for i in range(horizon_days)
    ]

    overflow: list[dict] = []
    for item in backlog_items:
        est = item["estimated_minutes"]
        placed = False
        for day in days:
            # Allow a single large item on an empty day so it isn't stuck forever,
            # otherwise require it to fit cleanly inside remaining_minutes.
            if est <= day["remaining_minutes"] or (
                day["planned_minutes"] == 0 and est <= int(daily_minutes * 1.25)
            ):
                day["items"].append(item)
                day["planned_minutes"] += est
                day["remaining_minutes"] = max(0, daily_minutes - day["planned_minutes"])
                placed = True
                break
        if not placed:
            overflow.append(item)

    return days, overflow


def generate_backlog_recovery_plan(
    student_id: int,
    daily_minutes: int | None = None,
    horizon_days: int = 7,
) -> dict:
    """Create a read-only, non-destructive recovery plan for overdue & pending work."""
    now = utc_now()
    today = date.today()

    if daily_minutes is None:
        settings = (
            SessionLocal.query(UserSetting).filter_by(student_id=student_id).first()
        )
        daily_minutes = settings.daily_study_target if settings else 120
    else:
        daily_minutes = parse_positive_int(daily_minutes, "daily_minutes")

    horizon_days = parse_positive_int(horizon_days, "days")
    if horizon_days > 30:
        horizon_days = 30

    subjects = {
        s.id: s.subject_name
        for s in SessionLocal.query(Subject).filter_by(student_id=student_id).all()
    }

    # Nearest upcoming exam per subject (used to boost urgency for exam subjects)
    upcoming_exams = (
        SessionLocal.query(Exam)
        .filter_by(student_id=student_id)
        .order_by(Exam.exam_date.asc())
        .all()
    )
    nearest_exam_days: dict[int, int] = {}
    for e in upcoming_exams:
        days_left = (ensure_utc(e.exam_date).date() - today).days
        if days_left >= 0 and e.subject_id not in nearest_exam_days:
            nearest_exam_days[e.subject_id] = days_left

    def _exam_boost(subject_id: int) -> int:
        days_left = nearest_exam_days.get(subject_id)
        if days_left is None:
            return 0
        if days_left <= 3:
            return 35
        if days_left <= 7:
            return 25
        if days_left <= 14:
            return 15
        return 5

    # 1. Detect overdue & unfinished tasks
    tasks = (
        SessionLocal.query(Task)
        .filter(
            Task.student_id == student_id,
            Task.status.in_(("pending", "in_progress")),
        )
        .all()
    )

    backlog_items: list[dict] = []
    overdue_count = 0
    unfinished_task_count = 0

    for t in tasks:
        due_dt = ensure_utc(t.due_date)
        is_overdue = bool(due_dt is not None and due_dt < now)
        if is_overdue:
            overdue_count += 1
        else:
            unfinished_task_count += 1

        remaining_est = max(15, (t.estimated_minutes or 30) - (t.actual_minutes or 0))
        urgency = (
            (50 if is_overdue else 15)
            + PRIORITY_POINTS.get(t.priority, 15)
            + _exam_boost(t.subject_id)
        )
        backlog_items.append(
            {
                "item_type": "overdue_task" if is_overdue else "unfinished_task",
                "task_id": t.id,
                "title": t.title,
                "subject_id": t.subject_id,
                "subject_name": subjects.get(t.subject_id, "Unknown"),
                "priority": t.priority,
                "due_date": due_dt.isoformat() if due_dt else None,
                "estimated_minutes": remaining_est,
                "urgency_score": urgency,
                "days_to_subject_exam": nearest_exam_days.get(t.subject_id),
            }
        )

    # 2. Detect pending / incomplete topics
    pending_topics = (
        SessionLocal.query(Topic)
        .join(Subject, Topic.subject_id == Subject.id)
        .filter(
            Subject.student_id == student_id,
            Topic.status.in_(("not_started", "in_progress")),
        )
        .all()
    )

    for tp in pending_topics:
        base_mins = DIFFICULTY_MINUTES.get(tp.difficulty_level, 45)
        remaining_ratio = max(0.25, (100.0 - tp.completion_percentage) / 100.0)
        est_mins = max(15, round(base_mins * remaining_ratio))
        urgency = (
            20
            + (15 if tp.difficulty_level == "hard" else 8)
            + (5 - tp.confidence_level) * 4
            + _exam_boost(tp.subject_id)
        )
        backlog_items.append(
            {
                "item_type": "pending_topic",
                "topic_id": tp.id,
                "title": f"Study topic: {tp.topic_name}",
                "subject_id": tp.subject_id,
                "subject_name": subjects.get(tp.subject_id, "Unknown"),
                "priority": "high" if tp.difficulty_level == "hard" else "medium",
                "due_date": None,
                "estimated_minutes": est_mins,
                "urgency_score": urgency,
                "days_to_subject_exam": nearest_exam_days.get(tp.subject_id),
            }
        )

    backlog_items.sort(key=lambda item: (-item["urgency_score"], item["estimated_minutes"]))

    daily_plan, overflow = build_daily_schedule(
        backlog_items=backlog_items,
        daily_minutes=daily_minutes,
        horizon_days=horizon_days,
        start_date=today,
    )

    return {
        "daily_study_limit_minutes": daily_minutes,
        "horizon_days": horizon_days,
        "modifies_existing_tasks": False,
        "summary": {
            "overdue_tasks": overdue_count,
            "unfinished_tasks": unfinished_task_count,
            "pending_topics": len(pending_topics),
            "total_backlog_items": len(backlog_items),
            "total_estimated_minutes": sum(i["estimated_minutes"] for i in backlog_items),
            "scheduled_items": len(backlog_items) - len(overflow),
            "overflow_items": len(overflow),
        },
        "daily_recovery_plan": daily_plan,
        "unscheduled_overflow": overflow,
    }
