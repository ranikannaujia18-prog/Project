"""Revision scheduler service with configurable spaced-repetition intervals."""

from __future__ import annotations

from datetime import date, timedelta

from flask import current_app

from backend.app.models import RevisionSchedule, Topic, utc_now
from backend.app.services.topic_service import get_student_topic
from backend.app.utils.errors import ConflictError, NotFoundError, ValidationError
from backend.app.utils.serializers import serialize_revision
from backend.app.utils.validators import parse_iso_date, parse_positive_int
from backend.database.db import SessionLocal


def get_student_revision(student_id: int, revision_id: int) -> RevisionSchedule:
    rev = (
        SessionLocal.query(RevisionSchedule)
        .filter_by(id=revision_id, student_id=student_id)
        .first()
    )
    if not rev:
        raise NotFoundError(f"Revision schedule with id={revision_id} not found.")
    return rev


def suggest_revision_dates(
    base_date: date | None = None, intervals: list[int] | None = None
) -> list[dict]:
    """Pure rule-based date generator for spaced-repetition checkpoints."""
    start = base_date or date.today()
    days_list = intervals or current_app.config.get(
        "DEFAULT_REVISION_INTERVALS", [1, 3, 7, 14, 30]
    )
    if not isinstance(days_list, list) or not days_list:
        raise ValidationError("'intervals' must be a non-empty list of positive integers.")

    suggestions = []
    for idx, offset in enumerate(days_list, start=1):
        day_offset = parse_positive_int(offset, f"intervals[{idx - 1}]")
        suggestions.append(
            {
                "revision_number": idx,
                "offset_days": day_offset,
                "scheduled_date": (start + timedelta(days=day_offset)).isoformat(),
            }
        )
    return suggestions


def create_revision(student_id: int, data: dict) -> dict:
    topic_id = parse_positive_int(data.get("topic_id"), "topic_id")
    get_student_topic(student_id, topic_id)

    scheduled_date = parse_iso_date(data.get("scheduled_date"), "scheduled_date")
    if scheduled_date is None:
        raise ValidationError("'scheduled_date' is required (YYYY-MM-DD).")

    if data.get("revision_number") is not None:
        rev_num = parse_positive_int(data.get("revision_number"), "revision_number")
    else:
        existing_count = (
            SessionLocal.query(RevisionSchedule)
            .filter_by(student_id=student_id, topic_id=topic_id)
            .count()
        )
        rev_num = existing_count + 1

    if SessionLocal.query(RevisionSchedule).filter_by(
        student_id=student_id, topic_id=topic_id, revision_number=rev_num
    ).first():
        raise ConflictError(
            f"Revision #{rev_num} already exists for topic_id={topic_id}."
        )

    rev = RevisionSchedule(
        student_id=student_id,
        topic_id=topic_id,
        scheduled_date=scheduled_date,
        revision_number=rev_num,
        status=data.get("status", "scheduled"),
        notes=data.get("notes"),
    )
    SessionLocal.add(rev)
    SessionLocal.commit()
    return serialize_revision(rev)


def auto_schedule_revisions(student_id: int, data: dict) -> dict:
    """Suggest (and optionally save) spaced-repetition revisions for a topic."""
    topic_id = parse_positive_int(data.get("topic_id"), "topic_id")
    get_student_topic(student_id, topic_id)

    base_date = parse_iso_date(data.get("start_date"), "start_date") or date.today()
    intervals = data.get("intervals")
    save = bool(data.get("save", True))

    suggestions = suggest_revision_dates(base_date=base_date, intervals=intervals)
    if not save:
        return {"topic_id": topic_id, "saved": False, "suggestions": suggestions}

    # Find current highest revision_number for this topic so we never collide
    existing = (
        SessionLocal.query(RevisionSchedule)
        .filter_by(student_id=student_id, topic_id=topic_id)
        .all()
    )
    next_num = max((r.revision_number for r in existing), default=0) + 1

    created = []
    for item in suggestions:
        rev = RevisionSchedule(
            student_id=student_id,
            topic_id=topic_id,
            scheduled_date=date.fromisoformat(item["scheduled_date"]),
            revision_number=next_num,
            status="scheduled",
            notes=f"Auto-scheduled spaced revision (+{item['offset_days']} days).",
        )
        SessionLocal.add(rev)
        created.append(rev)
        next_num += 1

    SessionLocal.commit()
    return {
        "topic_id": topic_id,
        "saved": True,
        "revisions": [serialize_revision(r) for r in created],
    }


def list_revisions(
    student_id: int,
    topic_id: int | None = None,
    status: str | None = None,
    only_today: bool = False,
    only_overdue: bool = False,
) -> list[dict]:
    query = SessionLocal.query(RevisionSchedule).filter_by(student_id=student_id)
    if topic_id is not None:
        query = query.filter(RevisionSchedule.topic_id == topic_id)
    if status:
        query = query.filter(RevisionSchedule.status == status)

    today = date.today()
    if only_today:
        query = query.filter(RevisionSchedule.scheduled_date == today)
    elif only_overdue:
        query = query.filter(
            RevisionSchedule.scheduled_date < today,
            RevisionSchedule.status == "scheduled",
        )

    rows = query.order_by(RevisionSchedule.scheduled_date.asc()).all()
    return [serialize_revision(r) for r in rows]


def update_revision(student_id: int, revision_id: int, data: dict) -> dict:
    rev = get_student_revision(student_id, revision_id)
    if "scheduled_date" in data and data["scheduled_date"] is not None:
        rev.scheduled_date = parse_iso_date(data["scheduled_date"], "scheduled_date")
    if "status" in data and data["status"] is not None:
        rev.status = data["status"]
        if rev.status == "completed":
            topic = SessionLocal.get(Topic, rev.topic_id)
            if topic:
                topic.last_revised_at = utc_now()
    if "notes" in data:
        rev.notes = data["notes"]

    SessionLocal.commit()
    return serialize_revision(rev)


def complete_revision(student_id: int, revision_id: int, notes: str | None = None) -> dict:
    rev = get_student_revision(student_id, revision_id)
    rev.status = "completed"
    if notes is not None:
        rev.notes = notes
    topic = SessionLocal.get(Topic, rev.topic_id)
    if topic:
        topic.last_revised_at = utc_now()
    SessionLocal.commit()
    return serialize_revision(rev)


def delete_revision(student_id: int, revision_id: int) -> dict:
    rev = get_student_revision(student_id, revision_id)
    SessionLocal.delete(rev)
    SessionLocal.commit()
    return {"deleted_id": revision_id}
