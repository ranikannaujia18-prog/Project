"""Rule-based Weak Topic Detector (transparent weighted formula — no fake ML).

Formula (each factor normalized to 0–100, higher = weaker):
    weakness_score = (
        w_confidence * confidence_risk
      + w_exam       * exam_risk
      + w_difficulty * difficulty_risk
      + w_revision   * revision_risk
      + w_completion * completion_risk
    )

Default weights (automatically normalized to sum to 1.0):
    confidence : 0.30   -> (5 - confidence_level) / 4 * 100
    exam       : 0.25   -> 100 - subject_avg_exam_percentage (50 if no graded exams)
    difficulty : 0.15   -> easy=25, medium=60, hard=100
    revision   : 0.15   -> based on days since last_revised_at + missed/overdue revisions
    completion : 0.15   -> 100 - completion_percentage
"""

from __future__ import annotations

from collections import defaultdict
from datetime import date

from backend.app.models import Exam, RevisionSchedule, Subject, Topic, utc_now
from backend.app.utils.errors import ValidationError
from backend.app.utils.validators import ensure_utc
from backend.database.db import SessionLocal

DEFAULT_WEIGHTS = {
    "confidence": 0.30,
    "exam": 0.25,
    "difficulty": 0.15,
    "revision": 0.15,
    "completion": 0.15,
}

DIFFICULTY_RISK_MAP = {"easy": 25.0, "medium": 60.0, "hard": 100.0}


def normalize_weights(custom_weights: dict[str, float] | None = None) -> dict[str, float]:
    """Validate and normalize custom factor weights so they sum to 1.0."""
    merged = dict(DEFAULT_WEIGHTS)
    if custom_weights:
        for key, raw_val in custom_weights.items():
            if key not in DEFAULT_WEIGHTS:
                raise ValidationError(
                    f"Unknown weight key '{key}'. Allowed keys: {list(DEFAULT_WEIGHTS)}."
                )
            try:
                val = float(raw_val)
            except (TypeError, ValueError) as exc:
                raise ValidationError(f"Weight '{key}' must be a non-negative number.") from exc
            if val < 0:
                raise ValidationError(f"Weight '{key}' must be >= 0.")
            merged[key] = val

    total = sum(merged.values())
    if total <= 0:
        raise ValidationError("At least one weight must be greater than 0.")
    return {k: round(v / total, 4) for k, v in merged.items()}


def compute_topic_weakness_score(
    *,
    confidence_level: int,
    difficulty_level: str,
    completion_percentage: float,
    days_since_revision: int | None,
    missed_or_overdue_revisions: int,
    subject_exam_avg_pct: float | None,
    weights: dict[str, float],
) -> tuple[float, dict[str, float]]:
    """Pure, deterministic scoring function (easy to unit test and inspect)."""
    confidence_risk = ((5 - confidence_level) / 4.0) * 100.0
    exam_risk = (100.0 - subject_exam_avg_pct) if subject_exam_avg_pct is not None else 50.0
    difficulty_risk = DIFFICULTY_RISK_MAP.get(difficulty_level, 60.0)

    if days_since_revision is None:
        base_rev_risk = 100.0
    elif days_since_revision > 14:
        base_rev_risk = 90.0
    elif days_since_revision > 7:
        base_rev_risk = 65.0
    elif days_since_revision > 3:
        base_rev_risk = 35.0
    else:
        base_rev_risk = 10.0
    revision_risk = min(100.0, base_rev_risk + missed_or_overdue_revisions * 15.0)

    completion_risk = 100.0 - float(completion_percentage)

    breakdown = {
        "confidence_risk": round(confidence_risk, 1),
        "exam_risk": round(exam_risk, 1),
        "difficulty_risk": round(difficulty_risk, 1),
        "revision_risk": round(revision_risk, 1),
        "completion_risk": round(completion_risk, 1),
    }

    score = (
        weights["confidence"] * confidence_risk
        + weights["exam"] * exam_risk
        + weights["difficulty"] * difficulty_risk
        + weights["revision"] * revision_risk
        + weights["completion"] * completion_risk
    )
    return round(score, 2), breakdown


def analyze_weak_topics(
    student_id: int,
    custom_weights: dict[str, float] | None = None,
    weak_threshold: float = 55.0,
    high_risk_threshold: float = 70.0,
) -> dict:
    """Analyze all topics for a student and return categorized weakness insights."""
    weights = normalize_weights(custom_weights)
    now = utc_now()
    today = date.today()

    subjects = SessionLocal.query(Subject).filter_by(student_id=student_id).all()
    subject_map = {s.id: s for s in subjects}

    topics = (
        SessionLocal.query(Topic)
        .join(Subject, Topic.subject_id == Subject.id)
        .filter(Subject.student_id == student_id)
        .all()
    )

    exams = SessionLocal.query(Exam).filter_by(student_id=student_id).all()
    exam_scores_by_sub: dict[int, list[float]] = defaultdict(list)
    for e in exams:
        if e.percentage is not None:
            exam_scores_by_sub[e.subject_id].append(e.percentage)

    revisions = SessionLocal.query(RevisionSchedule).filter_by(student_id=student_id).all()
    missed_by_topic: dict[int, int] = defaultdict(int)
    for r in revisions:
        if r.status == "missed" or (r.status == "scheduled" and r.scheduled_date < today):
            missed_by_topic[r.topic_id] += 1

    scored_topics: list[dict] = []
    subject_scores: dict[int, list[float]] = defaultdict(list)

    for t in topics:
        sub = subject_map.get(t.subject_id)
        sub_exam_list = exam_scores_by_sub.get(t.subject_id, [])
        sub_exam_avg = (
            round(sum(sub_exam_list) / len(sub_exam_list), 1) if sub_exam_list else None
        )

        days_since_rev = None
        if t.last_revised_at is not None:
            days_since_rev = max(0, (now - ensure_utc(t.last_revised_at)).days)

        score, breakdown = compute_topic_weakness_score(
            confidence_level=t.confidence_level,
            difficulty_level=t.difficulty_level,
            completion_percentage=t.completion_percentage,
            days_since_revision=days_since_rev,
            missed_or_overdue_revisions=missed_by_topic.get(t.id, 0),
            subject_exam_avg_pct=sub_exam_avg,
            weights=weights,
        )

        if score >= high_risk_threshold:
            risk_level = "high_risk"
        elif score >= weak_threshold:
            risk_level = "weak"
        else:
            risk_level = "healthy"

        entry = {
            "topic_id": t.id,
            "topic_name": t.topic_name,
            "subject_id": t.subject_id,
            "subject_name": sub.subject_name if sub else "Unknown",
            "difficulty_level": t.difficulty_level,
            "status": t.status,
            "confidence_level": t.confidence_level,
            "completion_percentage": t.completion_percentage,
            "days_since_revision": days_since_rev,
            "missed_or_overdue_revisions": missed_by_topic.get(t.id, 0),
            "weakness_score": score,
            "risk_level": risk_level,
            "factor_breakdown": breakdown,
        }
        scored_topics.append(entry)
        subject_scores[t.subject_id].append(score)

    scored_topics.sort(key=lambda item: -item["weakness_score"])

    subjects_needing_attention = []
    for sid, scores in subject_scores.items():
        avg_score = round(sum(scores) / len(scores), 2)
        if avg_score >= weak_threshold:
            sub = subject_map[sid]
            subjects_needing_attention.append(
                {
                    "subject_id": sid,
                    "subject_name": sub.subject_name,
                    "subject_code": sub.subject_code,
                    "average_weakness_score": avg_score,
                    "weak_topic_count": sum(1 for sc in scores if sc >= weak_threshold),
                }
            )
    subjects_needing_attention.sort(key=lambda s: -s["average_weakness_score"])

    return {
        "method": "rule_based_weighted_scoring",
        "formula": (
            "weakness_score = w_confidence*confidence_risk + w_exam*exam_risk + "
            "w_difficulty*difficulty_risk + w_revision*revision_risk + w_completion*completion_risk"
        ),
        "weights_used": weights,
        "thresholds": {
            "weak_threshold": weak_threshold,
            "high_risk_threshold": high_risk_threshold,
        },
        "weak_topics": [t for t in scored_topics if t["weakness_score"] >= weak_threshold],
        "high_risk_topics": [
            t for t in scored_topics if t["weakness_score"] >= high_risk_threshold
        ],
        "topics_needing_revision": [
            t
            for t in scored_topics
            if t["days_since_revision"] is None
            or t["days_since_revision"] > 7
            or t["missed_or_overdue_revisions"] > 0
        ],
        "low_confidence_topics": [
            t for t in scored_topics if t["confidence_level"] <= 2
        ],
        "subjects_needing_attention": subjects_needing_attention,
        "all_topics_ranked": scored_topics,
    }
