"""Task management business logic (CRUD, filtering, overdue, completion)."""

from __future__ import annotations

from datetime import date, datetime, time, timezone

from backend.app.models import DailyGoal, Task, utc_now
from backend.app.services.subject_service import get_student_subject
from backend.app.services.topic_service import get_student_topic
from backend.app.utils.errors import NotFoundError, ValidationError
from backend.app.utils.serializers import serialize_task
from backend.app.utils.validators import (
    ensure_utc,
    parse_iso_date,
    parse_iso_datetime,
    parse_positive_int,
)
from backend.database.db import SessionLocal

PRIORITY_RANK = {"urgent": 0, "high": 1, "medium": 2, "low": 3}


def get_student_task(student_id: int, task_id: int) -> Task:
    task = SessionLocal.query(Task).filter_by(id=task_id, student_id=student_id).first()
    if not task:
        raise NotFoundError(f"Task with id={task_id} not found.")
    return task


def _sync_daily_goal_tasks(student_id: int, delta: int) -> None:
    """Increment/decrement today's DailyGoal.completed_tasks when a task toggles."""
    today_goal = (
        SessionLocal.query(DailyGoal)
        .filter_by(student_id=student_id, goal_date=date.today())
        .first()
    )
    if today_goal:
        today_goal.completed_tasks = max(0, today_goal.completed_tasks + delta)


def create_task(student_id: int, data: dict) -> dict:
    subject_id = parse_positive_int(data.get("subject_id"), "subject_id")
    get_student_subject(student_id, subject_id)

    topic_id = parse_positive_int(data.get("topic_id"), "topic_id", allow_none=True)
    if topic_id is not None:
        topic = get_student_topic(student_id, topic_id)
        if topic.subject_id != subject_id:
            raise ValidationError("Selected topic does not belong to the specified subject.")

    title = (data.get("title") or "").strip()
    if not title:
        raise ValidationError("'title' cannot be empty.")

    estimated = parse_positive_int(
        data.get("estimated_minutes"), "estimated_minutes", allow_none=True
    )
    actual = parse_positive_int(
        data.get("actual_minutes", 0), "actual_minutes", allow_zero=True
    )

    task = Task(
        student_id=student_id,
        subject_id=subject_id,
        topic_id=topic_id,
        title=title,
        description=data.get("description"),
        priority=data.get("priority", "medium"),
        status=data.get("status", "pending"),
        due_date=parse_iso_datetime(data.get("due_date"), "due_date"),
        estimated_minutes=estimated,
        actual_minutes=actual,
    )
    SessionLocal.add(task)
    if task.status == "completed":
        _sync_daily_goal_tasks(student_id, +1)
    SessionLocal.commit()
    return serialize_task(task)


def list_tasks(
    student_id: int,
    subject_id: int | None = None,
    topic_id: int | None = None,
    status: str | None = None,
    priority: str | None = None,
    due_date_str: str | None = None,
    overdue_only: bool = False,
    sort_by_priority: bool = False,
) -> list[dict]:
    query = SessionLocal.query(Task).filter_by(student_id=student_id)

    if subject_id is not None:
        query = query.filter(Task.subject_id == subject_id)
    if topic_id is not None:
        query = query.filter(Task.topic_id == topic_id)
    if status:
        query = query.filter(Task.status == status)
    if priority:
        query = query.filter(Task.priority == priority)
    if due_date_str:
        target_day = parse_iso_date(due_date_str, "date")
        day_start = datetime.combine(target_day, time.min, tzinfo=timezone.utc)
        day_end = datetime.combine(target_day, time.max, tzinfo=timezone.utc)
        query = query.filter(Task.due_date >= day_start, Task.due_date <= day_end)

    tasks = query.order_by(Task.due_date.asc().nullslast(), Task.created_at.desc()).all()

    if overdue_only:
        now = utc_now()
        tasks = [
            t
            for t in tasks
            if t.due_date is not None
            and ensure_utc(t.due_date) < now
            and t.status not in ("completed", "cancelled")
        ]

    if sort_by_priority:
        tasks.sort(
            key=lambda t: (
                PRIORITY_RANK.get(t.priority, 99),
                ensure_utc(t.due_date) or datetime.max.replace(tzinfo=timezone.utc),
            )
        )

    return [serialize_task(t) for t in tasks]


def get_task_detail(student_id: int, task_id: int) -> dict:
    return serialize_task(get_student_task(student_id, task_id))


def update_task(student_id: int, task_id: int, data: dict) -> dict:
    task = get_student_task(student_id, task_id)
    prev_status = task.status

    if "subject_id" in data and data["subject_id"] is not None:
        new_sub_id = parse_positive_int(data["subject_id"], "subject_id")
        get_student_subject(student_id, new_sub_id)
        task.subject_id = new_sub_id

    if "topic_id" in data:
        new_topic_id = parse_positive_int(data["topic_id"], "topic_id", allow_none=True)
        if new_topic_id is not None:
            topic = get_student_topic(student_id, new_topic_id)
            if topic.subject_id != task.subject_id:
                raise ValidationError("Selected topic does not belong to the task's subject.")
        task.topic_id = new_topic_id

    if "title" in data and data["title"] is not None:
        title = str(data["title"]).strip()
        if not title:
            raise ValidationError("'title' cannot be empty.")
        task.title = title

    if "description" in data:
        task.description = data["description"]
    if "priority" in data and data["priority"] is not None:
        task.priority = data["priority"]
    if "status" in data and data["status"] is not None:
        task.status = data["status"]
    if "due_date" in data:
        task.due_date = parse_iso_datetime(data["due_date"], "due_date")
    if "estimated_minutes" in data:
        task.estimated_minutes = parse_positive_int(
            data["estimated_minutes"], "estimated_minutes", allow_none=True
        )
    if "actual_minutes" in data and data["actual_minutes"] is not None:
        task.actual_minutes = parse_positive_int(
            data["actual_minutes"], "actual_minutes", allow_zero=True
        )

    if prev_status != "completed" and task.status == "completed":
        _sync_daily_goal_tasks(student_id, +1)
    elif prev_status == "completed" and task.status != "completed":
        _sync_daily_goal_tasks(student_id, -1)

    SessionLocal.commit()
    return serialize_task(task)


def mark_task_completed(student_id: int, task_id: int, actual_minutes: int | None = None) -> dict:
    task = get_student_task(student_id, task_id)
    was_completed = task.status == "completed"
    task.status = "completed"
    task.completed_at = utc_now()
    if actual_minutes is not None:
        task.actual_minutes = parse_positive_int(
            actual_minutes, "actual_minutes", allow_zero=True
        )
    if not was_completed:
        _sync_daily_goal_tasks(student_id, +1)
    SessionLocal.commit()
    return serialize_task(task)


def mark_task_pending(student_id: int, task_id: int) -> dict:
    task = get_student_task(student_id, task_id)
    was_completed = task.status == "completed"
    task.status = "pending"
    task.completed_at = None
    if was_completed:
        _sync_daily_goal_tasks(student_id, -1)
    SessionLocal.commit()
    return serialize_task(task)


def delete_task(student_id: int, task_id: int) -> dict:
    task = get_student_task(student_id, task_id)
    SessionLocal.delete(task)
    SessionLocal.commit()
    return {"deleted_id": task_id}
