"""Rule-based Study Recommendations engine (uses real student data, no fake AI)."""

from __future__ import annotations

from backend.app.services import (
    backlog_service,
    exam_service,
    task_service,
    weak_topic_service,
)


def get_study_recommendations(student_id: int) -> dict:
    """Combine weak-topic, backlog, task, and exam signals into clear next actions."""
    weak_report = weak_topic_service.analyze_weak_topics(student_id)
    backlog_report = backlog_service.generate_backlog_recovery_plan(
        student_id, horizon_days=3
    )
    upcoming_exams = exam_service.list_exams(student_id, upcoming_only=True)
    prioritized_tasks = [
        t
        for t in task_service.list_tasks(student_id, sort_by_priority=True)
        if t["status"] in ("pending", "in_progress")
    ]

    # 1. Next topic to study: highest-weakness incomplete topic (or top weak topic overall)
    incomplete_ranked = [
        t for t in weak_report["all_topics_ranked"] if t["status"] != "completed"
    ]
    next_topic = incomplete_ranked[0] if incomplete_ranked else (
        weak_report["all_topics_ranked"][0] if weak_report["all_topics_ranked"] else None
    )

    # 2. Top tasks to complete next (overdue + highest priority)
    recommended_tasks = sorted(
        prioritized_tasks,
        key=lambda t: (0 if t["is_overdue"] else 1),
    )[:5]

    # 3. Weak topics to revise
    weak_to_revise = weak_report["topics_needing_revision"][:5]

    # 4. Immediate backlog items from today's recovery bucket
    today_plan = backlog_report["daily_recovery_plan"][0] if backlog_report["daily_recovery_plan"] else {"items": []}
    backlog_to_recover = today_plan["items"][:5]

    # 5. Upcoming exams needing attention (within 14 days, or next 3 exams)
    exams_needing_attention = [
        {
            **exam,
            "reason": (
                f"Exam is in {exam['days_remaining']} day(s) — prioritize revision and practice."
                if exam["days_remaining"] is not None and exam["days_remaining"] <= 7
                else f"Upcoming in {exam['days_remaining']} day(s) — stay on track with syllabus."
            ),
        }
        for exam in upcoming_exams[:3]
    ]

    return {
        "engine": "deterministic_rule_based",
        "next_topic_to_study": (
            {
                **next_topic,
                "reason": (
                    f"Weakness score {next_topic['weakness_score']}/100, "
                    f"confidence {next_topic['confidence_level']}/5, "
                    f"completion {next_topic['completion_percentage']}%."
                ),
            }
            if next_topic
            else None
        ),
        "tasks_to_complete": recommended_tasks,
        "weak_topics_to_revise": weak_to_revise,
        "backlog_to_recover": backlog_to_recover,
        "exams_needing_attention": exams_needing_attention,
    }
