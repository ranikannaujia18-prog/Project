"""Daily goals and user study settings service."""

from __future__ import annotations

from datetime import date, datetime, time, timezone

from backend.app.models import DailyGoal, StudySession, Task, UserSetting
from backend.app.utils.errors import NotFoundError
from backend.app.utils.serializers import serialize_daily_goal, serialize_settings
from backend.app.utils.validators import ensure_utc, parse_iso_date, parse_positive_int
from backend.database.db import SessionLocal


def _compute_actuals_for_day(student_id: int, target_day: date) -> tuple[int, int]:
    """Calculate actual study minutes and tasks completed on a given date."""
    start_bound = datetime.combine(target_day, time.min, tzinfo=timezone.utc)
    end_bound = datetime.combine(target_day, time.max, tzinfo=timezone.utc)

    sessions = (
        SessionLocal.query(StudySession)
        .filter(
            StudySession.student_id == student_id,
            StudySession.duration_minutes.is_not(None),
            StudySession.start_time >= start_bound,
            StudySession.start_time <= end_bound,
        )
        .all()
    )
    minutes = sum(s.duration_minutes or 0 for s in sessions)

    completed_tasks = (
        SessionLocal.query(Task)
        .filter(
            Task.student_id == student_id,
            Task.status == "completed",
            Task.completed_at.is_not(None),
        )
        .all()
    )
    tasks_done = sum(
        1 for t in completed_tasks if ensure_utc(t.completed_at).date() == target_day
    )
    return minutes, tasks_done


def set_daily_goal(student_id: int, data: dict) -> dict:
    """Create or update the student's daily goal for a specific date (default today)."""
    goal_date = parse_iso_date(data.get("goal_date"), "goal_date") or date.today()

    settings = SessionLocal.query(UserSetting).filter_by(student_id=student_id).first()
    default_minutes = settings.daily_study_target if settings else 120

    target_minutes = parse_positive_int(
        data.get("target_minutes", default_minutes), "target_minutes", allow_zero=True
    )
    target_tasks = parse_positive_int(
        data.get("target_tasks", 3), "target_tasks", allow_zero=True
    )

    goal = (
        SessionLocal.query(DailyGoal)
        .filter_by(student_id=student_id, goal_date=goal_date)
        .first()
    )
    actual_mins, actual_tasks = _compute_actuals_for_day(student_id, goal_date)

    if goal:
        goal.target_minutes = target_minutes
        goal.target_tasks = target_tasks
        if "completed_minutes" in data and data["completed_minutes"] is not None:
            goal.completed_minutes = parse_positive_int(
                data["completed_minutes"], "completed_minutes", allow_zero=True
            )
        if "completed_tasks" in data and data["completed_tasks"] is not None:
            goal.completed_tasks = parse_positive_int(
                data["completed_tasks"], "completed_tasks", allow_zero=True
            )
    else:
        goal = DailyGoal(
            student_id=student_id,
            goal_date=goal_date,
            target_minutes=target_minutes,
            completed_minutes=parse_positive_int(
                data.get("completed_minutes", actual_mins),
                "completed_minutes",
                allow_zero=True,
            ),
            target_tasks=target_tasks,
            completed_tasks=parse_positive_int(
                data.get("completed_tasks", actual_tasks),
                "completed_tasks",
                allow_zero=True,
            ),
        )
        SessionLocal.add(goal)

    SessionLocal.commit()
    return serialize_daily_goal(goal)


def get_today_goal(student_id: int) -> dict:
    """Retrieve today's goal (auto-initializing from UserSetting if not created yet)."""
    today = date.today()
    goal = (
        SessionLocal.query(DailyGoal)
        .filter_by(student_id=student_id, goal_date=today)
        .first()
    )
    actual_mins, actual_tasks = _compute_actuals_for_day(student_id, today)

    if goal is None:
        settings = (
            SessionLocal.query(UserSetting).filter_by(student_id=student_id).first()
        )
        goal = DailyGoal(
            student_id=student_id,
            goal_date=today,
            target_minutes=settings.daily_study_target if settings else 120,
            completed_minutes=actual_mins,
            target_tasks=3,
            completed_tasks=actual_tasks,
        )
        SessionLocal.add(goal)
    else:
        goal.completed_minutes = max(goal.completed_minutes, actual_mins)
        goal.completed_tasks = max(goal.completed_tasks, actual_tasks)

    SessionLocal.commit()
    return serialize_daily_goal(goal)


def list_daily_goals(student_id: int, limit: int = 30) -> list[dict]:
    rows = (
        SessionLocal.query(DailyGoal)
        .filter_by(student_id=student_id)
        .order_by(DailyGoal.goal_date.desc())
        .limit(limit)
        .all()
    )
    return [serialize_daily_goal(g) for g in rows]


def update_daily_goal(student_id: int, goal_id: int, data: dict) -> dict:
    goal = (
        SessionLocal.query(DailyGoal)
        .filter_by(id=goal_id, student_id=student_id)
        .first()
    )
    if not goal:
        raise NotFoundError(f"DailyGoal with id={goal_id} not found.")

    if "target_minutes" in data and data["target_minutes"] is not None:
        goal.target_minutes = parse_positive_int(
            data["target_minutes"], "target_minutes", allow_zero=True
        )
    if "completed_minutes" in data and data["completed_minutes"] is not None:
        goal.completed_minutes = parse_positive_int(
            data["completed_minutes"], "completed_minutes", allow_zero=True
        )
    if "target_tasks" in data and data["target_tasks"] is not None:
        goal.target_tasks = parse_positive_int(
            data["target_tasks"], "target_tasks", allow_zero=True
        )
    if "completed_tasks" in data and data["completed_tasks"] is not None:
        goal.completed_tasks = parse_positive_int(
            data["completed_tasks"], "completed_tasks", allow_zero=True
        )

    SessionLocal.commit()
    return serialize_daily_goal(goal)


def update_user_settings(student_id: int, data: dict) -> dict:
    """Update the student's daily study target, Pomodoro timers, or theme."""
    settings = SessionLocal.query(UserSetting).filter_by(student_id=student_id).first()
    if not settings:
        settings = UserSetting(student_id=student_id)
        SessionLocal.add(settings)

    if "daily_study_target" in data and data["daily_study_target"] is not None:
        settings.daily_study_target = parse_positive_int(
            data["daily_study_target"], "daily_study_target"
        )
    if "pomodoro_duration" in data and data["pomodoro_duration"] is not None:
        settings.pomodoro_duration = parse_positive_int(
            data["pomodoro_duration"], "pomodoro_duration"
        )
    if "break_duration" in data and data["break_duration"] is not None:
        settings.break_duration = parse_positive_int(
            data["break_duration"], "break_duration"
        )
    if "theme" in data and data["theme"] is not None:
        settings.theme = data["theme"]

    SessionLocal.commit()
    return serialize_settings(settings)
