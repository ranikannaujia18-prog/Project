"""Study session tracker service (start, end, manual log, time summaries)."""

from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime, time, timedelta, timezone

from backend.app.models import DailyGoal, StudySession, Subject, Task, Topic, utc_now
from backend.app.services.subject_service import get_student_subject
from backend.app.services.task_service import get_student_task
from backend.app.services.topic_service import get_student_topic
from backend.app.utils.errors import ConflictError, NotFoundError, ValidationError
from backend.app.utils.serializers import serialize_study_session
from backend.app.utils.validators import (
    ensure_utc,
    parse_iso_date,
    parse_iso_datetime,
    parse_positive_int,
)
from backend.database.db import SessionLocal


def _sync_after_session_completed(
    student_id: int,
    topic: Topic,
    task: Task | None,
    duration_minutes: int,
    session_type: str,
    completed_at: datetime,
) -> None:
    """Update linked task actual_minutes, topic last_revised_at, and daily goal."""
    if task is not None:
        task.actual_minutes = (task.actual_minutes or 0) + duration_minutes

    if session_type == "revision":
        topic.last_revised_at = completed_at

    goal = (
        SessionLocal.query(DailyGoal)
        .filter_by(student_id=student_id, goal_date=completed_at.date())
        .first()
    )
    if goal:
        goal.completed_minutes = (goal.completed_minutes or 0) + duration_minutes


def start_session(student_id: int, data: dict) -> dict:
    """Start a live study session (prevents overlapping active sessions)."""
    active = (
        SessionLocal.query(StudySession)
        .filter(StudySession.student_id == student_id, StudySession.end_time.is_(None))
        .first()
    )
    if active:
        raise ConflictError(
            f"You already have an active study session (id={active.id}). "
            "End it before starting a new one."
        )

    subject_id = parse_positive_int(data.get("subject_id"), "subject_id")
    topic_id = parse_positive_int(data.get("topic_id"), "topic_id")
    get_student_subject(student_id, subject_id)
    topic = get_student_topic(student_id, topic_id)
    if topic.subject_id != subject_id:
        raise ValidationError("Topic does not belong to the selected subject.")

    task_id = parse_positive_int(data.get("task_id"), "task_id", allow_none=True)
    if task_id is not None:
        task = get_student_task(student_id, task_id)
        if task.subject_id != subject_id:
            raise ValidationError("Task does not belong to the selected subject.")

    session = StudySession(
        student_id=student_id,
        subject_id=subject_id,
        topic_id=topic_id,
        task_id=task_id,
        start_time=parse_iso_datetime(data.get("start_time"), "start_time") or utc_now(),
        end_time=None,
        duration_minutes=None,
        session_type=data.get("session_type", "focused"),
        notes=data.get("notes"),
    )
    SessionLocal.add(session)
    SessionLocal.commit()
    return serialize_study_session(session)


def end_session(student_id: int, session_id: int, data: dict | None = None) -> dict:
    """End an active study session, compute duration, and prevent invalid durations."""
    data = data or {}
    session = (
        SessionLocal.query(StudySession)
        .filter_by(id=session_id, student_id=student_id)
        .first()
    )
    if not session:
        raise NotFoundError(f"Study session with id={session_id} not found.")
    if session.end_time is not None:
        raise ConflictError("This study session has already ended.")

    start_dt = ensure_utc(session.start_time)
    end_dt = parse_iso_datetime(data.get("end_time"), "end_time") or utc_now()

    if end_dt <= start_dt:
        raise ValidationError("end_time must be strictly after start_time.")

    elapsed_seconds = (end_dt - start_dt).total_seconds()
    computed_minutes = max(1, round(elapsed_seconds / 60))
    if computed_minutes > 1440:
        raise ValidationError("Study session duration cannot exceed 24 hours (1440 minutes).")

    session.end_time = end_dt
    session.duration_minutes = computed_minutes
    if "notes" in data and data["notes"] is not None:
        session.notes = data["notes"]

    topic = SessionLocal.get(Topic, session.topic_id)
    task = SessionLocal.get(Task, session.task_id) if session.task_id else None
    _sync_after_session_completed(
        student_id, topic, task, computed_minutes, session.session_type, end_dt
    )

    SessionLocal.commit()
    return serialize_study_session(session)


def create_completed_session(student_id: int, data: dict) -> dict:
    """Manually save an already-completed study session with strict duration checks."""
    subject_id = parse_positive_int(data.get("subject_id"), "subject_id")
    topic_id = parse_positive_int(data.get("topic_id"), "topic_id")
    get_student_subject(student_id, subject_id)
    topic = get_student_topic(student_id, topic_id)
    if topic.subject_id != subject_id:
        raise ValidationError("Topic does not belong to the selected subject.")

    task_id = parse_positive_int(data.get("task_id"), "task_id", allow_none=True)
    task = None
    if task_id is not None:
        task = get_student_task(student_id, task_id)
        if task.subject_id != subject_id:
            raise ValidationError("Task does not belong to the selected subject.")

    start_dt = parse_iso_datetime(data.get("start_time"), "start_time")
    end_dt = parse_iso_datetime(data.get("end_time"), "end_time")
    if start_dt is None or end_dt is None:
        raise ValidationError("Both 'start_time' and 'end_time' are required.")
    if end_dt <= start_dt:
        raise ValidationError("end_time must be strictly after start_time.")

    computed_minutes = round((end_dt - start_dt).total_seconds() / 60)
    if computed_minutes <= 0:
        raise ValidationError("Study session duration must be at least 1 minute.")
    if computed_minutes > 1440:
        raise ValidationError("Study session duration cannot exceed 24 hours (1440 minutes).")

    duration = (
        parse_positive_int(data.get("duration_minutes"), "duration_minutes")
        if data.get("duration_minutes") is not None
        else computed_minutes
    )
    if duration > 1440:
        raise ValidationError("duration_minutes cannot exceed 1440 minutes.")

    session = StudySession(
        student_id=student_id,
        subject_id=subject_id,
        topic_id=topic_id,
        task_id=task_id,
        start_time=start_dt,
        end_time=end_dt,
        duration_minutes=duration,
        session_type=data.get("session_type", "focused"),
        notes=data.get("notes"),
    )
    SessionLocal.add(session)
    _sync_after_session_completed(
        student_id, topic, task, duration, session.session_type, end_dt
    )
    SessionLocal.commit()
    return serialize_study_session(session)


def get_active_session(student_id: int) -> dict | None:
    active = (
        SessionLocal.query(StudySession)
        .filter(StudySession.student_id == student_id, StudySession.end_time.is_(None))
        .first()
    )
    return serialize_study_session(active) if active else None


def list_sessions(
    student_id: int,
    subject_id: int | None = None,
    topic_id: int | None = None,
    session_type: str | None = None,
    date_str: str | None = None,
) -> list[dict]:
    query = SessionLocal.query(StudySession).filter_by(student_id=student_id)
    if subject_id is not None:
        query = query.filter(StudySession.subject_id == subject_id)
    if topic_id is not None:
        query = query.filter(StudySession.topic_id == topic_id)
    if session_type:
        query = query.filter(StudySession.session_type == session_type)
    if date_str:
        target = parse_iso_date(date_str, "date")
        start_bound = datetime.combine(target, time.min, tzinfo=timezone.utc)
        end_bound = datetime.combine(target, time.max, tzinfo=timezone.utc)
        query = query.filter(
            StudySession.start_time >= start_bound, StudySession.start_time <= end_bound
        )

    rows = query.order_by(StudySession.start_time.desc()).all()
    return [serialize_study_session(r) for r in rows]


def get_session_summary(student_id: int) -> dict:
    """Calculate daily, weekly, subject-wise, and topic-wise study minutes."""
    sessions = (
        SessionLocal.query(StudySession)
        .filter(
            StudySession.student_id == student_id,
            StudySession.duration_minutes.is_not(None),
        )
        .all()
    )

    today = date.today()
    week_start = today - timedelta(days=6)

    today_minutes = 0
    weekly_minutes = 0
    by_subject: dict[int, int] = defaultdict(int)
    by_topic: dict[int, int] = defaultdict(int)

    for s in sessions:
        mins = s.duration_minutes or 0
        s_date = ensure_utc(s.start_time).date()
        if s_date == today:
            today_minutes += mins
        if s_date >= week_start:
            weekly_minutes += mins
        by_subject[s.subject_id] += mins
        by_topic[s.topic_id] += mins

    subjects = {
        s.id: s.subject_name
        for s in SessionLocal.query(Subject).filter_by(student_id=student_id).all()
    }
    topics = {
        t.id: t.topic_name
        for t in SessionLocal.query(Topic)
        .join(Subject, Topic.subject_id == Subject.id)
        .filter(Subject.student_id == student_id)
        .all()
    }

    return {
        "today_minutes": today_minutes,
        "weekly_minutes": weekly_minutes,
        "total_minutes": sum(by_subject.values()),
        "total_sessions": len(sessions),
        "by_subject": [
            {
                "subject_id": sid,
                "subject_name": subjects.get(sid, "Unknown"),
                "minutes": mins,
            }
            for sid, mins in sorted(by_subject.items(), key=lambda x: -x[1])
        ],
        "by_topic": [
            {
                "topic_id": tid,
                "topic_name": topics.get(tid, "Unknown"),
                "minutes": mins,
            }
            for tid, mins in sorted(by_topic.items(), key=lambda x: -x[1])
        ],
    }
