"""Environment-specific Flask configuration classes."""

from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DEFAULT_DB_PATH = BASE_DIR / "database" / "study_planner.db"


class BaseConfig:
    """Shared defaults for all environments."""

    SECRET_KEY = os.getenv("SECRET_KEY", "dev-change-this-secret-key-before-deploy")
    DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{DEFAULT_DB_PATH}")
    SQLALCHEMY_ECHO = os.getenv("SQLALCHEMY_ECHO", "false").lower() == "true"

    # Bearer token expiry in seconds (default: 7 days)
    AUTH_TOKEN_MAX_AGE = int(os.getenv("AUTH_TOKEN_MAX_AGE", str(7 * 24 * 3600)))

    # CORS origins (comma-separated in .env, default "*" for local development)
    CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*")

    # Default spaced-repetition intervals in days for Revision Scheduler
    DEFAULT_REVISION_INTERVALS = [1, 3, 7, 14, 30]


class DevelopmentConfig(BaseConfig):
    """Local development settings."""

    DEBUG = True


class TestingConfig(BaseConfig):
    """Isolated in-memory SQLite settings for pytest."""

    TESTING = True
    DEBUG = False
    DATABASE_URL = "sqlite:///:memory:"
    SECRET_KEY = "test-secret-key"


class ProductionConfig(BaseConfig):
    """Production settings (always supply SECRET_KEY via environment)."""

    DEBUG = False


CONFIG_MAP = {
    "development": DevelopmentConfig,
    "testing": TestingConfig,
    "production": ProductionConfig,
}
