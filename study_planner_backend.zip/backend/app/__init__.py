"""Flask application factory for the Study Planner and Task Tracker backend."""

from __future__ import annotations

from dotenv import load_dotenv
from flask import Flask
from sqlalchemy import text

from backend.app.config import CONFIG_MAP, DevelopmentConfig
from backend.app.extensions import cors
from backend.app.routes import register_blueprints
from backend.app.utils.errors import register_error_handlers
from backend.app.utils.responses import success_response
from backend.database.db import SessionLocal, init_app as init_db_app


def create_app(config_name: str = "development") -> Flask:
    """Create and configure a Flask application instance."""
    load_dotenv()

    app = Flask(__name__)
    config_cls = CONFIG_MAP.get(config_name, DevelopmentConfig)
    app.config.from_object(config_cls)

    # Enable CORS for frontend/API clients
    origins = app.config.get("CORS_ORIGINS", "*")
    if isinstance(origins, str) and "," in origins:
        origins = [o.strip() for o in origins.split(",") if o.strip()]
    cors.init_app(app, resources={r"/api/*": {"origins": origins}})

    # Connect SQLAlchemy + SQLite and ensure schema tables exist
    init_db_app(app)

    # Register global JSON error handlers and all 14 REST Blueprints
    register_error_handlers(app)
    register_blueprints(app)

    @app.get("/api/health")
    def health_check():
        """Verify the Flask server and SQLite database connection are healthy."""
        SessionLocal.execute(text("SELECT 1"))
        return success_response(
            {"database": "connected", "environment": config_name},
            message="Study Planner API is healthy.",
        )

    return app
