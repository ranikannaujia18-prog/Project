"""Database engine, session management, and Flask integration.

Centralizes SQLAlchemy + SQLite configuration so standalone scripts
(init_db.py, seed.py), the Flask app, and pytest tests share the same setup.
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Session, scoped_session, sessionmaker
from sqlalchemy.pool import StaticPool

# Default SQLite file lives at: backend/database/study_planner.db
BASE_DIR = Path(__file__).resolve().parent
DATABASE_PATH = BASE_DIR / "study_planner.db"
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{DATABASE_PATH}")


class Base(DeclarativeBase):
    """Base class that every SQLAlchemy model inherits from."""


def _build_engine(database_url: str, echo: bool = False) -> Engine:
    """Create a SQLAlchemy engine with SQLite-friendly settings."""
    connect_args: dict[str, object] = {}
    engine_kwargs: dict[str, object] = {"echo": echo, "future": True}

    if database_url.startswith("sqlite"):
        connect_args["check_same_thread"] = False
        # In-memory SQLite needs StaticPool so all connections share the same DB
        if database_url in ("sqlite://", "sqlite:///:memory:"):
            engine_kwargs["poolclass"] = StaticPool

    eng = create_engine(database_url, connect_args=connect_args, **engine_kwargs)

    if database_url.startswith("sqlite"):
        @event.listens_for(eng, "connect")
        def _enable_sqlite_foreign_keys(dbapi_connection, _connection_record) -> None:
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

    return eng


engine = _build_engine(
    DATABASE_URL,
    echo=os.getenv("SQLALCHEMY_ECHO", "false").lower() == "true",
)

_session_factory = sessionmaker(
    bind=engine,
    autoflush=False,
    autocommit=False,
    expire_on_commit=False,
)

# Request/thread-scoped session used across Flask routes and services
SessionLocal = scoped_session(_session_factory)


def configure_database(database_url: str, echo: bool = False) -> Engine:
    """Rebind the global engine and SessionLocal (useful for Flask config & tests)."""
    global DATABASE_URL, engine, _session_factory

    SessionLocal.remove()
    DATABASE_URL = database_url
    engine = _build_engine(database_url, echo=echo)
    _session_factory = sessionmaker(
        bind=engine,
        autoflush=False,
        autocommit=False,
        expire_on_commit=False,
    )
    SessionLocal.configure(bind=engine)
    return engine


def get_session() -> Session:
    """Return the current thread/request-scoped SQLAlchemy session."""
    return SessionLocal()


@contextmanager
def get_db() -> Generator[Session, None, None]:
    """Context manager for safe database transactions in CLI scripts."""
    session = _session_factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def init_app(app) -> None:
    """Attach database configuration and session teardown to a Flask app."""
    configured_url = app.config.get("DATABASE_URL") or DATABASE_URL
    echo = bool(app.config.get("SQLALCHEMY_ECHO", False))
    if configured_url != DATABASE_URL:
        configure_database(configured_url, echo=echo)

    app.config["DATABASE_URL"] = DATABASE_URL

    # Import models so Base.metadata knows about every table, then ensure tables exist
    from backend.database import models  # noqa: F401
    Base.metadata.create_all(bind=engine)

    @app.teardown_appcontext
    def _shutdown_session(_exception=None) -> None:
        SessionLocal.remove()
