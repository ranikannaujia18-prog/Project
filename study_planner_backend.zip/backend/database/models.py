"""SQLAlchemy ORM models for the Study Planner and Task Tracker database.

Tables defined here:
    1. students           (Student)
    2. subjects           (Subject)
    3. topics             (Topic)
    4. tasks              (Task)
    5. study_sessions     (StudySession)
    6. exams              (Exam)
    7. revision_schedules (RevisionSchedule)
    8. daily_goals        (DailyGoal)
    9. notes              (Note)
   10. user_settings      (UserSetting)
"""

from __future__ import annotations

import re
from datetime import date, datetime, timezone
from typing import Optional

from sqlalchemy import (
    CheckConstraint,
    Date,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship, validates
from werkzeug.security import check_password_hash, generate_password_hash

from backend.database.db import Base

# ---------------------------------------------------------------------------
# Shared validation constants & helpers
# ---------------------------------------------------------------------------
EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
HEX_COLOR_REGEX = re.compile(r"^#[0-9A-Fa-f]{6}$")

VALID_DIFFICULTIES = ("easy", "medium", "hard")
VALID_TOPIC_STATUSES = ("not_started", "in_progress", "completed")
VALID_TASK_PRIORITIES = ("low", "medium", "high", "urgent")
VALID_TASK_STATUSES = ("pending", "in_progress", "completed", "cancelled")
VALID_SESSION_TYPES = ("pomodoro", "focused", "revision", "practice", "group")
VALID_REVISION_STATUSES = ("scheduled", "completed", "missed", "rescheduled")
VALID_THEMES = ("light", "dark", "system")


def utc_now() -> datetime:
    """Return the current timezone-aware UTC timestamp."""
    return datetime.now(timezone.utc)


# ===========================================================================
# 1. Students
# ===========================================================================
class Student(Base):
    """Represents a registered student account."""

    __tablename__ = "students"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    email: Mapped[str] = mapped_column(
        String(255), unique=True, nullable=False, index=True
    )
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utc_now, nullable=False
    )

    subjects: Mapped[list["Subject"]] = relationship(
        "Subject",
        back_populates="student",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    tasks: Mapped[list["Task"]] = relationship(
        "Task",
        back_populates="student",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    study_sessions: Mapped[list["StudySession"]] = relationship(
        "StudySession",
        back_populates="student",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    exams: Mapped[list["Exam"]] = relationship(
        "Exam",
        back_populates="student",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    revision_schedules: Mapped[list["RevisionSchedule"]] = relationship(
        "RevisionSchedule",
        back_populates="student",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    daily_goals: Mapped[list["DailyGoal"]] = relationship(
        "DailyGoal",
        back_populates="student",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    notes: Mapped[list["Note"]] = relationship(
        "Note",
        back_populates="student",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    settings: Mapped[Optional["UserSetting"]] = relationship(
        "UserSetting",
        back_populates="student",
        uselist=False,
        cascade="all, delete-orphan",
        passive_deletes=True,
    )

    def set_password(self, raw_password: str) -> None:
        """Hash and store a plaintext password securely using Werkzeug."""
        if not raw_password or len(raw_password) < 8:
            raise ValueError("Password must be at least 8 characters long.")
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password: str) -> bool:
        """Verify a plaintext password against the stored hash."""
        return check_password_hash(self.password_hash, raw_password)

    @validates("name")
    def _validate_name(self, _key: str, value: str) -> str:
        cleaned = (value or "").strip()
        if not cleaned:
            raise ValueError("Student name cannot be empty.")
        return cleaned

    @validates("email")
    def _validate_email(self, _key: str, value: str) -> str:
        cleaned = (value or "").strip().lower()
        if not EMAIL_REGEX.match(cleaned):
            raise ValueError(f"Invalid email address: {value!r}")
        return cleaned

    def __repr__(self) -> str:
        return f"<Student id={self.id} email={self.email!r}>"


# ===========================================================================
# 2. Subjects
# ===========================================================================
class Subject(Base):
    """Represents a course or subject owned by a student."""

    __tablename__ = "subjects"
    __table_args__ = (
        UniqueConstraint("student_id", "subject_name", name="uq_subject_student_name"),
        UniqueConstraint("student_id", "subject_code", name="uq_subject_student_code"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("students.id", ondelete="CASCADE"), nullable=False, index=True
    )
    subject_name: Mapped[str] = mapped_column(String(120), nullable=False)
    subject_code: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    color: Mapped[str] = mapped_column(String(7), nullable=False, default="#4A90E2")
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    student: Mapped["Student"] = relationship("Student", back_populates="subjects")
    topics: Mapped[list["Topic"]] = relationship(
        "Topic",
        back_populates="subject",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    tasks: Mapped[list["Task"]] = relationship(
        "Task",
        back_populates="subject",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    study_sessions: Mapped[list["StudySession"]] = relationship(
        "StudySession",
        back_populates="subject",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    exams: Mapped[list["Exam"]] = relationship(
        "Exam",
        back_populates="subject",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    notes: Mapped[list["Note"]] = relationship(
        "Note",
        back_populates="subject",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )

    @validates("color")
    def _validate_color(self, _key: str, value: str) -> str:
        cleaned = (value or "").strip()
        if not HEX_COLOR_REGEX.match(cleaned):
            raise ValueError("Color must be a 6-digit hex code like '#4A90E2'.")
        return cleaned.upper()

    @validates("subject_code")
    def _validate_subject_code(self, _key: str, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        cleaned = value.strip().upper()
        return cleaned or None

    def __repr__(self) -> str:
        return f"<Subject id={self.id} code={self.subject_code!r} name={self.subject_name!r}>"


# ===========================================================================
# 3. Topics
# ===========================================================================
class Topic(Base):
    """Represents a syllabus topic or chapter within a subject."""

    __tablename__ = "topics"
    __table_args__ = (
        UniqueConstraint("subject_id", "topic_name", name="uq_topic_subject_name"),
        CheckConstraint(
            "difficulty_level IN ('easy', 'medium', 'hard')",
            name="ck_topic_difficulty",
        ),
        CheckConstraint(
            "status IN ('not_started', 'in_progress', 'completed')",
            name="ck_topic_status",
        ),
        CheckConstraint(
            "confidence_level >= 1 AND confidence_level <= 5",
            name="ck_topic_confidence_range",
        ),
        CheckConstraint(
            "completion_percentage >= 0 AND completion_percentage <= 100",
            name="ck_topic_completion_range",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    subject_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("subjects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    topic_name: Mapped[str] = mapped_column(String(150), nullable=False)
    difficulty_level: Mapped[str] = mapped_column(
        String(20), nullable=False, default="medium"
    )
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="not_started"
    )
    confidence_level: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    completion_percentage: Mapped[float] = mapped_column(
        Float, nullable=False, default=0.0
    )
    last_revised_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    subject: Mapped["Subject"] = relationship("Subject", back_populates="topics")
    tasks: Mapped[list["Task"]] = relationship(
        "Task",
        back_populates="topic",
        passive_deletes=True,
    )
    study_sessions: Mapped[list["StudySession"]] = relationship(
        "StudySession",
        back_populates="topic",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    revision_schedules: Mapped[list["RevisionSchedule"]] = relationship(
        "RevisionSchedule",
        back_populates="topic",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    study_notes: Mapped[list["Note"]] = relationship(
        "Note",
        back_populates="topic",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )

    @validates("difficulty_level")
    def _validate_difficulty(self, _key: str, value: str) -> str:
        if value not in VALID_DIFFICULTIES:
            raise ValueError(f"difficulty_level must be one of {VALID_DIFFICULTIES}")
        return value

    @validates("status")
    def _validate_status(self, _key: str, value: str) -> str:
        if value not in VALID_TOPIC_STATUSES:
            raise ValueError(f"status must be one of {VALID_TOPIC_STATUSES}")
        return value

    @validates("confidence_level")
    def _validate_confidence(self, _key: str, value: int) -> int:
        if not 1 <= value <= 5:
            raise ValueError("confidence_level must be between 1 and 5.")
        return value

    @validates("completion_percentage")
    def _validate_completion(self, _key: str, value: float) -> float:
        if not 0.0 <= value <= 100.0:
            raise ValueError("completion_percentage must be between 0 and 100.")
        return float(value)

    def __repr__(self) -> str:
        return f"<Topic id={self.id} name={self.topic_name!r} status={self.status!r}>"


# ===========================================================================
# 4. Tasks
# ===========================================================================
class Task(Base):
    """Represents an actionable study task or assignment."""

    __tablename__ = "tasks"
    __table_args__ = (
        CheckConstraint(
            "priority IN ('low', 'medium', 'high', 'urgent')",
            name="ck_task_priority",
        ),
        CheckConstraint(
            "status IN ('pending', 'in_progress', 'completed', 'cancelled')",
            name="ck_task_status",
        ),
        CheckConstraint(
            "estimated_minutes IS NULL OR estimated_minutes > 0",
            name="ck_task_estimated_minutes_positive",
        ),
        CheckConstraint(
            "actual_minutes >= 0",
            name="ck_task_actual_minutes_non_negative",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("students.id", ondelete="CASCADE"), nullable=False, index=True
    )
    subject_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("subjects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    topic_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("topics.id", ondelete="SET NULL"), nullable=True, index=True
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    priority: Mapped[str] = mapped_column(String(20), nullable=False, default="medium")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")
    due_date: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True, index=True
    )
    estimated_minutes: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    actual_minutes: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utc_now, nullable=False
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    student: Mapped["Student"] = relationship("Student", back_populates="tasks")
    subject: Mapped["Subject"] = relationship("Subject", back_populates="tasks")
    topic: Mapped[Optional["Topic"]] = relationship("Topic", back_populates="tasks")
    study_sessions: Mapped[list["StudySession"]] = relationship(
        "StudySession",
        back_populates="task",
        passive_deletes=True,
    )

    @validates("priority")
    def _validate_priority(self, _key: str, value: str) -> str:
        if value not in VALID_TASK_PRIORITIES:
            raise ValueError(f"priority must be one of {VALID_TASK_PRIORITIES}")
        return value

    @validates("status")
    def _validate_status(self, _key: str, value: str) -> str:
        if value not in VALID_TASK_STATUSES:
            raise ValueError(f"status must be one of {VALID_TASK_STATUSES}")
        if value == "completed" and self.completed_at is None:
            self.completed_at = utc_now()
        elif value != "completed":
            self.completed_at = None
        return value

    def __repr__(self) -> str:
        return f"<Task id={self.id} title={self.title!r} status={self.status!r}>"


# ===========================================================================
# 5. Study_Sessions
# ===========================================================================
class StudySession(Base):
    """Logs a live (in-progress) or completed study block.

    When a session is started via POST /api/study-sessions/start, end_time and
    duration_minutes remain NULL until POST /api/study-sessions/<id>/end
    completes it and computes duration_minutes.
    """

    __tablename__ = "study_sessions"
    __table_args__ = (
        CheckConstraint(
            "duration_minutes IS NULL OR duration_minutes > 0",
            name="ck_session_duration_positive",
        ),
        CheckConstraint(
            "end_time IS NULL OR end_time > start_time",
            name="ck_session_end_after_start",
        ),
        CheckConstraint(
            "session_type IN ('pomodoro', 'focused', 'revision', 'practice', 'group')",
            name="ck_session_type",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("students.id", ondelete="CASCADE"), nullable=False, index=True
    )
    subject_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("subjects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    topic_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("topics.id", ondelete="CASCADE"), nullable=False, index=True
    )
    task_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("tasks.id", ondelete="SET NULL"), nullable=True, index=True
    )
    start_time: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    end_time: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    duration_minutes: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    session_type: Mapped[str] = mapped_column(
        String(30), nullable=False, default="focused"
    )
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    student: Mapped["Student"] = relationship("Student", back_populates="study_sessions")
    subject: Mapped["Subject"] = relationship("Subject", back_populates="study_sessions")
    topic: Mapped["Topic"] = relationship("Topic", back_populates="study_sessions")
    task: Mapped[Optional["Task"]] = relationship("Task", back_populates="study_sessions")

    @validates("session_type")
    def _validate_session_type(self, _key: str, value: str) -> str:
        if value not in VALID_SESSION_TYPES:
            raise ValueError(f"session_type must be one of {VALID_SESSION_TYPES}")
        return value

    @validates("duration_minutes")
    def _validate_duration(self, _key: str, value: Optional[int]) -> Optional[int]:
        if value is not None and value <= 0:
            raise ValueError("duration_minutes must be greater than 0.")
        return value

    def __repr__(self) -> str:
        return (
            f"<StudySession id={self.id} type={self.session_type!r} "
            f"duration={self.duration_minutes}m>"
        )


# ===========================================================================
# 6. Exams
# ===========================================================================
class Exam(Base):
    """Tracks upcoming or completed exams and scores for a subject."""

    __tablename__ = "exams"
    __table_args__ = (
        CheckConstraint("total_marks > 0", name="ck_exam_total_marks_positive"),
        CheckConstraint(
            "obtained_marks IS NULL OR (obtained_marks >= 0 AND obtained_marks <= total_marks)",
            name="ck_exam_obtained_marks_valid",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("students.id", ondelete="CASCADE"), nullable=False, index=True
    )
    subject_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("subjects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    exam_name: Mapped[str] = mapped_column(String(150), nullable=False)
    exam_date: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    total_marks: Mapped[float] = mapped_column(Float, nullable=False)
    obtained_marks: Mapped[Optional[float]] = mapped_column(Float, nullable=True)

    student: Mapped["Student"] = relationship("Student", back_populates="exams")
    subject: Mapped["Subject"] = relationship("Subject", back_populates="exams")

    @property
    def percentage(self) -> Optional[float]:
        """Calculate score percentage once obtained_marks is recorded."""
        if self.obtained_marks is None or not self.total_marks:
            return None
        return round((self.obtained_marks / self.total_marks) * 100, 2)

    def __repr__(self) -> str:
        return f"<Exam id={self.id} name={self.exam_name!r} date={self.exam_date}>"


# ===========================================================================
# 7. Revision_Schedules
# ===========================================================================
class RevisionSchedule(Base):
    """Stores spaced-repetition revision checkpoints for a topic."""

    __tablename__ = "revision_schedules"
    __table_args__ = (
        UniqueConstraint(
            "student_id",
            "topic_id",
            "revision_number",
            name="uq_revision_student_topic_num",
        ),
        CheckConstraint("revision_number >= 1", name="ck_revision_number_positive"),
        CheckConstraint(
            "status IN ('scheduled', 'completed', 'missed', 'rescheduled')",
            name="ck_revision_status",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("students.id", ondelete="CASCADE"), nullable=False, index=True
    )
    topic_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("topics.id", ondelete="CASCADE"), nullable=False, index=True
    )
    scheduled_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    revision_number: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="scheduled"
    )
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    student: Mapped["Student"] = relationship(
        "Student", back_populates="revision_schedules"
    )
    topic: Mapped["Topic"] = relationship("Topic", back_populates="revision_schedules")

    @validates("status")
    def _validate_status(self, _key: str, value: str) -> str:
        if value not in VALID_REVISION_STATUSES:
            raise ValueError(f"status must be one of {VALID_REVISION_STATUSES}")
        return value

    def __repr__(self) -> str:
        return (
            f"<RevisionSchedule id={self.id} topic_id={self.topic_id} "
            f"rev={self.revision_number} status={self.status!r}>"
        )


# ===========================================================================
# 8. Daily_Goals
# ===========================================================================
class DailyGoal(Base):
    """Tracks a student's daily study minutes and task completion targets."""

    __tablename__ = "daily_goals"
    __table_args__ = (
        UniqueConstraint("student_id", "goal_date", name="uq_daily_goal_student_date"),
        CheckConstraint("target_minutes >= 0", name="ck_goal_target_minutes"),
        CheckConstraint("completed_minutes >= 0", name="ck_goal_completed_minutes"),
        CheckConstraint("target_tasks >= 0", name="ck_goal_target_tasks"),
        CheckConstraint("completed_tasks >= 0", name="ck_goal_completed_tasks"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("students.id", ondelete="CASCADE"), nullable=False, index=True
    )
    goal_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    target_minutes: Mapped[int] = mapped_column(Integer, nullable=False, default=120)
    completed_minutes: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    target_tasks: Mapped[int] = mapped_column(Integer, nullable=False, default=3)
    completed_tasks: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    student: Mapped["Student"] = relationship("Student", back_populates="daily_goals")

    def __repr__(self) -> str:
        return (
            f"<DailyGoal id={self.id} date={self.goal_date} "
            f"minutes={self.completed_minutes}/{self.target_minutes}>"
        )


# ===========================================================================
# 9. Notes
# ===========================================================================
class Note(Base):
    """Stores rich study notes and optional external resource links."""

    __tablename__ = "notes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("students.id", ondelete="CASCADE"), nullable=False, index=True
    )
    subject_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("subjects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    topic_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("topics.id", ondelete="CASCADE"), nullable=False, index=True
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    resource_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utc_now, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utc_now, onupdate=utc_now, nullable=False
    )

    student: Mapped["Student"] = relationship("Student", back_populates="notes")
    subject: Mapped["Subject"] = relationship("Subject", back_populates="notes")
    topic: Mapped["Topic"] = relationship("Topic", back_populates="study_notes")

    @validates("resource_url")
    def _validate_resource_url(self, _key: str, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        cleaned = value.strip()
        if not cleaned:
            return None
        if not (cleaned.startswith("http://") or cleaned.startswith("https://")):
            raise ValueError("resource_url must start with 'http://' or 'https://'.")
        return cleaned

    def __repr__(self) -> str:
        return f"<Note id={self.id} title={self.title!r}>"


# ===========================================================================
# 10. User_Settings
# ===========================================================================
class UserSetting(Base):
    """Stores per-student study timer and UI preferences (1-to-1 with Student)."""

    __tablename__ = "user_settings"
    __table_args__ = (
        CheckConstraint(
            "daily_study_target > 0 AND daily_study_target <= 1440",
            name="ck_settings_daily_target_range",
        ),
        CheckConstraint(
            "pomodoro_duration >= 5 AND pomodoro_duration <= 180",
            name="ck_settings_pomodoro_range",
        ),
        CheckConstraint(
            "break_duration >= 1 AND break_duration <= 60",
            name="ck_settings_break_range",
        ),
        CheckConstraint(
            "theme IN ('light', 'dark', 'system')",
            name="ck_settings_theme",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("students.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
        index=True,
    )
    daily_study_target: Mapped[int] = mapped_column(Integer, nullable=False, default=120)
    pomodoro_duration: Mapped[int] = mapped_column(Integer, nullable=False, default=25)
    break_duration: Mapped[int] = mapped_column(Integer, nullable=False, default=5)
    theme: Mapped[str] = mapped_column(String(20), nullable=False, default="light")

    student: Mapped["Student"] = relationship("Student", back_populates="settings")

    @validates("theme")
    def _validate_theme(self, _key: str, value: str) -> str:
        if value not in VALID_THEMES:
            raise ValueError(f"theme must be one of {VALID_THEMES}")
        return value

    def __repr__(self) -> str:
        return (
            f"<UserSetting student_id={self.student_id} "
            f"pomodoro={self.pomodoro_duration}m theme={self.theme!r}>"
        )
