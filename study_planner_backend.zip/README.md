# Study Planner and Task Tracker — Flask REST API Backend

Modular, beginner-friendly Flask + SQLAlchemy + SQLite backend organized into Blueprints (HTTP routes) and Services (business logic).

## Project Structure

```text
.
├── .env.example
├── requirements.txt
├── run.py
└── backend/
    ├── __init__.py
    ├── app/
    │   ├── __init__.py          # create_app() factory + /api/health
    │   ├── config.py            # Development, Testing, Production configs
    │   ├── extensions.py        # Flask-CORS setup
    │   ├── models/              # Re-exports all 10 ORM models
    │   ├── routes/              # 14 Flask Blueprints (HTTP only)
    │   ├── services/            # 14 Business-logic service modules
    │   └── utils/               # Auth tokens, serializers, validators, error handlers
    ├── database/
    │   ├── __init__.py
    │   ├── db.py                # SQLAlchemy engine, SQLite FK pragma, sessions
    │   ├── models.py            # 10 normalized SQLAlchemy ORM models
    │   ├── init_db.py           # CLI script to initialize/reset tables
    │   └── seed.py              # CLI script to populate sample data
    └── tests/
        ├── conftest.py          # Isolated in-memory SQLite fixtures
        └── test_api_end_to_end.py
```

## Quick Start

```bash
# 1. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate          # Windows PowerShell: venv\Scripts\Activate.ps1

# 2. Install dependencies
pip install -r requirements.txt

# 3. Copy environment template
cp .env.example .env

# 4. Initialize SQLite database & insert sample data
python -m backend.database.init_db
python -m backend.database.seed

# 5. Run the automated API test suite
pytest -v

# 6. Start the Flask development server
python run.py
```

## API Route Prefixes

| Blueprint | Prefix | Key Capabilities |
| :--- | :--- | :--- |
| Auth | `/api/auth` | Register, Login, Logout, Profile (`/me`) |
| Dashboard | `/api/dashboard` | Study/task/topic totals, overdue count, study time, upcoming exams & deadlines |
| Subjects | `/api/subjects` | CRUD + subject-wise statistics (`/stats`) |
| Topics | `/api/topics` | CRUD + syllabus coverage report (`/coverage`) |
| Tasks | `/api/tasks` | CRUD, filters (`date`, `subject_id`, `status`, `priority`, `overdue`), complete/pending |
| Study Sessions | `/api/study-sessions` | Start/end live timer, manual save, active session, daily/weekly/subject/topic summary |
| Revisions | `/api/revisions` | CRUD, today/overdue lists, configurable spaced-repetition `/auto-schedule`, complete |
| Exams | `/api/exams` | CRUD, upcoming countdown (`days_remaining`), score saving & percentages |
| Notes | `/api/notes` | CRUD linked to subjects/topics, resource URLs, keyword search (`?q=`) |
| Daily Goals | `/api/goals` | Set/track daily minutes & tasks, `/today`, `/settings` |
| Weak Topics | `/api/weak-topics` | Transparent rule-based weighted scoring + custom weights (`POST /analyze`) |
| Backlog Planner | `/api/backlog` | Non-destructive day-by-day `/recovery-plan` with configurable daily study cap |
| Analytics | `/api/analytics` | Daily/weekly/monthly stats, streaks, exam history, completion rates, trends |
| Recommendations | `/api/recommendations` | Rule-based next topic, tasks, weak topics to revise, backlog & exam priorities |
