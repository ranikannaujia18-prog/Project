"""Sample development data seeder.

Populates the SQLite database with realistic sample records across all 10
tables so you can test queries, relationships, and Flask endpoints immediately.

Usage (from project root):
    python -m backend.database.seed
"""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

from backend.database.db import get_db
from backend.database.init_db import init_db
from backend.database.models import (
    DailyGoal,
    Exam,
    Note,
    RevisionSchedule,
    Student,
    StudySession,
    Subject,
    Task,
    Topic,
    UserSetting,
)


def seed_database() -> None:
    """Insert sample data if the demo student does not already exist."""
    # Ensure tables exist before inserting data
    init_db(reset=False)

    demo_email = "aarav.sharma@college.edu"

    with get_db() as db:
        existing = db.query(Student).filter_by(email=demo_email).first()
        if existing:
            print(f"Sample data already exists for {demo_email}. Skipping seed.")
            return

        now = datetime.now(timezone.utc)
        today = date.today()

        # -------------------------------------------------------------------
        # 1. Student (password is hashed, never stored in plaintext)
        # -------------------------------------------------------------------
        student = Student(name="Aarav Sharma", email=demo_email)
        student.set_password("StudyPass123!")
        db.add(student)
        db.flush()  # Assigns student.id without committing yet

        # -------------------------------------------------------------------
        # 2. User Settings (1-to-1 with Student)
        # -------------------------------------------------------------------
        settings = UserSetting(
            student_id=student.id,
            daily_study_target=180,
            pomodoro_duration=25,
            break_duration=5,
            theme="dark",
        )
        db.add(settings)

        # -------------------------------------------------------------------
        # 3. Subjects
        # -------------------------------------------------------------------
        dbms = Subject(
            student_id=student.id,
            subject_name="Database Management Systems",
            subject_code="CS301",
            color="#2563EB",
            description="Relational modeling, SQL, indexing, and transactions.",
        )
        dsa = Subject(
            student_id=student.id,
            subject_name="Data Structures & Algorithms",
            subject_code="CS204",
            color="#059669",
            description="Trees, graphs, dynamic programming, and complexity.",
        )
        os_sub = Subject(
            student_id=student.id,
            subject_name="Operating Systems",
            subject_code="CS305",
            color="#D97706",
            description="Processes, threads, scheduling, and virtual memory.",
        )
        db.add_all([dbms, dsa, os_sub])
        db.flush()

        # -------------------------------------------------------------------
        # 4. Topics
        # -------------------------------------------------------------------
        t_norm = Topic(
            subject_id=dbms.id,
            topic_name="Normalization (1NF to BCNF)",
            difficulty_level="medium",
            status="completed",
            confidence_level=4,
            completion_percentage=100.0,
            last_revised_at=now - timedelta(days=2),
            notes="Practice functional dependency closure problems.",
        )
        t_index = Topic(
            subject_id=dbms.id,
            topic_name="B+ Trees and Indexing",
            difficulty_level="hard",
            status="in_progress",
            confidence_level=3,
            completion_percentage=60.0,
            last_revised_at=now - timedelta(days=1),
            notes="Review node splitting during insertions.",
        )
        t_graphs = Topic(
            subject_id=dsa.id,
            topic_name="Graph Traversals (BFS & DFS)",
            difficulty_level="medium",
            status="in_progress",
            confidence_level=4,
            completion_percentage=75.0,
            last_revised_at=now - timedelta(days=3),
            notes="Focus on cycle detection in directed graphs.",
        )
        t_sched = Topic(
            subject_id=os_sub.id,
            topic_name="CPU Scheduling Algorithms",
            difficulty_level="easy",
            status="not_started",
            confidence_level=2,
            completion_percentage=0.0,
            notes="Compare Round Robin, SJF, and Priority Scheduling.",
        )
        db.add_all([t_norm, t_index, t_graphs, t_sched])
        db.flush()

        # -------------------------------------------------------------------
        # 5. Tasks (demonstrates both linked topic_id and nullable topic_id)
        # -------------------------------------------------------------------
        task_1 = Task(
            student_id=student.id,
            subject_id=dbms.id,
            topic_id=t_index.id,
            title="Solve 5 B+ Tree insertion & deletion exercises",
            description="Complete worksheet questions 1 through 5 from lab sheet 4.",
            priority="high",
            status="in_progress",
            due_date=now + timedelta(days=2),
            estimated_minutes=60,
            actual_minutes=25,
        )
        task_2 = Task(
            student_id=student.id,
            subject_id=dsa.id,
            topic_id=t_graphs.id,
            title="Implement Dijkstra's shortest path in Python",
            description="Use heapq for the priority queue and test on weighted graphs.",
            priority="urgent",
            status="pending",
            due_date=now + timedelta(days=1),
            estimated_minutes=45,
            actual_minutes=0,
        )
        task_3 = Task(
            student_id=student.id,
            subject_id=os_sub.id,
            topic_id=None,  # General subject task not tied to a single topic
            title="Download Operating Systems midterm syllabus",
            description="Check the course portal for updated chapter weightage.",
            priority="low",
            status="completed",
            due_date=now - timedelta(days=1),
            estimated_minutes=15,
            actual_minutes=10,
            completed_at=now - timedelta(hours=18),
        )
        db.add_all([task_1, task_2, task_3])
        db.flush()

        # -------------------------------------------------------------------
        # 6. Study Sessions (one linked to a task, one standalone revision)
        # -------------------------------------------------------------------
        session_1 = StudySession(
            student_id=student.id,
            subject_id=dbms.id,
            topic_id=t_index.id,
            task_id=task_1.id,
            start_time=now - timedelta(hours=3),
            end_time=now - timedelta(hours=2, minutes=35),
            duration_minutes=25,
            session_type="pomodoro",
            notes="Finished first two B+ Tree insertion diagrams.",
        )
        session_2 = StudySession(
            student_id=student.id,
            subject_id=dbms.id,
            topic_id=t_norm.id,
            task_id=None,
            start_time=now - timedelta(hours=2),
            end_time=now - timedelta(hours=1, minutes=15),
            duration_minutes=45,
            session_type="revision",
            notes="Revised BCNF decomposition rules using past exam paper.",
        )
        db.add_all([session_1, session_2])

        # -------------------------------------------------------------------
        # 7. Exams (one completed with marks, one upcoming)
        # -------------------------------------------------------------------
        exam_1 = Exam(
            student_id=student.id,
            subject_id=dbms.id,
            exam_name="DBMS Quiz 1",
            exam_date=now - timedelta(days=10),
            total_marks=25.0,
            obtained_marks=22.5,
        )
        exam_2 = Exam(
            student_id=student.id,
            subject_id=dsa.id,
            exam_name="DSA Midterm Exam",
            exam_date=now + timedelta(days=14),
            total_marks=100.0,
            obtained_marks=None,
        )
        db.add_all([exam_1, exam_2])

        # -------------------------------------------------------------------
        # 8. Revision Schedules
        # -------------------------------------------------------------------
        rev_1 = RevisionSchedule(
            student_id=student.id,
            topic_id=t_norm.id,
            scheduled_date=today - timedelta(days=2),
            revision_number=1,
            status="completed",
            notes="All normal forms clear; confident on lossless joins.",
        )
        rev_2 = RevisionSchedule(
            student_id=student.id,
            topic_id=t_norm.id,
            scheduled_date=today + timedelta(days=5),
            revision_number=2,
            status="scheduled",
            notes="Quick 15-minute spaced-repetition review before midterm.",
        )
        rev_3 = RevisionSchedule(
            student_id=student.id,
            topic_id=t_index.id,
            scheduled_date=today + timedelta(days=2),
            revision_number=1,
            status="scheduled",
            notes="Re-draw B+ tree deletion underflow cases.",
        )
        db.add_all([rev_1, rev_2, rev_3])

        # -------------------------------------------------------------------
        # 9. Daily Goals
        # -------------------------------------------------------------------
        goal_yesterday = DailyGoal(
            student_id=student.id,
            goal_date=today - timedelta(days=1),
            target_minutes=150,
            completed_minutes=165,
            target_tasks=3,
            completed_tasks=3,
        )
        goal_today = DailyGoal(
            student_id=student.id,
            goal_date=today,
            target_minutes=180,
            completed_minutes=70,
            target_tasks=4,
            completed_tasks=1,
        )
        db.add_all([goal_yesterday, goal_today])

        # -------------------------------------------------------------------
        # 10. Notes
        # -------------------------------------------------------------------
        note_1 = Note(
            student_id=student.id,
            subject_id=dbms.id,
            topic_id=t_norm.id,
            title="Quick Checklist for 3NF vs BCNF",
            content=(
                "A relation is in BCNF if for every non-trivial functional "
                "dependency X -> Y, X is a superkey. 3NF relaxes this when Y "
                "is a prime attribute."
            ),
            resource_url="https://www.postgresql.org/docs/current/ddl.html",
        )
        note_2 = Note(
            student_id=student.id,
            subject_id=dsa.id,
            topic_id=t_graphs.id,
            title="BFS vs DFS Complexity Summary",
            content=(
                "Both BFS and DFS run in O(V + E) time using adjacency lists. "
                "Use BFS for unweighted shortest paths and DFS for topological sort."
            ),
            resource_url=None,
        )
        db.add_all([note_1, note_2])

    print("Sample data inserted successfully for Aarav Sharma (aarav.sharma@college.edu).")


if __name__ == "__main__":
    seed_database()
