"""Database package for the Study Planner and Task Tracker application.

Exports the core database helpers and ORM models so other parts of the
Flask backend (such as routes or services) can import them cleanly:

    from backend.database import SessionLocal, init_app, Student, Task
"""

from backend.database.db import (
    Base,
    DATABASE_PATH,
    DATABASE_URL,
    SessionLocal,
    engine,
    get_db,
    get_session,
    init_app,
)
from backend.database.models import (
    DailyGoal,
    Exam,
    Note,
    RevisionSchedule,
    Student,
    StudySession,
    Subject,
    Task,
    Topic,
    UserSetting,
)

__all__ = [
    # Database configuration & session helpers
    "Base",
    "DATABASE_PATH",
    "DATABASE_URL",
    "engine",
    "SessionLocal",
    "get_db",
    "get_session",
    "init_app",
    # ORM models
    "Student",
    "Subject",
    "Topic",
    "Task",
    "StudySession",
    "Exam",
    "RevisionSchedule",
    "DailyGoal",
    "Note",
    "UserSetting",
]
