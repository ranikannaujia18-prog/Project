"""Database engine, session management, and Flask integration.

This module centralizes all SQLAlchemy + SQLite configuration so that both
standalone scripts (init_db.py, seed.py) and a Flask application can share
the exact same database setup.
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Session, scoped_session, sessionmaker

# ---------------------------------------------------------------------------
# Database location & URL
# ---------------------------------------------------------------------------
# Default SQLite file lives at: backend/database/study_planner.db
# Override with the DATABASE_URL environment variable for testing or deployment.
BASE_DIR = Path(__file__).resolve().parent
DATABASE_PATH = BASE_DIR / "study_planner.db"
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{DATABASE_PATH}")


# ---------------------------------------------------------------------------
# Declarative Base for all ORM models
# ---------------------------------------------------------------------------
class Base(DeclarativeBase):
    """Base class that every SQLAlchemy model inherits from."""


# ---------------------------------------------------------------------------
# Engine configuration
# ---------------------------------------------------------------------------
_connect_args: dict[str, object] = {}
if DATABASE_URL.startswith("sqlite"):
    # Flask handles requests across threads; check_same_thread=False allows
    # SQLAlchemy's scoped_session to safely use SQLite connections per request.
    _connect_args["check_same_thread"] = False

engine = create_engine(
    DATABASE_URL,
    echo=os.getenv("SQLALCHEMY_ECHO", "false").lower() == "true",
    future=True,
    connect_args=_connect_args,
)


@event.listens_for(Engine, "connect")
def _enable_sqlite_foreign_keys(dbapi_connection, _connection_record) -> None:
    """Turn on SQLite foreign key enforcement for every new connection.

    SQLite disables foreign key checks by default for backwards compatibility.
    Without this PRAGMA, ON DELETE CASCADE and ON DELETE SET NULL rules
    defined on ForeignKey columns would be silently ignored.
    """
    if DATABASE_URL.startswith("sqlite"):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()


# ---------------------------------------------------------------------------
# Session factory (thread-safe scoped_session for Flask compatibility)
# ---------------------------------------------------------------------------
_session_factory = sessionmaker(
    bind=engine,
    autoflush=False,
    autocommit=False,
    expire_on_commit=False,
)

# Use SessionLocal() inside Flask routes; call SessionLocal.remove() on teardown.
SessionLocal = scoped_session(_session_factory)


def get_session() -> Session:
    """Return the current thread/request-scoped SQLAlchemy session."""
    return SessionLocal()


@contextmanager
def get_db() -> Generator[Session, None, None]:
    """Context manager for safe database transactions in scripts or services.

    Commits automatically if no exception occurs, rolls back on any error,
    and always closes the session.

    Example:
        with get_db() as db:
            student = db.query(Student).filter_by(email="a@example.com").first()
    """
    session = _session_factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Flask integration helper
# ---------------------------------------------------------------------------
def init_app(app) -> None:
    """Attach database teardown handling to a Flask application instance.

    Call this once inside your Flask app factory (e.g., create_app()):

        from flask import Flask
        from backend.database import init_app

        app = Flask(__name__)
        init_app(app)

    This guarantees the scoped session is cleaned up after every HTTP request,
    preventing leaked connections or stale transactions.
    """
    app.config.setdefault("DATABASE_URL", DATABASE_URL)

    @app.teardown_appcontext
    def _shutdown_session(_exception=None) -> None:
        SessionLocal.remove()
