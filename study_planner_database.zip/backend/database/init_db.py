"""Database initialization script.

Creates all tables defined in backend/database/models.py inside the configured
SQLite database.

Usage (from project root):
    python -m backend.database.init_db
    python -m backend.database.init_db --reset   # Drops and recreates all tables
"""

from __future__ import annotations

import argparse

from sqlalchemy import inspect

# Importing models registers every table on Base.metadata before create_all()
from backend.database import models  # noqa: F401
from backend.database.db import Base, DATABASE_URL, engine


def init_db(reset: bool = False) -> list[str]:
    """Initialize the database schema and return the list of created tables.

    Args:
        reset: If True, drops all existing tables before recreating them.
               Useful during local development; avoid in production.
    """
    if reset:
        print("Dropping existing tables...")
        Base.metadata.drop_all(bind=engine)

    Base.metadata.create_all(bind=engine)

    inspector = inspect(engine)
    tables = sorted(inspector.get_table_names())
    return tables


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Initialize the Study Planner and Task Tracker SQLite database."
    )
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Drop all existing tables before recreating them (destructive).",
    )
    args = parser.parse_args()

    tables = init_db(reset=args.reset)
    print(f"Database initialized at: {DATABASE_URL}")
    print(f"Tables ready ({len(tables)}): {', '.join(tables)}")


if __name__ == "__main__":
    main()
