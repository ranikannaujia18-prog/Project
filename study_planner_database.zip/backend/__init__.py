"""Backend package for the Study Planner and Task Tracker application."""
