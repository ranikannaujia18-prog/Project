# Study Planner and Task Tracker — Database Layer

Modular, normalized SQLite + SQLAlchemy 2.0 database layer designed to plug directly into a Flask backend.

## Folder Structure

```text
.
├── requirements.txt
└── backend/
    ├── __init__.py
    └── database/
        ├── __init__.py   # Public package exports (engine, SessionLocal, models)
        ├── db.py         # SQLAlchemy engine, SQLite FK pragma, sessions, Flask init_app
        ├── models.py     # All 10 normalized ORM models, constraints, and validations
        ├── init_db.py    # CLI script to create or reset database tables
        └── seed.py       # CLI script to insert sample development data
```

## Quick Start

1. **Create and activate a virtual environment** (recommended):

   ```bash
   python -m venv venv
   # macOS / Linux:
   source venv/bin/activate
   # Windows (PowerShell):
   venv\Scripts\Activate.ps1
   ```

2. **Install dependencies**:

   ```bash
   pip install -r requirements.txt
   ```

3. **Initialize the SQLite database**:

   ```bash
   python -m backend.database.init_db
   ```

   To drop and recreate all tables from scratch during development:

   ```bash
   python -m backend.database.init_db --reset
   ```

4. **Insert sample development data**:

   ```bash
   python -m backend.database.seed
   ```

## Connecting to Flask Later

```python
from flask import Flask
from backend.database import SessionLocal, Student, init_app

app = Flask(__name__)
init_app(app)

@app.get("/students")
def list_students():
    students = SessionLocal.query(Student).all()
    return [{"id": s.id, "name": s.name, "email": s.email} for s in students]
```
