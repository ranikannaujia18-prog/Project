/**
 * Centralized API service layer mapped 1-to-1 to the 14 Flask Blueprints.
 * Every function unwraps the backend's { status, message, data } envelope.
 */
import apiClient from "./apiClient";

const unwrap = (promise) => promise.then((res) => res.data?.data);

export const authApi = {
  register: (payload) => unwrap(apiClient.post("/api/auth/register", payload)),
  login: (payload) => unwrap(apiClient.post("/api/auth/login", payload)),
  logout: () => unwrap(apiClient.post("/api/auth/logout")),
  me: () => unwrap(apiClient.get("/api/auth/me")),
};

export const dashboardApi = {
  getSummary: () => unwrap(apiClient.get("/api/dashboard")),
};

export const subjectsApi = {
  list: () => unwrap(apiClient.get("/api/subjects")),
  listWithStats: () => unwrap(apiClient.get("/api/subjects/stats")),
  getStats: (id) => unwrap(apiClient.get(`/api/subjects/${id}/stats`)),
  create: (payload) => unwrap(apiClient.post("/api/subjects", payload)),
  update: (id, payload) => unwrap(apiClient.put(`/api/subjects/${id}`, payload)),
  remove: (id) => unwrap(apiClient.delete(`/api/subjects/${id}`)),
};

export const topicsApi = {
  list: (params) => unwrap(apiClient.get("/api/topics", { params })),
  coverage: (params) => unwrap(apiClient.get("/api/topics/coverage", { params })),
  create: (payload) => unwrap(apiClient.post("/api/topics", payload)),
  update: (id, payload) => unwrap(apiClient.put(`/api/topics/${id}`, payload)),
  remove: (id) => unwrap(apiClient.delete(`/api/topics/${id}`)),
};

export const tasksApi = {
  list: (params) => unwrap(apiClient.get("/api/tasks", { params })),
  overdue: () => unwrap(apiClient.get("/api/tasks/overdue")),
  create: (payload) => unwrap(apiClient.post("/api/tasks", payload)),
  update: (id, payload) => unwrap(apiClient.put(`/api/tasks/${id}`, payload)),
  markComplete: (id, actualMinutes) =>
    unwrap(
      apiClient.patch(
        `/api/tasks/${id}/complete`,
        actualMinutes !== undefined ? { actual_minutes: actualMinutes } : {}
      )
    ),
  markPending: (id) => unwrap(apiClient.patch(`/api/tasks/${id}/pending`)),
  remove: (id) => unwrap(apiClient.delete(`/api/tasks/${id}`)),
};

export const studySessionsApi = {
  start: (payload) => unwrap(apiClient.post("/api/study-sessions/start", payload)),
  end: (id, payload = {}) => unwrap(apiClient.post(`/api/study-sessions/${id}/end`, payload)),
  saveManual: (payload) => unwrap(apiClient.post("/api/study-sessions", payload)),
  list: (params) => unwrap(apiClient.get("/api/study-sessions", { params })),
  active: () => unwrap(apiClient.get("/api/study-sessions/active")),
  summary: () => unwrap(apiClient.get("/api/study-sessions/summary")),
};

export const revisionsApi = {
  list: (params) => unwrap(apiClient.get("/api/revisions", { params })),
  today: () => unwrap(apiClient.get("/api/revisions/today")),
  overdue: () => unwrap(apiClient.get("/api/revisions/overdue")),
  create: (payload) => unwrap(apiClient.post("/api/revisions", payload)),
  autoSchedule: (payload) => unwrap(apiClient.post("/api/revisions/auto-schedule", payload)),
  update: (id, payload) => unwrap(apiClient.put(`/api/revisions/${id}`, payload)),
  complete: (id, notes) =>
    unwrap(apiClient.patch(`/api/revisions/${id}/complete`, notes ? { notes } : {})),
  remove: (id) => unwrap(apiClient.delete(`/api/revisions/${id}`)),
};

export const examsApi = {
  list: (params) => unwrap(apiClient.get("/api/exams", { params })),
  upcoming: () => unwrap(apiClient.get("/api/exams/upcoming")),
  create: (payload) => unwrap(apiClient.post("/api/exams", payload)),
  update: (id, payload) => unwrap(apiClient.put(`/api/exams/${id}`, payload)),
  saveScore: (id, obtainedMarks) =>
    unwrap(apiClient.patch(`/api/exams/${id}/score`, { obtained_marks: obtainedMarks })),
  remove: (id) => unwrap(apiClient.delete(`/api/exams/${id}`)),
};

export const notesApi = {
  list: (params) => unwrap(apiClient.get("/api/notes", { params })),
  create: (payload) => unwrap(apiClient.post("/api/notes", payload)),
  update: (id, payload) => unwrap(apiClient.put(`/api/notes/${id}`, payload)),
  remove: (id) => unwrap(apiClient.delete(`/api/notes/${id}`)),
};

export const goalsApi = {
  today: () => unwrap(apiClient.get("/api/goals/today")),
  list: (params) => unwrap(apiClient.get("/api/goals", { params })),
  saveGoal: (payload) => unwrap(apiClient.post("/api/goals", payload)),
  updateGoal: (id, payload) => unwrap(apiClient.put(`/api/goals/${id}`, payload)),
  updateSettings: (payload) => unwrap(apiClient.put("/api/goals/settings", payload)),
};

export const weakTopicsApi = {
  get: (params) => unwrap(apiClient.get("/api/weak-topics", { params })),
  analyze: (payload) => unwrap(apiClient.post("/api/weak-topics/analyze", payload)),
};

export const backlogApi = {
  getPlan: (params) => unwrap(apiClient.get("/api/backlog/recovery-plan", { params })),
  generatePlan: (payload) => unwrap(apiClient.post("/api/backlog/recovery-plan", payload)),
};

export const analyticsApi = {
  get: () => unwrap(apiClient.get("/api/analytics")),
};

export const recommendationsApi = {
  get: () => unwrap(apiClient.get("/api/recommendations")),
};
