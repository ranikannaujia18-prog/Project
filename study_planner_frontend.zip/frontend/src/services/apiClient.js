import axios from "axios";

// Configurable Flask API base URL (set VITE_API_BASE_URL in .env)
export const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:5000";

export const TOKEN_STORAGE_KEY = "study_planner_token";

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 15000,
});

// Attach Bearer token automatically to every outgoing request
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_STORAGE_KEY);
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Normalize API errors so pages always receive a clear message string
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error.response?.status;
    const serverMsg = error.response?.data?.message;

    if (status === 401 && localStorage.getItem(TOKEN_STORAGE_KEY)) {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
      window.dispatchEvent(new Event("auth:unauthorized"));
    }

    const message =
      serverMsg ||
      (error.code === "ERR_NETWORK"
        ? "Cannot reach the Flask backend. Make sure 'python run.py' is running."
        : "Something went wrong while communicating with the server.");

    return Promise.reject(new Error(message));
  }
);

export default apiClient;
