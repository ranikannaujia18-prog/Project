import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { TOKEN_STORAGE_KEY } from "../services/apiClient";
import { authApi } from "../services/studyApi";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [student, setStudent] = useState(null);
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async () => {
    const token = localStorage.getItem(TOKEN_STORAGE_KEY);
    if (!token) {
      setLoading(false);
      return;
    }
    try {
      const data = await authApi.me();
      setStudent(data.student);
      setSettings(data.settings);
    } catch {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
      setStudent(null);
      setSettings(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProfile();
    const handleUnauthorized = () => {
      setStudent(null);
      setSettings(null);
    };
    window.addEventListener("auth:unauthorized", handleUnauthorized);
    return () => window.removeEventListener("auth:unauthorized", handleUnauthorized);
  }, [loadProfile]);

  const login = async (email, password) => {
    const data = await authApi.login({ email, password });
    localStorage.setItem(TOKEN_STORAGE_KEY, data.token);
    setStudent(data.student);
    const profile = await authApi.me();
    setSettings(profile.settings);
    return data;
  };

  const register = async (name, email, password) => {
    const data = await authApi.register({ name, email, password });
    localStorage.setItem(TOKEN_STORAGE_KEY, data.token);
    setStudent(data.student);
    setSettings(data.settings);
    return data;
  };

  const logout = async () => {
    try {
      await authApi.logout();
    } catch {
      // Clear local session even if server token already expired
    } finally {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
      setStudent(null);
      setSettings(null);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        student,
        settings,
        setSettings,
        loading,
        isAuthenticated: Boolean(student),
        login,
        register,
        logout,
        refreshProfile: loadProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
