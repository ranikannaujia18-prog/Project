export function formatMinutes(minutes) {
  const mins = Number(minutes) || 0;
  if (mins < 60) return `${mins}m`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m ? `${h}h ${m}m` : `${h}h`;
}

export function formatDate(isoString) {
  if (!isoString) return "—";
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return isoString;
  return d.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function formatDateTime(isoString) {
  if (!isoString) return "—";
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return isoString;
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function todayIsoDate() {
  const now = new Date();
  const offset = now.getTimezoneOffset() * 60000;
  return new Date(now.getTime() - offset).toISOString().slice(0, 10);
}

export function toDatetimeLocalValue(isoString) {
  if (!isoString) return "";
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return "";
  const offset = d.getTimezoneOffset() * 60000;
  return new Date(d.getTime() - offset).toISOString().slice(0, 16);
}

export function priorityVariant(priority) {
  const map = {
    urgent: "danger",
    high: "warning",
    medium: "primary",
    low: "neutral",
  };
  return map[priority] || "neutral";
}

export function statusVariant(status) {
  const map = {
    completed: "success",
    in_progress: "info",
    pending: "warning",
    not_started: "neutral",
    scheduled: "primary",
    missed: "danger",
    rescheduled: "warning",
    cancelled: "neutral",
  };
  return map[status] || "neutral";
}

export function formatLabel(text) {
  return String(text || "").replace(/_/g, " ");
}
