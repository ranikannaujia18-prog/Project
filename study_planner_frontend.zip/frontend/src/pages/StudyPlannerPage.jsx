import { useMemo, useState } from "react";
import { CalendarDays, CheckCircle2, Circle, Pencil, Plus, Trash2 } from "lucide-react";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";
import EmptyState from "../components/ui/EmptyState";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import Modal from "../components/ui/Modal";
import { useToast } from "../context/ToastContext";
import { useApiData } from "../hooks/useApiData";
import { subjectsApi, tasksApi } from "../services/studyApi";
import {
  formatDate,
  formatMinutes,
  priorityVariant,
  todayIsoDate,
  toDatetimeLocalValue,
} from "../utils/formatters";

export default function StudyPlannerPage() {
  const [viewMode, setViewMode] = useState("daily");
  const [selectedDate, setSelectedDate] = useState(todayIsoDate());
  const [priorityFilter, setPriorityFilter] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [form, setForm] = useState({
    subject_id: "",
    title: "",
    description: "",
    priority: "medium",
    due_date: "",
    estimated_minutes: 30,
  });

  const { addToast } = useToast();

  const { data, loading, error, refetch } = useApiData(async () => {
    const [tasks, subjects] = await Promise.all([
      tasksApi.list({ sort: "priority" }),
      subjectsApi.list(),
    ]);
    return { tasks, subjects };
  }, []);

  const subjectMap = useMemo(() => {
    const map = {};
    (data?.subjects || []).forEach((s) => {
      map[s.id] = s;
    });
    return map;
  }, [data]);

  const weekDates = useMemo(() => {
    const base = new Date(`${selectedDate}T00:00:00`);
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(base);
      d.setDate(base.getDate() + i);
      return d.toISOString().slice(0, 10);
    });
  }, [selectedDate]);

  const filteredTasks = useMemo(() => {
    const all = data?.tasks || [];
    return all.filter((t) => {
      if (priorityFilter && t.priority !== priorityFilter) return false;
      if (!t.due_date) return false;
      const dueDay = t.due_date.slice(0, 10);
      if (viewMode === "daily") return dueDay === selectedDate;
      return weekDates.includes(dueDay);
    });
  }, [data, priorityFilter, viewMode, selectedDate, weekDates]);

  const openCreate = () => {
    setEditingTask(null);
    setForm({
      subject_id: data?.subjects?.[0]?.id || "",
      title: "",
      description: "",
      priority: "medium",
      due_date: `${selectedDate}T18:00`,
      estimated_minutes: 30,
    });
    setModalOpen(true);
  };

  const openEdit = (task) => {
    setEditingTask(task);
    setForm({
      subject_id: task.subject_id,
      title: task.title,
      description: task.description || "",
      priority: task.priority,
      due_date: toDatetimeLocalValue(task.due_date),
      estimated_minutes: task.estimated_minutes || 30,
    });
    setModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        ...form,
        subject_id: Number(form.subject_id),
        estimated_minutes: form.estimated_minutes ? Number(form.estimated_minutes) : null,
        due_date: form.due_date ? new Date(form.due_date).toISOString() : null,
      };
      if (editingTask) {
        await tasksApi.update(editingTask.id, payload);
        addToast("Planned task updated.", "success");
      } else {
        await tasksApi.create(payload);
        addToast("Task added to your study plan.", "success");
      }
      setModalOpen(false);
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  const toggleStatus = async (task) => {
    try {
      if (task.status === "completed") {
        await tasksApi.markPending(task.id);
      } else {
        await tasksApi.markComplete(task.id);
      }
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  const handleDelete = async (id) => {
    try {
      await tasksApi.remove(id);
      addToast("Task deleted.", "success");
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  if (loading) return <LoadingSpinner label="Loading study planner..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Study Planner</h1>
          <p className="page-subtitle">Switch between daily and 7-day weekly planning views.</p>
        </div>
        <Button onClick={openCreate} disabled={!data.subjects.length}>
          <Plus size={16} /> Add Planned Task
        </Button>
      </div>

      <div className="filter-bar">
        <div className="header-actions">
          <Button
            variant={viewMode === "daily" ? "primary" : "secondary"}
            size="sm"
            onClick={() => setViewMode("daily")}
          >
            Daily View
          </Button>
          <Button
            variant={viewMode === "weekly" ? "primary" : "secondary"}
            size="sm"
            onClick={() => setViewMode("weekly")}
          >
            Weekly View (7 Days)
          </Button>
        </div>

        <input
          type="date"
          className="form-control"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
        />

        <select
          className="form-control"
          value={priorityFilter}
          onChange={(e) => setPriorityFilter(e.target.value)}
        >
          <option value="">All Priorities</option>
          <option value="urgent">Urgent</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
      </div>

      {viewMode === "daily" ? (
        <Card title={`Tasks for ${formatDate(selectedDate)}`}>
          {filteredTasks.length === 0 ? (
            <EmptyState
              icon={CalendarDays}
              title="No tasks scheduled for this day"
              description="Add a task for this date or switch to Weekly View to inspect the rest of the week."
            />
          ) : (
            <div className="stack-list">
              {filteredTasks.map((task) => (
                <div key={task.id} className="list-row">
                  <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
                    <button
                      type="button"
                      className="btn btn-ghost btn-sm"
                      onClick={() => toggleStatus(task)}
                      aria-label="Toggle task completion"
                    >
                      {task.status === "completed" ? (
                        <CheckCircle2 size={18} color="var(--success)" />
                      ) : (
                        <Circle size={18} color="var(--text-muted)" />
                      )}
                    </button>
                    <div>
                      <div
                        style={{
                          fontWeight: 600,
                          textDecoration: task.status === "completed" ? "line-through" : "none",
                        }}
                      >
                        {task.title}
                      </div>
                      <div style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>
                        {subjectMap[task.subject_id]?.subject_name || "Subject"} · Est.{" "}
                        {formatMinutes(task.estimated_minutes || 0)}
                      </div>
                    </div>
                  </div>
                  <div className="header-actions">
                    <Badge variant={priorityVariant(task.priority)}>{task.priority}</Badge>
                    <Button variant="ghost" size="sm" onClick={() => openEdit(task)}>
                      <Pencil size={14} />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDelete(task.id)}>
                      <Trash2 size={14} color="var(--danger)" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      ) : (
        <div className="grid-3">
          {weekDates.map((dayStr) => {
            const dayTasks = filteredTasks.filter((t) => t.due_date?.slice(0, 10) === dayStr);
            return (
              <Card key={dayStr} title={formatDate(dayStr)} subtitle={`${dayTasks.length} task(s)`}>
                {dayTasks.length === 0 ? (
                  <p style={{ fontSize: "0.85rem", color: "var(--text-muted)" }}>Free day</p>
                ) : (
                  <div className="stack-list">
                    {dayTasks.map((task) => (
                      <div key={task.id} className="list-row" style={{ padding: "0.55rem 0.7rem" }}>
                        <div style={{ minWidth: 0 }}>
                          <div style={{ fontWeight: 500, fontSize: "0.86rem" }}>{task.title}</div>
                          <Badge variant={priorityVariant(task.priority)}>{task.priority}</Badge>
                        </div>
                        <button
                          type="button"
                          className="btn btn-ghost btn-sm"
                          onClick={() => toggleStatus(task)}
                        >
                          {task.status === "completed" ? (
                            <CheckCircle2 size={16} color="var(--success)" />
                          ) : (
                            <Circle size={16} />
                          )}
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingTask ? "Edit Planned Task" : "Add Planned Task"}
      >
        <form className="form-stack" onSubmit={handleSave}>
          <div className="form-group">
            <label className="form-label">Subject</label>
            <select
              className="form-control"
              value={form.subject_id}
              onChange={(e) => setForm({ ...form, subject_id: e.target.value })}
              required
            >
              {data.subjects.map((s) => (
                <option key={s.id} value={s.id}>{s.subject_name}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Task Title</label>
            <input
              className="form-control"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              required
            />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Priority</label>
              <select
                className="form-control"
                value={form.priority}
                onChange={(e) => setForm({ ...form, priority: e.target.value })}
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Estimated Minutes</label>
              <input
                type="number"
                min="5"
                className="form-control"
                value={form.estimated_minutes}
                onChange={(e) => setForm({ ...form, estimated_minutes: e.target.value })}
              />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Due Date & Time</label>
            <input
              type="datetime-local"
              className="form-control"
              value={form.due_date}
              onChange={(e) => setForm({ ...form, due_date: e.target.value })}
            />
          </div>
          <div className="modal-actions">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit">{editingTask ? "Update Task" : "Add Task"}</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
