import { AlertTriangle, CheckSquare, GraduationCap, History, Lightbulb } from "lucide-react";
import Badge from "../components/ui/Badge";
import Card from "../components/ui/Card";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import { useApiData } from "../hooks/useApiData";
import { recommendationsApi } from "../services/studyApi";
import { formatDate, formatMinutes, priorityVariant } from "../utils/formatters";

export default function RecommendationsPage() {
  const { data, loading, error, refetch } = useApiData(() => recommendationsApi.get(), []);

  if (loading) return <LoadingSpinner label="Generating rule-based recommendations..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Smart Recommendations</h1>
          <p className="page-subtitle">
            Deterministic recommendations calculated directly from your weakness scores, backlog, and upcoming exams.
          </p>
        </div>
      </div>

      <Card title="Study Next" action={<Lightbulb size={18} color="var(--primary)" />}>
        {data.next_topic_to_study ? (
          <div className="list-row">
            <div>
              <strong style={{ fontSize: "1.02rem" }}>{data.next_topic_to_study.topic_name}</strong>
              <div style={{ fontSize: "0.86rem", color: "var(--text-secondary)", marginTop: "0.2rem" }}>
                {data.next_topic_to_study.subject_name} · {data.next_topic_to_study.reason}
              </div>
            </div>
            <Badge variant="danger">Weakness {data.next_topic_to_study.weakness_score}</Badge>
          </div>
        ) : (
          <p className="empty-state" style={{ padding: "1rem" }}>Add syllabus topics to get your next study target.</p>
        )}
      </Card>

      <div className="grid-2" style={{ marginTop: "1.25rem" }}>
        <Card title="Tasks to Complete" action={<CheckSquare size={18} color="var(--primary)" />}>
          {data.tasks_to_complete.length === 0 ? (
            <p className="empty-state" style={{ padding: "1rem" }}>No pending tasks right now.</p>
          ) : (
            <div className="stack-list">
              {data.tasks_to_complete.map((t) => (
                <div key={t.id} className="list-row">
                  <div>
                    <div style={{ fontWeight: 600 }}>{t.title}</div>
                    <div style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>Due {formatDate(t.due_date)}</div>
                  </div>
                  <div className="header-actions">
                    {t.is_overdue && <Badge variant="danger">Overdue</Badge>}
                    <Badge variant={priorityVariant(t.priority)}>{t.priority}</Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card title="Weak Topics to Revise" action={<AlertTriangle size={18} color="var(--warning)" />}>
          {data.weak_topics_to_revise.length === 0 ? (
            <p className="empty-state" style={{ padding: "1rem" }}>No topics urgently needing revision.</p>
          ) : (
            <div className="stack-list">
              {data.weak_topics_to_revise.map((t) => (
                <div key={t.topic_id} className="list-row">
                  <div>
                    <div style={{ fontWeight: 600 }}>{t.topic_name}</div>
                    <div style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>{t.subject_name}</div>
                  </div>
                  <Badge variant="warning">Score {t.weakness_score}</Badge>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      <div className="grid-2">
        <Card title="Backlog to Recover Today" action={<History size={18} color="var(--danger)" />}>
          {data.backlog_to_recover.length === 0 ? (
            <p className="empty-state" style={{ padding: "1rem" }}>No backlog items scheduled for today.</p>
          ) : (
            <div className="stack-list">
              {data.backlog_to_recover.map((item, idx) => (
                <div key={idx} className="list-row">
                  <span>{item.title}</span>
                  <Badge variant="info">{formatMinutes(item.estimated_minutes)}</Badge>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card title="Upcoming Exams Needing Attention" action={<GraduationCap size={18} color="var(--info)" />}>
          {data.exams_needing_attention.length === 0 ? (
            <p className="empty-state" style={{ padding: "1rem" }}>No upcoming exams scheduled.</p>
          ) : (
            <div className="stack-list">
              {data.exams_needing_attention.map((exam) => (
                <div key={exam.id} className="list-row">
                  <div>
                    <div style={{ fontWeight: 600 }}>{exam.exam_name}</div>
                    <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)" }}>{exam.reason}</div>
                  </div>
                  <Badge variant={exam.days_remaining <= 7 ? "danger" : "info"}>{exam.days_remaining}d left</Badge>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
