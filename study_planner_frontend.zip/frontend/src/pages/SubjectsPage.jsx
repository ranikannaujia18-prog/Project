import { useState } from "react";
import { BookOpen, Pencil, Plus, Trash2 } from "lucide-react";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";
import EmptyState from "../components/ui/EmptyState";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import Modal from "../components/ui/Modal";
import ProgressBar from "../components/ui/ProgressBar";
import { useToast } from "../context/ToastContext";
import { useApiData } from "../hooks/useApiData";
import { subjectsApi } from "../services/studyApi";
import { formatMinutes } from "../utils/formatters";

export default function SubjectsPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({
    subject_name: "",
    subject_code: "",
    color: "#4F46E5",
    description: "",
  });

  const { addToast } = useToast();
  const { data: subjects, loading, error, refetch } = useApiData(
    () => subjectsApi.listWithStats(),
    []
  );

  const openCreate = () => {
    setEditing(null);
    setForm({ subject_name: "", subject_code: "", color: "#4F46E5", description: "" });
    setModalOpen(true);
  };

  const openEdit = (sub) => {
    setEditing(sub);
    setForm({
      subject_name: sub.subject_name,
      subject_code: sub.subject_code || "",
      color: sub.color || "#4F46E5",
      description: sub.description || "",
    });
    setModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      if (editing) {
        await subjectsApi.update(editing.id, form);
        addToast("Subject updated.", "success");
      } else {
        await subjectsApi.create(form);
        addToast("Subject created.", "success");
      }
      setModalOpen(false);
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  const handleDelete = async (id) => {
    try {
      await subjectsApi.remove(id);
      addToast("Subject deleted.", "success");
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  if (loading) return <LoadingSpinner label="Loading subjects..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Subjects</h1>
          <p className="page-subtitle">Manage your courses and monitor subject-wise study progress.</p>
        </div>
        <Button onClick={openCreate}>
          <Plus size={16} /> Add Subject
        </Button>
      </div>

      {subjects.length === 0 ? (
        <div className="card">
          <EmptyState
            icon={BookOpen}
            title="No subjects added yet"
            description="Create your first course to start adding syllabus topics, tasks, and exams."
            action={<Button onClick={openCreate}>Add First Subject</Button>}
          />
        </div>
      ) : (
        <div className="grid-3">
          {subjects.map((sub) => (
            <div
              key={sub.id}
              className="card"
              style={{ borderTop: `4px solid ${sub.color || "var(--primary)"}` }}
            >
              <div className="card-header">
                <div>
                  <h3 className="card-title">{sub.subject_name}</h3>
                  {sub.subject_code && <Badge variant="neutral">{sub.subject_code}</Badge>}
                </div>
                <div className="header-actions">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(sub)}>
                    <Pencil size={14} />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(sub.id)}>
                    <Trash2 size={14} color="var(--danger)" />
                  </Button>
                </div>
              </div>

              {sub.description && (
                <p style={{ fontSize: "0.86rem", color: "var(--text-secondary)", marginBottom: "1rem" }}>
                  {sub.description}
                </p>
              )}

              <div style={{ marginBottom: "0.85rem" }}>
                <div style={{ fontSize: "0.8rem", color: "var(--text-muted)", marginBottom: "0.3rem" }}>
                  Syllabus Progress ({sub.stats.completed_topics}/{sub.stats.total_topics} topics)
                </div>
                <ProgressBar
                  value={sub.stats.syllabus_completion_percentage}
                  color={sub.color || "var(--primary)"}
                  showLabel
                />
              </div>

              <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.82rem", color: "var(--text-secondary)" }}>
                <span>Tasks: {sub.stats.completed_tasks}/{sub.stats.total_tasks}</span>
                <span>Studied: {formatMinutes(sub.stats.total_study_minutes)}</span>
                <span>
                  Exam Avg: {sub.stats.average_exam_percentage !== null ? `${sub.stats.average_exam_percentage}%` : "—"}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Subject" : "Add Subject"}>
        <form className="form-stack" onSubmit={handleSave}>
          <div className="form-group">
            <label className="form-label">Subject Name</label>
            <input
              className="form-control"
              placeholder="Database Management Systems"
              value={form.subject_name}
              onChange={(e) => setForm({ ...form, subject_name: e.target.value })}
              required
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Subject Code</label>
              <input
                className="form-control"
                placeholder="CS301"
                value={form.subject_code}
                onChange={(e) => setForm({ ...form, subject_code: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label className="form-label">Accent Color</label>
              <input
                type="color"
                className="form-control"
                style={{ height: 40, padding: 4 }}
                value={form.color}
                onChange={(e) => setForm({ ...form, color: e.target.value })}
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea
              className="form-control"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
          </div>

          <div className="modal-actions">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit">{editing ? "Save Changes" : "Create Subject"}</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
