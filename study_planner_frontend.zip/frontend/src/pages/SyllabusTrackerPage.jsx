import { useState } from "react";
import { ListChecks, Pencil, Plus, Trash2 } from "lucide-react";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";
import DataTable from "../components/ui/DataTable";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import Modal from "../components/ui/Modal";
import ProgressBar from "../components/ui/ProgressBar";
import StatCard from "../components/ui/StatCard";
import { useToast } from "../context/ToastContext";
import { useApiData } from "../hooks/useApiData";
import { subjectsApi, topicsApi } from "../services/studyApi";
import { formatLabel, statusVariant } from "../utils/formatters";

export default function SyllabusTrackerPage() {
  const [selectedSubject, setSelectedSubject] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({
    subject_id: "",
    topic_name: "",
    difficulty_level: "medium",
    status: "not_started",
    confidence_level: 3,
    completion_percentage: 0,
    notes: "",
  });

  const { addToast } = useToast();

  const { data, loading, error, refetch } = useApiData(async () => {
    const params = selectedSubject ? { subject_id: selectedSubject } : undefined;
    const [coverage, topics, subjects] = await Promise.all([
      topicsApi.coverage(params),
      topicsApi.list(params),
      subjectsApi.list(),
    ]);
    return { coverage, topics, subjects };
  }, [selectedSubject]);

  const openCreate = () => {
    setEditing(null);
    setForm({
      subject_id: selectedSubject || data?.subjects?.[0]?.id || "",
      topic_name: "",
      difficulty_level: "medium",
      status: "not_started",
      confidence_level: 3,
      completion_percentage: 0,
      notes: "",
    });
    setModalOpen(true);
  };

  const openEdit = (topic) => {
    setEditing(topic);
    setForm({
      subject_id: topic.subject_id,
      topic_name: topic.topic_name,
      difficulty_level: topic.difficulty_level,
      status: topic.status,
      confidence_level: topic.confidence_level,
      completion_percentage: topic.completion_percentage,
      notes: topic.notes || "",
    });
    setModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        ...form,
        subject_id: Number(form.subject_id),
        confidence_level: Number(form.confidence_level),
        completion_percentage: Number(form.completion_percentage),
      };
      if (editing) {
        await topicsApi.update(editing.id, payload);
        addToast("Topic updated.", "success");
      } else {
        await topicsApi.create(payload);
        addToast("Topic added to syllabus.", "success");
      }
      setModalOpen(false);
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  const handleDelete = async (id) => {
    try {
      await topicsApi.remove(id);
      addToast("Topic removed.", "success");
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  if (loading) return <LoadingSpinner label="Loading syllabus coverage..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  const { coverage, topics, subjects } = data;
  const subNameMap = Object.fromEntries(subjects.map((s) => [s.id, s.subject_name]));

  const columns = [
    {
      key: "topic_name",
      label: "Topic",
      render: (t) => (
        <div>
          <div style={{ fontWeight: 600 }}>{t.topic_name}</div>
          <div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>{subNameMap[t.subject_id]}</div>
        </div>
      ),
    },
    {
      key: "difficulty_level",
      label: "Difficulty",
      render: (t) => (
        <Badge variant={t.difficulty_level === "hard" ? "danger" : t.difficulty_level === "medium" ? "warning" : "success"}>
          {t.difficulty_level}
        </Badge>
      ),
    },
    {
      key: "status",
      label: "Status",
      render: (t) => <Badge variant={statusVariant(t.status)}>{formatLabel(t.status)}</Badge>,
    },
    {
      key: "confidence_level",
      label: "Confidence",
      render: (t) => `${t.confidence_level} / 5`,
    },
    {
      key: "completion_percentage",
      label: "Completion",
      render: (t) => <ProgressBar value={t.completion_percentage} showLabel />,
    },
    {
      key: "actions",
      label: "Actions",
      render: (t) => (
        <div className="header-actions">
          <Button variant="ghost" size="sm" onClick={() => openEdit(t)}>
            <Pencil size={14} />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleDelete(t.id)}>
            <Trash2 size={14} color="var(--danger)" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Syllabus Tracker</h1>
          <p className="page-subtitle">Track chapter-by-chapter completion, difficulty, and confidence.</p>
        </div>
        <Button onClick={openCreate} disabled={!subjects.length}>
          <Plus size={16} /> Add Topic
        </Button>
      </div>

      <div className="grid-stats">
        <StatCard
          label="Overall Coverage"
          value={`${coverage.overall_completion_percentage}%`}
          icon={ListChecks}
          accent="primary"
        />
        <StatCard label="Completed Topics" value={coverage.summary.completed} accent="success" />
        <StatCard label="Ongoing Topics" value={coverage.summary.ongoing} accent="info" />
        <StatCard label="Pending Topics" value={coverage.summary.pending} accent="warning" />
      </div>

      <div className="filter-bar">
        <select
          className="form-control"
          value={selectedSubject}
          onChange={(e) => setSelectedSubject(e.target.value)}
        >
          <option value="">All Subjects</option>
          {subjects.map((s) => (
            <option key={s.id} value={s.id}>{s.subject_name}</option>
          ))}
        </select>
      </div>

      <Card title="Syllabus Topics">
        <DataTable columns={columns} rows={topics} emptyText="No topics added for this selection." />
      </Card>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Topic" : "Add Topic"}>
        <form className="form-stack" onSubmit={handleSave}>
          <div className="form-group">
            <label className="form-label">Subject</label>
            <select
              className="form-control"
              value={form.subject_id}
              onChange={(e) => setForm({ ...form, subject_id: e.target.value })}
              disabled={Boolean(editing)}
              required
            >
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>{s.subject_name}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Topic Name</label>
            <input
              className="form-control"
              value={form.topic_name}
              onChange={(e) => setForm({ ...form, topic_name: e.target.value })}
              required
            />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Difficulty</label>
              <select
                className="form-control"
                value={form.difficulty_level}
                onChange={(e) => setForm({ ...form, difficulty_level: e.target.value })}
              >
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Status</label>
              <select
                className="form-control"
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value })}
              >
                <option value="not_started">Not Started</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
              </select>
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Confidence (1–5)</label>
              <input
                type="number"
                min="1"
                max="5"
                className="form-control"
                value={form.confidence_level}
                onChange={(e) => setForm({ ...form, confidence_level: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label className="form-label">Completion % (0–100)</label>
              <input
                type="number"
                min="0"
                max="100"
                className="form-control"
                value={form.completion_percentage}
                onChange={(e) => setForm({ ...form, completion_percentage: e.target.value })}
              />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Notes</label>
            <textarea
              className="form-control"
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
            />
          </div>
          <div className="modal-actions">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit">{editing ? "Save Changes" : "Add Topic"}</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
