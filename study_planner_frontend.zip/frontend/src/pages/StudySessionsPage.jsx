import { useEffect, useMemo, useState } from "react";
import { Clock, Play, Square } from "lucide-react";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";
import DataTable from "../components/ui/DataTable";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import StatCard from "../components/ui/StatCard";
import { useToast } from "../context/ToastContext";
import { useApiData } from "../hooks/useApiData";
import { studySessionsApi, subjectsApi, tasksApi, topicsApi } from "../services/studyApi";
import { formatDateTime, formatMinutes } from "../utils/formatters";

export default function StudySessionsPage() {
  const [form, setForm] = useState({
    subject_id: "",
    topic_id: "",
    task_id: "",
    session_type: "pomodoro",
    notes: "",
  });
  const [elapsedSec, setElapsedSec] = useState(0);
  const { addToast } = useToast();

  const { data, loading, error, refetch } = useApiData(async () => {
    const [active, sessions, summary, subjects, topics, tasks] = await Promise.all([
      studySessionsApi.active(),
      studySessionsApi.list(),
      studySessionsApi.summary(),
      subjectsApi.list(),
      topicsApi.list(),
      tasksApi.list(),
    ]);
    return { active, sessions, summary, subjects, topics, tasks };
  }, []);

  // Live ticking timer synced to the backend active session's start_time
  useEffect(() => {
    if (!data?.active) {
      setElapsedSec(0);
      return undefined;
    }
    const startMs = new Date(data.active.start_time).getTime();
    const tick = () => setElapsedSec(Math.max(0, Math.floor((Date.now() - startMs) / 1000)));
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [data?.active]);

  const filteredTopics = useMemo(
    () => (data?.topics || []).filter((t) => String(t.subject_id) === String(form.subject_id)),
    [data, form.subject_id]
  );

  const filteredTasks = useMemo(
    () =>
      (data?.tasks || []).filter(
        (t) => String(t.subject_id) === String(form.subject_id) && t.status !== "completed"
      ),
    [data, form.subject_id]
  );

  const handleStart = async (e) => {
    e.preventDefault();
    if (!form.subject_id || !form.topic_id) {
      addToast("Please choose both a subject and a topic.", "error");
      return;
    }
    try {
      await studySessionsApi.start({
        subject_id: Number(form.subject_id),
        topic_id: Number(form.topic_id),
        task_id: form.task_id ? Number(form.task_id) : null,
        session_type: form.session_type,
        notes: form.notes || null,
      });
      addToast("Study session started!", "success");
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  const handleStop = async () => {
    if (!data?.active) return;
    try {
      await studySessionsApi.end(data.active.id, { notes: form.notes || undefined });
      addToast("Study session saved!", "success");
      setForm((prev) => ({ ...prev, notes: "" }));
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  if (loading) return <LoadingSpinner label="Loading study session tracker..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  const subMap = Object.fromEntries(data.subjects.map((s) => [s.id, s.subject_name]));
  const topicMap = Object.fromEntries(data.topics.map((t) => [t.id, t.topic_name]));

  const hrs = String(Math.floor(elapsedSec / 3600)).padStart(2, "0");
  const mins = String(Math.floor((elapsedSec % 3600) / 60)).padStart(2, "0");
  const secs = String(elapsedSec % 60).padStart(2, "0");

  const columns = [
    { key: "subject_id", label: "Subject", render: (s) => subMap[s.subject_id] || "—" },
    { key: "topic_id", label: "Topic", render: (s) => topicMap[s.topic_id] || "—" },
    { key: "session_type", label: "Type", render: (s) => <Badge variant="primary">{s.session_type}</Badge> },
    { key: "start_time", label: "Started", render: (s) => formatDateTime(s.start_time) },
    {
      key: "duration_minutes",
      label: "Duration",
      render: (s) => (s.is_active ? <Badge variant="success">Active</Badge> : formatMinutes(s.duration_minutes)),
    },
  ];

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Study Session Tracker</h1>
          <p className="page-subtitle">Run a live focus timer and automatically track subject & topic hours.</p>
        </div>
      </div>

      <div className="grid-stats">
        <StatCard label="Today's Study Time" value={formatMinutes(data.summary.today_minutes)} icon={Clock} accent="primary" />
        <StatCard label="Weekly Study Time" value={formatMinutes(data.summary.weekly_minutes)} accent="info" />
        <StatCard label="Total Logged Time" value={formatMinutes(data.summary.total_minutes)} accent="success" />
        <StatCard label="Completed Sessions" value={data.summary.total_sessions} accent="warning" />
      </div>

      <Card title={data.active ? "Active Session Running" : "Start a New Study Session"} className="mb-4">
        {data.active ? (
          <div style={{ textAlign: "center", padding: "1.25rem 0" }}>
            <div style={{ fontSize: "2.8rem", fontWeight: 700, fontVariantNumeric: "tabular-nums", letterSpacing: "0.04em" }}>
              {hrs}:{mins}:{secs}
            </div>
            <p style={{ color: "var(--text-secondary)", margin: "0.5rem 0 1.25rem" }}>
              {subMap[data.active.subject_id]} · {topicMap[data.active.topic_id]} ({data.active.session_type})
            </p>
            <Button variant="danger" onClick={handleStop}>
              <Square size={16} /> Stop & Save Session
            </Button>
          </div>
        ) : (
          <form className="form-stack" onSubmit={handleStart}>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Subject</label>
                <select
                  className="form-control"
                  value={form.subject_id}
                  onChange={(e) => setForm({ ...form, subject_id: e.target.value, topic_id: "", task_id: "" })}
                  required
                >
                  <option value="">Select subject...</option>
                  {data.subjects.map((s) => (
                    <option key={s.id} value={s.id}>{s.subject_name}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Topic</label>
                <select
                  className="form-control"
                  value={form.topic_id}
                  onChange={(e) => setForm({ ...form, topic_id: e.target.value })}
                  required
                >
                  <option value="">Select topic...</option>
                  {filteredTopics.map((t) => (
                    <option key={t.id} value={t.id}>{t.topic_name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Session Type</label>
                <select
                  className="form-control"
                  value={form.session_type}
                  onChange={(e) => setForm({ ...form, session_type: e.target.value })}
                >
                  <option value="pomodoro">Pomodoro</option>
                  <option value="focused">Focused</option>
                  <option value="revision">Revision</option>
                  <option value="practice">Practice</option>
                  <option value="group">Group</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Linked Task (Optional)</label>
                <select
                  className="form-control"
                  value={form.task_id}
                  onChange={(e) => setForm({ ...form, task_id: e.target.value })}
                >
                  <option value="">None</option>
                  {filteredTasks.map((t) => (
                    <option key={t.id} value={t.id}>{t.title}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <Button type="submit">
                <Play size={16} /> Start Session
              </Button>
            </div>
          </form>
        )}
      </Card>

      <div style={{ marginTop: "1.25rem" }}>
        <Card title="Session History">
          <DataTable columns={columns} rows={data.sessions} emptyText="No study sessions recorded yet." />
        </Card>
      </div>
    </div>
  );
}
