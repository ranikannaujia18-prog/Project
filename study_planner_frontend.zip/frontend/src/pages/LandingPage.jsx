import { Link } from "react-router-dom";
import {
  AlertTriangle,
  BarChart3,
  BookOpen,
  CalendarDays,
  Clock,
  GraduationCap,
  History,
  Lightbulb,
} from "lucide-react";
import Button from "../components/ui/Button";

const FEATURES = [
  {
    icon: CalendarDays,
    title: "Daily & Weekly Study Planner",
    desc: "Organize assignments by date, subject, and priority with overdue alerts.",
  },
  {
    icon: BookOpen,
    title: "Syllabus Coverage Tracker",
    desc: "Track every chapter's completion %, difficulty, and confidence level.",
  },
  {
    icon: AlertTriangle,
    title: "Rule-Based Weak Topic Detector",
    desc: "Transparent weighted scoring flags low-confidence and high-risk topics.",
  },
  {
    icon: History,
    title: "Smart Backlog Recovery",
    desc: "Turn overdue tasks into a realistic daily plan without overloading your schedule.",
  },
  {
    icon: Clock,
    title: "Live Study Session Timer",
    desc: "Start and stop Pomodoro or focused blocks and log time by subject and topic.",
  },
  {
    icon: BarChart3,
    title: "Productivity Analytics & Insights",
    desc: "Monitor study streaks, exam performance, and actionable rule-based recommendations.",
  },
];

export default function LandingPage() {
  return (
    <div>
      <header className="landing-nav">
        <div className="brand-mark" style={{ fontWeight: 700, fontSize: "1.1rem" }}>
          <span className="brand-icon">
            <GraduationCap size={18} />
          </span>
          StudyFlow
        </div>
        <div className="header-actions">
          <Link to="/login">
            <Button variant="ghost">Log in</Button>
          </Link>
          <Link to="/register">
            <Button variant="primary">Get Started</Button>
          </Link>
        </div>
      </header>

      <section className="landing-hero">
        <span className="badge badge-primary" style={{ marginBottom: "0.75rem" }}>
          <Lightbulb size={13} /> Smart Academic Productivity Suite
        </span>
        <h1>Plan your semester, master weak topics, and finish every exam ready.</h1>
        <p>
          StudyFlow brings your syllabus, tasks, Pomodoro timer, spaced-repetition revisions,
          backlog recovery, and exam analytics into one clean student workspace.
        </p>
        <div className="header-actions" style={{ justifyContent: "center" }}>
          <Link to="/register">
            <Button variant="primary">Create Free Account</Button>
          </Link>
          <Link to="/login">
            <Button variant="secondary">Sign In to Dashboard</Button>
          </Link>
        </div>
      </section>

      <section className="landing-features">
        <div className="grid-3">
          {FEATURES.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="card">
              <div
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 10,
                  background: "var(--primary-soft)",
                  color: "var(--primary)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: "0.85rem",
                }}
              >
                <Icon size={20} />
              </div>
              <h3 className="card-title" style={{ marginBottom: "0.4rem" }}>
                {title}
              </h3>
              <p style={{ fontSize: "0.9rem", color: "var(--text-secondary)" }}>{desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
