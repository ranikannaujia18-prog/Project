import { useState } from "react";
import { AlertTriangle, RefreshCw } from "lucide-react";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";
import DataTable from "../components/ui/DataTable";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import ProgressBar from "../components/ui/ProgressBar";
import StatCard from "../components/ui/StatCard";
import { useToast } from "../context/ToastContext";
import { useApiData } from "../hooks/useApiData";
import { weakTopicsApi } from "../services/studyApi";

export default function WeakTopicsPage() {
  const [weights, setWeights] = useState({
    confidence: 0.3,
    exam: 0.25,
    difficulty: 0.15,
    revision: 0.15,
    completion: 0.15,
  });
  const [customResult, setCustomResult] = useState(null);
  const { addToast } = useToast();

  const { data: initialData, loading, error, refetch } = useApiData(() => weakTopicsApi.get(), []);
  const report = customResult || initialData;

  const handleRecalculate = async (e) => {
    e.preventDefault();
    try {
      const res = await weakTopicsApi.analyze({ weights });
      setCustomResult(res);
      addToast("Weakness scores recalculated with your custom weights.", "success");
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  if (loading) return <LoadingSpinner label="Analyzing weak topics..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  const columns = [
    {
      key: "topic_name",
      label: "Topic",
      render: (t) => (
        <div>
          <div style={{ fontWeight: 600 }}>{t.topic_name}</div>
          <div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>{t.subject_name}</div>
        </div>
      ),
    },
    {
      key: "weakness_score",
      label: "Weakness Score",
      render: (t) => (
        <Badge variant={t.risk_level === "high_risk" ? "danger" : t.risk_level === "weak" ? "warning" : "success"}>
          {t.weakness_score} / 100
        </Badge>
      ),
    },
    { key: "confidence_level", label: "Confidence", render: (t) => `${t.confidence_level} / 5` },
    { key: "difficulty_level", label: "Difficulty", render: (t) => <Badge variant="neutral">{t.difficulty_level}</Badge> },
    {
      key: "days_since_revision",
      label: "Revision Status",
      render: (t) => (t.days_since_revision === null ? "Never revised" : `${t.days_since_revision}d ago`),
    },
    {
      key: "completion_percentage",
      label: "Completion",
      render: (t) => <ProgressBar value={t.completion_percentage} showLabel />,
    },
  ];

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Weak Topic Detector</h1>
          <p className="page-subtitle">Transparent rule-based weighted scoring — adjust weights anytime.</p>
        </div>
      </div>

      <div className="grid-stats">
        <StatCard label="Weak Topics" value={report.weak_topics.length} icon={AlertTriangle} accent="warning" />
        <StatCard label="High-Risk Topics" value={report.high_risk_topics.length} accent="danger" />
        <StatCard label="Need Revision" value={report.topics_needing_revision.length} icon={RefreshCw} accent="info" />
        <StatCard label="Low Confidence (≤2)" value={report.low_confidence_topics.length} accent="primary" />
      </div>

      <div className="grid-2">
        <Card title="Adjust Scoring Weights" subtitle={report.formula}>
          <form className="form-stack" onSubmit={handleRecalculate}>
            <div className="form-row">
              {Object.entries(weights).map(([key, val]) => (
                <div key={key} className="form-group">
                  <label className="form-label" style={{ textTransform: "capitalize" }}>{key} weight</label>
                  <input
                    type="number"
                    step="0.05"
                    min="0"
                    max="1"
                    className="form-control"
                    value={val}
                    onChange={(e) => setWeights({ ...weights, [key]: Number(e.target.value) })}
                  />
                </div>
              ))}
            </div>
            <div>
              <Button type="submit">Recalculate Scores</Button>
            </div>
          </form>
        </Card>

        <Card title="Subjects Requiring Attention">
          {report.subjects_needing_attention.length === 0 ? (
            <p className="empty-state" style={{ padding: "1.25rem" }}>All subjects are currently in healthy shape.</p>
          ) : (
            <div className="stack-list">
              {report.subjects_needing_attention.map((s) => (
                <div key={s.subject_id} className="list-row">
                  <div>
                    <strong>{s.subject_name}</strong>
                    <div style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>{s.weak_topic_count} weak topic(s)</div>
                  </div>
                  <Badge variant="danger">Avg {s.average_weakness_score}</Badge>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      <Card title="All Topics Ranked by Weakness Score">
        <DataTable columns={columns} rows={report.all_topics_ranked} emptyText="Add topics in Syllabus Tracker to analyze weakness scores." />
      </Card>
    </div>
  );
}
