import { useState } from "react";
import { History } from "lucide-react";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import ProgressBar from "../components/ui/ProgressBar";
import StatCard from "../components/ui/StatCard";
import { useToast } from "../context/ToastContext";
import { useApiData } from "../hooks/useApiData";
import { backlogApi } from "../services/studyApi";
import { formatDate, formatLabel, formatMinutes, priorityVariant } from "../utils/formatters";

export default function BacklogRecoveryPage() {
  const [dailyMinutes, setDailyMinutes] = useState(120);
  const [days, setDays] = useState(7);
  const [planOverride, setPlanOverride] = useState(null);
  const { addToast } = useToast();

  const { data: initialPlan, loading, error, refetch } = useApiData(
    () => backlogApi.getPlan({ daily_minutes: dailyMinutes, days }),
    []
  );
  const plan = planOverride || initialPlan;

  const handleGenerate = async (e) => {
    e.preventDefault();
    try {
      const updated = await backlogApi.generatePlan({
        daily_minutes: Number(dailyMinutes),
        days: Number(days),
      });
      setPlanOverride(updated);
      addToast("Recovery plan updated without modifying your existing tasks.", "success");
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  if (loading) return <LoadingSpinner label="Building your backlog recovery plan..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Smart Backlog Recovery Planner</h1>
          <p className="page-subtitle">
            Prioritizes overdue tasks, unfinished work, and pending topics without overloading your daily schedule.
          </p>
        </div>
      </div>

      <form className="filter-bar" onSubmit={handleGenerate}>
        <label className="form-label">Daily Limit (min):</label>
        <input
          type="number"
          min="15"
          max="720"
          className="form-control"
          value={dailyMinutes}
          onChange={(e) => setDailyMinutes(e.target.value)}
        />
        <label className="form-label">Plan Horizon (days):</label>
        <input
          type="number"
          min="1"
          max="30"
          className="form-control"
          value={days}
          onChange={(e) => setDays(e.target.value)}
        />
        <Button type="submit" size="sm">Regenerate Plan</Button>
      </form>

      <div className="grid-stats">
        <StatCard label="Overdue Tasks" value={plan.summary.overdue_tasks} icon={History} accent={plan.summary.overdue_tasks ? "danger" : "success"} />
        <StatCard label="Unfinished Tasks" value={plan.summary.unfinished_tasks} accent="warning" />
        <StatCard label="Pending Topics" value={plan.summary.pending_topics} accent="info" />
        <StatCard
          label="Total Workload"
          value={formatMinutes(plan.summary.total_estimated_minutes)}
          subtext={`${plan.summary.scheduled_items} scheduled · ${plan.summary.overflow_items} overflow`}
          accent="primary"
        />
      </div>

      <div className="grid-2">
        {plan.daily_recovery_plan.map((day) => {
          const loadPct = Math.round((day.planned_minutes / plan.daily_study_limit_minutes) * 100);
          return (
            <Card
              key={day.date}
              title={formatDate(day.date)}
              subtitle={`${formatMinutes(day.planned_minutes)} / ${formatMinutes(plan.daily_study_limit_minutes)} allocated`}
            >
              <div style={{ marginBottom: "0.85rem" }}>
                <ProgressBar value={loadPct} color={loadPct > 100 ? "var(--danger)" : "var(--primary)"} showLabel />
              </div>
              {day.items.length === 0 ? (
                <p style={{ fontSize: "0.86rem", color: "var(--text-muted)" }}>No recovery items needed on this day.</p>
              ) : (
                <div className="stack-list">
                  {day.items.map((item, idx) => (
                    <div key={idx} className="list-row">
                      <div>
                        <div style={{ fontWeight: 600, fontSize: "0.88rem" }}>{item.title}</div>
                        <div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>
                          {item.subject_name} · {formatLabel(item.item_type)}
                        </div>
                      </div>
                      <div className="header-actions">
                        <Badge variant={priorityVariant(item.priority)}>{item.priority}</Badge>
                        <Badge variant="neutral">{formatMinutes(item.estimated_minutes)}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          );
        })}
      </div>

      {plan.unscheduled_overflow.length > 0 && (
        <Card title="Overflow Items (Increase daily minutes or horizon to fit)">
          <div className="stack-list">
            {plan.unscheduled_overflow.map((item, idx) => (
              <div key={idx} className="list-row">
                <span>{item.title} ({item.subject_name})</span>
                <Badge variant="warning">{formatMinutes(item.estimated_minutes)}</Badge>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
