import { useState } from "react";
import { Award, GraduationCap, Pencil, Plus, Trash2 } from "lucide-react";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";
import DataTable from "../components/ui/DataTable";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import Modal from "../components/ui/Modal";
import { useToast } from "../context/ToastContext";
import { useApiData } from "../hooks/useApiData";
import { examsApi, subjectsApi } from "../services/studyApi";
import { formatDateTime, toDatetimeLocalValue } from "../utils/formatters";

export default function ExamsPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [scoreModal, setScoreModal] = useState(null);
  const [scoreVal, setScoreVal] = useState("");
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ subject_id: "", exam_name: "", exam_date: "", total_marks: 100 });
  const { addToast } = useToast();

  const { data, loading, error, refetch } = useApiData(async () => {
    const [exams, subjects] = await Promise.all([examsApi.list(), subjectsApi.list()]);
    return { exams, subjects };
  }, []);

  const openCreate = () => {
    setEditing(null);
    setForm({ subject_id: data?.subjects?.[0]?.id || "", exam_name: "", exam_date: "", total_marks: 100 });
    setModalOpen(true);
  };

  const openEdit = (exam) => {
    setEditing(exam);
    setForm({
      subject_id: exam.subject_id,
      exam_name: exam.exam_name,
      exam_date: toDatetimeLocalValue(exam.exam_date),
      total_marks: exam.total_marks,
    });
    setModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        subject_id: Number(form.subject_id),
        exam_name: form.exam_name.trim(),
        exam_date: new Date(form.exam_date).toISOString(),
        total_marks: Number(form.total_marks),
      };
      if (editing) {
        await examsApi.update(editing.id, payload);
        addToast("Exam updated.", "success");
      } else {
        await examsApi.create(payload);
        addToast("Exam added.", "success");
      }
      setModalOpen(false);
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  const handleSaveScore = async (e) => {
    e.preventDefault();
    try {
      await examsApi.saveScore(scoreModal.id, Number(scoreVal));
      addToast("Exam score recorded!", "success");
      setScoreModal(null);
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  const handleDelete = async (id) => {
    try {
      await examsApi.remove(id);
      addToast("Exam deleted.", "success");
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  if (loading) return <LoadingSpinner label="Loading exams..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  const subMap = Object.fromEntries(data.subjects.map((s) => [s.id, s.subject_name]));

  const columns = [
    {
      key: "exam_name",
      label: "Exam",
      render: (e) => (
        <div>
          <div style={{ fontWeight: 600 }}>{e.exam_name}</div>
          <div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>{subMap[e.subject_id]}</div>
        </div>
      ),
    },
    { key: "exam_date", label: "Date", render: (e) => formatDateTime(e.exam_date) },
    {
      key: "days_remaining",
      label: "Countdown",
      render: (e) =>
        e.days_remaining >= 0 ? (
          <Badge variant={e.days_remaining <= 7 ? "danger" : "info"}>{e.days_remaining}d left</Badge>
        ) : (
          <Badge variant="neutral">Completed</Badge>
        ),
    },
    {
      key: "score",
      label: "Score",
      render: (e) =>
        e.obtained_marks !== null ? (
          <strong>{e.obtained_marks} / {e.total_marks} ({e.percentage}%)</strong>
        ) : (
          <span style={{ color: "var(--text-muted)" }}>Pending / {e.total_marks}</span>
        ),
    },
    {
      key: "actions",
      label: "Actions",
      render: (e) => (
        <div className="header-actions">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => {
              setScoreModal(e);
              setScoreVal(e.obtained_marks ?? "");
            }}
          >
            <Award size={14} /> Score
          </Button>
          <Button variant="ghost" size="sm" onClick={() => openEdit(e)}>
            <Pencil size={14} />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleDelete(e.id)}>
            <Trash2 size={14} color="var(--danger)" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Exam Management</h1>
          <p className="page-subtitle">Track upcoming exam countdowns and log performance scores.</p>
        </div>
        <Button onClick={openCreate} disabled={!data.subjects.length}>
          <Plus size={16} /> Add Exam
        </Button>
      </div>

      <Card title="All Exams" action={<GraduationCap size={18} color="var(--primary)" />}>
        <DataTable columns={columns} rows={data.exams} emptyText="No exams scheduled yet." />
      </Card>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Exam" : "Add Exam"}>
        <form className="form-stack" onSubmit={handleSave}>
          <div className="form-group">
            <label className="form-label">Subject</label>
            <select className="form-control" value={form.subject_id} onChange={(e) => setForm({ ...form, subject_id: e.target.value })} required>
              {data.subjects.map((s) => <option key={s.id} value={s.id}>{s.subject_name}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Exam Name</label>
            <input className="form-control" value={form.exam_name} onChange={(e) => setForm({ ...form, exam_name: e.target.value })} required />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Exam Date & Time</label>
              <input type="datetime-local" className="form-control" value={form.exam_date} onChange={(e) => setForm({ ...form, exam_date: e.target.value })} required />
            </div>
            <div className="form-group">
              <label className="form-label">Total Marks</label>
              <input type="number" min="1" step="0.5" className="form-control" value={form.total_marks} onChange={(e) => setForm({ ...form, total_marks: e.target.value })} required />
            </div>
          </div>
          <div className="modal-actions">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit">{editing ? "Update Exam" : "Add Exam"}</Button>
          </div>
        </form>
      </Modal>

      <Modal isOpen={Boolean(scoreModal)} onClose={() => setScoreModal(null)} title={`Record Score — ${scoreModal?.exam_name || ""}`}>
        <form className="form-stack" onSubmit={handleSaveScore}>
          <div className="form-group">
            <label className="form-label">Obtained Marks (out of {scoreModal?.total_marks})</label>
            <input type="number" min="0" max={scoreModal?.total_marks} step="0.5" className="form-control" value={scoreVal} onChange={(e) => setScoreVal(e.target.value)} required />
          </div>
          <div className="modal-actions">
            <Button variant="secondary" onClick={() => setScoreModal(null)}>Cancel</Button>
            <Button type="submit">Save Score</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
