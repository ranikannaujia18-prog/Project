import { BarChart3, Flame, TrendingUp } from "lucide-react";
import {
  StudyAreaChart,
  StudyBarChart,
  SubjectDistributionPie,
} from "../components/charts/StudyCharts";
import Card from "../components/ui/Card";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import StatCard from "../components/ui/StatCard";
import { useApiData } from "../hooks/useApiData";
import { analyticsApi } from "../services/studyApi";
import { formatMinutes } from "../utils/formatters";

export default function AnalyticsPage() {
  const { data, loading, error, refetch } = useApiData(() => analyticsApi.get(), []);

  if (loading) return <LoadingSpinner label="Loading productivity analytics..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Productivity Analytics</h1>
          <p className="page-subtitle">Daily, weekly, and monthly study trends, streaks, and exam performance.</p>
        </div>
      </div>

      <div className="grid-stats">
        <StatCard
          label="Task Completion Rate"
          value={`${data.task_metrics.task_completion_rate}%`}
          subtext={`${data.task_metrics.completed_tasks}/${data.task_metrics.total_tasks} tasks`}
          icon={BarChart3}
          accent="primary"
        />
        <StatCard
          label="Syllabus Coverage"
          value={`${data.syllabus_completion.completion_percentage}%`}
          subtext={`${data.syllabus_completion.completed_topics}/${data.syllabus_completion.total_topics} topics`}
          accent="success"
        />
        <StatCard
          label="Study Streak"
          value={`${data.study_streaks.current_streak_days} days`}
          subtext={`Best: ${data.study_streaks.longest_streak_days} days`}
          icon={Flame}
          accent="warning"
        />
        <StatCard
          label="Weekly Trend"
          value={`${data.productivity_trends.week_over_week_change_percentage}%`}
          subtext={`This week: ${formatMinutes(data.productivity_trends.this_week_minutes)}`}
          icon={TrendingUp}
          accent={data.productivity_trends.direction === "down" ? "danger" : "info"}
        />
      </div>

      <div className="grid-2">
        <Card title="Daily Study Minutes (Last 7 Days)">
          <StudyBarChart data={data.daily_study_stats} xKey="date" yKey="minutes" barLabel="Minutes" />
        </Card>
        <Card title="Weekly Study Trend (Last 4 Weeks)">
          <StudyAreaChart data={data.weekly_study_stats} xKey="week_start" yKey="minutes" label="Weekly Minutes" />
        </Card>
      </div>

      <div className="grid-2">
        <Card title="Monthly Study Minutes">
          <StudyBarChart data={data.monthly_study_stats} xKey="month" yKey="minutes" barLabel="Monthly Minutes" color="#0284c7" />
        </Card>
        <Card title="Study Time by Subject">
          <SubjectDistributionPie data={data.study_time_by_subject} />
        </Card>
      </div>

      <Card
        title="Exam Performance History"
        subtitle={
          data.exam_performance.average_percentage !== null
            ? `Average across ${data.exam_performance.graded_exam_count} graded exam(s): ${data.exam_performance.average_percentage}%`
            : "Record exam scores to chart your exam performance."
        }
      >
        <StudyBarChart
          data={data.exam_performance.history}
          xKey="exam_name"
          yKey="percentage"
          barLabel="Score %"
          color="#059669"
        />
      </Card>
    </div>
  );
}
