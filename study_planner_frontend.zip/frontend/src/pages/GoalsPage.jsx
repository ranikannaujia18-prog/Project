import { useState } from "react";
import { Flame, Target } from "lucide-react";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";
import DataTable from "../components/ui/DataTable";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import ProgressBar from "../components/ui/ProgressBar";
import StatCard from "../components/ui/StatCard";
import { useToast } from "../context/ToastContext";
import { useApiData } from "../hooks/useApiData";
import { analyticsApi, goalsApi } from "../services/studyApi";
import { formatDate, formatMinutes, todayIsoDate } from "../utils/formatters";

export default function GoalsPage() {
  const [targetMinutes, setTargetMinutes] = useState("");
  const [targetTasks, setTargetTasks] = useState("");
  const { addToast } = useToast();

  const { data, loading, error, refetch } = useApiData(async () => {
    const [todayGoal, history, analytics] = await Promise.all([
      goalsApi.today(),
      goalsApi.list({ limit: 14 }),
      analyticsApi.get(),
    ]);
    setTargetMinutes(String(todayGoal.target_minutes));
    setTargetTasks(String(todayGoal.target_tasks));
    return { todayGoal, history, streaks: analytics.study_streaks };
  }, []);

  const handleSaveToday = async (e) => {
    e.preventDefault();
    try {
      await goalsApi.saveGoal({
        goal_date: todayIsoDate(),
        target_minutes: Number(targetMinutes),
        target_tasks: Number(targetTasks),
      });
      addToast("Today's study targets updated!", "success");
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  if (loading) return <LoadingSpinner label="Loading daily goals..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  const { todayGoal, history, streaks } = data;

  const columns = [
    { key: "goal_date", label: "Date", render: (g) => formatDate(g.goal_date) },
    { key: "minutes", label: "Study Time", render: (g) => `${formatMinutes(g.completed_minutes)} / ${formatMinutes(g.target_minutes)}` },
    { key: "tasks", label: "Tasks", render: (g) => `${g.completed_tasks} / ${g.target_tasks}` },
    { key: "overall_completion_percentage", label: "Completion", render: (g) => <ProgressBar value={g.overall_completion_percentage} showLabel /> },
  ];

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Daily Goals</h1>
          <p className="page-subtitle">Set realistic daily study targets and keep your streak alive.</p>
        </div>
      </div>

      <div className="grid-stats">
        <StatCard label="Today's Goal Completion" value={`${todayGoal.overall_completion_percentage}%`} icon={Target} accent="primary" />
        <StatCard label="Study Time Today" value={formatMinutes(todayGoal.completed_minutes)} subtext={`Target: ${formatMinutes(todayGoal.target_minutes)}`} accent="info" />
        <StatCard label="Tasks Completed Today" value={`${todayGoal.completed_tasks} / ${todayGoal.target_tasks}`} accent="success" />
        <StatCard label="Current Study Streak" value={`${streaks.current_streak_days} days`} subtext={`Longest: ${streaks.longest_streak_days} days`} icon={Flame} accent="warning" />
      </div>

      <div className="grid-2">
        <Card title="Update Today's Targets">
          <form className="form-stack" onSubmit={handleSaveToday}>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Target Study Minutes</label>
                <input type="number" min="0" className="form-control" value={targetMinutes} onChange={(e) => setTargetMinutes(e.target.value)} required />
              </div>
              <div className="form-group">
                <label className="form-label">Target Tasks</label>
                <input type="number" min="0" className="form-control" value={targetTasks} onChange={(e) => setTargetTasks(e.target.value)} required />
              </div>
            </div>
            <div>
              <Button type="submit">Save Today's Goal</Button>
            </div>
          </form>
        </Card>

        <Card title="Today's Progress Breakdown">
          <div className="form-stack">
            <div>
              <div style={{ fontSize: "0.84rem", marginBottom: "0.35rem" }}>Study Time Goal ({todayGoal.time_completion_percentage}%)</div>
              <ProgressBar value={todayGoal.time_completion_percentage} color="var(--primary)" showLabel />
            </div>
            <div>
              <div style={{ fontSize: "0.84rem", marginBottom: "0.35rem" }}>Task Completion Goal ({todayGoal.task_completion_percentage}%)</div>
              <ProgressBar value={todayGoal.task_completion_percentage} color="var(--success)" showLabel />
            </div>
          </div>
        </Card>
      </div>

      <Card title="Recent Daily Goals">
        <DataTable columns={columns} rows={history} emptyText="No daily goal history yet." />
      </Card>
    </div>
  );
}
