import { Link } from "react-router-dom";
import {
  AlertTriangle,
  BookOpen,
  CheckCircle2,
  Clock,
  GraduationCap,
  Lightbulb,
  Target,
} from "lucide-react";
import { StudyBarChart, SubjectDistributionPie } from "../components/charts/StudyCharts";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import ProgressBar from "../components/ui/ProgressBar";
import StatCard from "../components/ui/StatCard";
import { useAuth } from "../context/AuthContext";
import { useApiData } from "../hooks/useApiData";
import {
  analyticsApi,
  dashboardApi,
  goalsApi,
  recommendationsApi,
  weakTopicsApi,
} from "../services/studyApi";
import { formatDate, formatMinutes, priorityVariant } from "../utils/formatters";

export default function DashboardPage() {
  const { student } = useAuth();

  const { data, loading, error, refetch } = useApiData(async () => {
    const [summary, goalToday, analytics, weakReport, recs] = await Promise.all([
      dashboardApi.getSummary(),
      goalsApi.today(),
      analyticsApi.get(),
      weakTopicsApi.get(),
      recommendationsApi.get(),
    ]);
    return { summary, goalToday, analytics, weakReport, recs };
  }, []);

  if (loading) return <LoadingSpinner label="Loading your study dashboard..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  const { summary, goalToday, analytics, weakReport, recs } = data;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Welcome back, {student?.name?.split(" ")[0] || "Student"}</h1>
          <p className="page-subtitle">
            Here is your live study overview pulled directly from your workspace.
          </p>
        </div>
        <div className="header-actions">
          <Link to="/sessions">
            <Button variant="primary">Start Study Session</Button>
          </Link>
          <Link to="/tasks">
            <Button variant="secondary">Add Task</Button>
          </Link>
        </div>
      </div>

      {/* KPI Row */}
      <div className="grid-stats">
        <StatCard
          label="Daily Study Goal"
          value={`${goalToday.overall_completion_percentage}%`}
          subtext={`${formatMinutes(goalToday.completed_minutes)} / ${formatMinutes(goalToday.target_minutes)} today`}
          icon={Target}
          accent="primary"
        />
        <StatCard
          label="Today's Study Time"
          value={formatMinutes(summary.today_study_minutes)}
          subtext={`Weekly: ${formatMinutes(summary.weekly_study_minutes)}`}
          icon={Clock}
          accent="info"
        />
        <StatCard
          label="Tasks Progress"
          value={`${summary.completed_tasks} / ${summary.total_tasks}`}
          subtext={`${summary.pending_tasks} pending · ${summary.overdue_tasks_count} overdue`}
          icon={CheckCircle2}
          accent={summary.overdue_tasks_count > 0 ? "warning" : "success"}
        />
        <StatCard
          label="Syllabus Completion"
          value={`${summary.study_completion_percentage}%`}
          subtext={`${summary.completed_topics}/${summary.total_topics} topics across ${summary.total_subjects} subjects`}
          icon={BookOpen}
          accent="success"
        />
      </div>

      {/* Charts Row */}
      <div className="grid-2">
        <Card title="Weekly Productivity" subtitle="Minutes studied over the last 7 days">
          <StudyBarChart
            data={analytics.daily_study_stats}
            xKey="date"
            yKey="minutes"
            barLabel="Minutes Studied"
          />
        </Card>

        <Card title="Study Time by Subject" subtitle="Distribution across your active subjects">
          <SubjectDistributionPie data={analytics.study_time_by_subject} />
        </Card>
      </div>

      {/* Today's Plan & Smart Recommendations */}
      <div className="grid-2">
        <Card
          title="Today's Study Plan & Deadlines"
          subtitle="Upcoming tasks due within the next 7 days"
          action={
            <Link to="/planner">
              <Button variant="ghost" size="sm">Open Planner</Button>
            </Link>
          }
        >
          {summary.upcoming_deadlines.length === 0 ? (
            <p className="empty-state" style={{ padding: "1.25rem" }}>
              No upcoming deadlines in the next 7 days.
            </p>
          ) : (
            <div className="stack-list">
              {summary.upcoming_deadlines.slice(0, 5).map((task) => (
                <div key={task.id} className="list-row">
                  <div>
                    <div style={{ fontWeight: 600, fontSize: "0.9rem" }}>{task.title}</div>
                    <div style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>
                      Due {formatDate(task.due_date)} · Est. {formatMinutes(task.estimated_minutes || 30)}
                    </div>
                  </div>
                  <Badge variant={priorityVariant(task.priority)}>{task.priority}</Badge>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card
          title="Smart Recommendations"
          subtitle="Deterministic priorities based on your weak topics, backlog, and exams"
          action={
            <Link to="/recommendations">
              <Button variant="ghost" size="sm">View All</Button>
            </Link>
          }
        >
          <div className="stack-list">
            {recs.next_topic_to_study ? (
              <div className="list-row">
                <div>
                  <div style={{ fontSize: "0.75rem", color: "var(--primary)", fontWeight: 600 }}>
                    STUDY NEXT
                  </div>
                  <div style={{ fontWeight: 600 }}>{recs.next_topic_to_study.topic_name}</div>
                  <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)" }}>
                    {recs.next_topic_to_study.reason}
                  </div>
                </div>
                <Lightbulb size={18} color="var(--primary)" />
              </div>
            ) : (
              <p style={{ fontSize: "0.88rem", color: "var(--text-muted)" }}>
                Add topics to receive personalized study recommendations.
              </p>
            )}

            {recs.backlog_to_recover.slice(0, 2).map((item, idx) => (
              <div key={idx} className="list-row">
                <div>
                  <div style={{ fontSize: "0.75rem", color: "var(--warning)", fontWeight: 600 }}>
                    BACKLOG PRIORITY
                  </div>
                  <div style={{ fontWeight: 500, fontSize: "0.9rem" }}>{item.title}</div>
                </div>
                <Badge variant="warning">{formatMinutes(item.estimated_minutes)}</Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Upcoming Exams & Weak Topics */}
      <div className="grid-2">
        <Card
          title="Upcoming Exams"
          action={
            <Link to="/exams">
              <Button variant="ghost" size="sm">Manage Exams</Button>
            </Link>
          }
        >
          {summary.upcoming_exams.length === 0 ? (
            <p className="empty-state" style={{ padding: "1.25rem" }}>
              No upcoming exams scheduled.
            </p>
          ) : (
            <div className="stack-list">
              {summary.upcoming_exams.map((exam) => (
                <div key={exam.id} className="list-row">
                  <div style={{ display: "flex", alignItems: "center", gap: "0.65rem" }}>
                    <GraduationCap size={18} color="var(--primary)" />
                    <div>
                      <div style={{ fontWeight: 600, fontSize: "0.9rem" }}>{exam.exam_name}</div>
                      <div style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>
                        {formatDate(exam.exam_date)} · {exam.total_marks} marks
                      </div>
                    </div>
                  </div>
                  <Badge variant={exam.days_remaining <= 7 ? "danger" : "info"}>
                    {exam.days_remaining}d left
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card
          title="Weak Topics Needing Attention"
          action={
            <Link to="/weak-topics">
              <Button variant="ghost" size="sm">Full Analysis</Button>
            </Link>
          }
        >
          {weakReport.weak_topics.length === 0 ? (
            <p className="empty-state" style={{ padding: "1.25rem" }}>
              No weak topics detected right now. Great work!
            </p>
          ) : (
            <div className="stack-list">
              {weakReport.weak_topics.slice(0, 4).map((topic) => (
                <div key={topic.topic_id} className="list-row" style={{ flexDirection: "column", alignItems: "stretch" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "0.45rem" }}>
                      <AlertTriangle size={15} color="var(--danger)" />
                      <strong style={{ fontSize: "0.9rem" }}>{topic.topic_name}</strong>
                    </div>
                    <Badge variant={topic.risk_level === "high_risk" ? "danger" : "warning"}>
                      Score {topic.weakness_score}
                    </Badge>
                  </div>
                  <ProgressBar value={topic.completion_percentage} color="var(--warning)" showLabel />
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
