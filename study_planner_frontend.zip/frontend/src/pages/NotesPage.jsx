import { useMemo, useState } from "react";
import { ExternalLink, FileText, Pencil, Plus, Trash2 } from "lucide-react";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";
import EmptyState from "../components/ui/EmptyState";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import Modal from "../components/ui/Modal";
import { useToast } from "../context/ToastContext";
import { useApiData } from "../hooks/useApiData";
import { notesApi, subjectsApi, topicsApi } from "../services/studyApi";
import { formatDate } from "../utils/formatters";

export default function NotesPage() {
  const [filterSub, setFilterSub] = useState("");
  const [searchQ, setSearchQ] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ subject_id: "", topic_id: "", title: "", content: "", resource_url: "" });
  const { addToast } = useToast();

  const { data, loading, error, refetch } = useApiData(async () => {
    const params = {};
    if (filterSub) params.subject_id = filterSub;
    if (searchQ.trim()) params.q = searchQ.trim();
    const [notes, subjects, topics] = await Promise.all([
      notesApi.list(params),
      subjectsApi.list(),
      topicsApi.list(),
    ]);
    return { notes, subjects, topics };
  }, [filterSub, searchQ]);

  const formTopics = useMemo(
    () => (data?.topics || []).filter((t) => String(t.subject_id) === String(form.subject_id)),
    [data, form.subject_id]
  );

  const openCreate = () => {
    const firstSub = data?.subjects?.[0]?.id || "";
    const firstTopic = (data?.topics || []).find((t) => String(t.subject_id) === String(firstSub))?.id || "";
    setEditing(null);
    setForm({ subject_id: firstSub, topic_id: firstTopic, title: "", content: "", resource_url: "" });
    setModalOpen(true);
  };

  const openEdit = (note) => {
    setEditing(note);
    setForm({
      subject_id: note.subject_id,
      topic_id: note.topic_id,
      title: note.title,
      content: note.content,
      resource_url: note.resource_url || "",
    });
    setModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        subject_id: Number(form.subject_id),
        topic_id: Number(form.topic_id),
        title: form.title.trim(),
        content: form.content.trim(),
        resource_url: form.resource_url.trim() || null,
      };
      if (editing) {
        await notesApi.update(editing.id, payload);
        addToast("Note updated.", "success");
      } else {
        await notesApi.create(payload);
        addToast("Note saved.", "success");
      }
      setModalOpen(false);
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  const handleDelete = async (id) => {
    try {
      await notesApi.remove(id);
      addToast("Note deleted.", "success");
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  if (loading) return <LoadingSpinner label="Loading study notes..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  const subMap = Object.fromEntries(data.subjects.map((s) => [s.id, s.subject_name]));
  const topicMap = Object.fromEntries(data.topics.map((t) => [t.id, t.topic_name]));

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Notes & Resources</h1>
          <p className="page-subtitle">Organize chapter summaries and external study links by topic.</p>
        </div>
        <Button onClick={openCreate} disabled={!data.topics.length}>
          <Plus size={16} /> New Note
        </Button>
      </div>

      <div className="filter-bar">
        <select className="form-control" value={filterSub} onChange={(e) => setFilterSub(e.target.value)}>
          <option value="">All Subjects</option>
          {data.subjects.map((s) => <option key={s.id} value={s.id}>{s.subject_name}</option>)}
        </select>
        <input
          className="form-control"
          placeholder="Search notes..."
          value={searchQ}
          onChange={(e) => setSearchQ(e.target.value)}
        />
      </div>

      {data.notes.length === 0 ? (
        <div className="card">
          <EmptyState icon={FileText} title="No notes found" description="Create notes linked to your syllabus topics and attach reference URLs." />
        </div>
      ) : (
        <div className="grid-2">
          {data.notes.map((note) => (
            <div key={note.id} className="card">
              <div className="card-header">
                <div>
                  <h3 className="card-title">{note.title}</h3>
                  <div style={{ display: "flex", gap: "0.4rem", marginTop: "0.3rem", flexWrap: "wrap" }}>
                    <Badge variant="primary">{subMap[note.subject_id]}</Badge>
                    <Badge variant="neutral">{topicMap[note.topic_id]}</Badge>
                  </div>
                </div>
                <div className="header-actions">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(note)}><Pencil size={14} /></Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(note.id)}><Trash2 size={14} color="var(--danger)" /></Button>
                </div>
              </div>
              <p style={{ fontSize: "0.9rem", color: "var(--text-secondary)", whiteSpace: "pre-wrap", marginBottom: "0.85rem" }}>
                {note.content}
              </p>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: "0.8rem", color: "var(--text-muted)" }}>
                <span>Updated {formatDate(note.updated_at)}</span>
                {note.resource_url && (
                  <a href={note.resource_url} target="_blank" rel="noreferrer" style={{ color: "var(--primary)", display: "inline-flex", alignItems: "center", gap: "0.3rem", fontWeight: 500 }}>
                    Open Resource <ExternalLink size={13} />
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Note" : "Create Note"}>
        <form className="form-stack" onSubmit={handleSave}>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Subject</label>
              <select
                className="form-control"
                value={form.subject_id}
                onChange={(e) => setForm({ ...form, subject_id: e.target.value, topic_id: "" })}
                required
              >
                {data.subjects.map((s) => <option key={s.id} value={s.id}>{s.subject_name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Topic</label>
              <select className="form-control" value={form.topic_id} onChange={(e) => setForm({ ...form, topic_id: e.target.value })} required>
                <option value="">Select topic...</option>
                {formTopics.map((t) => <option key={t.id} value={t.id}>{t.topic_name}</option>)}
              </select>
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Title</label>
            <input className="form-control" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          </div>
          <div className="form-group">
            <label className="form-label">Content</label>
            <textarea className="form-control" rows={4} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} required />
          </div>
          <div className="form-group">
            <label className="form-label">Resource URL (Optional)</label>
            <input type="url" className="form-control" placeholder="https://..." value={form.resource_url} onChange={(e) => setForm({ ...form, resource_url: e.target.value })} />
          </div>
          <div className="modal-actions">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit">{editing ? "Save Changes" : "Create Note"}</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
