import { useState } from "react";
import { Check, Plus, RefreshCw, Sparkles, Trash2 } from "lucide-react";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";
import DataTable from "../components/ui/DataTable";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import Modal from "../components/ui/Modal";
import StatCard from "../components/ui/StatCard";
import { useToast } from "../context/ToastContext";
import { useApiData } from "../hooks/useApiData";
import { revisionsApi, topicsApi } from "../services/studyApi";
import { formatDate, statusVariant, todayIsoDate } from "../utils/formatters";

export default function RevisionsPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [autoOpen, setAutoOpen] = useState(false);
  const [form, setForm] = useState({ topic_id: "", scheduled_date: todayIsoDate(), notes: "" });
  const [autoForm, setAutoForm] = useState({ topic_id: "", intervals: "1,3,7,14,30" });
  const { addToast } = useToast();

  const { data, loading, error, refetch } = useApiData(async () => {
    const [all, todayList, overdueList, topics] = await Promise.all([
      revisionsApi.list(),
      revisionsApi.today(),
      revisionsApi.overdue(),
      topicsApi.list(),
    ]);
    return { all, todayList, overdueList, topics };
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await revisionsApi.create({
        topic_id: Number(form.topic_id),
        scheduled_date: form.scheduled_date,
        notes: form.notes || null,
      });
      addToast("Revision scheduled.", "success");
      setModalOpen(false);
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  const handleAutoSchedule = async (e) => {
    e.preventDefault();
    try {
      const intervals = autoForm.intervals
        .split(",")
        .map((n) => Number(n.trim()))
        .filter((n) => n > 0);
      await revisionsApi.autoSchedule({
        topic_id: Number(autoForm.topic_id),
        intervals,
        save: true,
      });
      addToast("Spaced-repetition checkpoints created!", "success");
      setAutoOpen(false);
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  const handleComplete = async (id) => {
    try {
      await revisionsApi.complete(id);
      addToast("Revision marked completed!", "success");
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  const handleDelete = async (id) => {
    try {
      await revisionsApi.remove(id);
      addToast("Revision deleted.", "success");
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  if (loading) return <LoadingSpinner label="Loading revision scheduler..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  const topicMap = Object.fromEntries(data.topics.map((t) => [t.id, t.topic_name]));

  const columns = [
    { key: "topic_id", label: "Topic", render: (r) => <strong>{topicMap[r.topic_id] || `Topic #${r.topic_id}`}</strong> },
    { key: "revision_number", label: "Rev #", render: (r) => `#${r.revision_number}` },
    { key: "scheduled_date", label: "Scheduled Date", render: (r) => formatDate(r.scheduled_date) },
    {
      key: "status",
      label: "Status",
      render: (r) => (
        <div className="header-actions">
          <Badge variant={statusVariant(r.status)}>{r.status}</Badge>
          {r.is_overdue && <Badge variant="danger">Overdue</Badge>}
        </div>
      ),
    },
    { key: "notes", label: "Notes" },
    {
      key: "actions",
      label: "Actions",
      render: (r) => (
        <div className="header-actions">
          {r.status !== "completed" && (
            <Button variant="secondary" size="sm" onClick={() => handleComplete(r.id)}>
              <Check size={14} /> Complete
            </Button>
          )}
          <Button variant="ghost" size="sm" onClick={() => handleDelete(r.id)}>
            <Trash2 size={14} color="var(--danger)" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Revision Scheduler</h1>
          <p className="page-subtitle">Stay on top of spaced-repetition reviews and overdue checkpoints.</p>
        </div>
        <div className="header-actions">
          <Button
            variant="secondary"
            onClick={() => {
              setAutoForm({ topic_id: data.topics[0]?.id || "", intervals: "1,3,7,14,30" });
              setAutoOpen(true);
            }}
            disabled={!data.topics.length}
          >
            <Sparkles size={16} /> Auto-Schedule Intervals
          </Button>
          <Button
            onClick={() => {
              setForm({ topic_id: data.topics[0]?.id || "", scheduled_date: todayIsoDate(), notes: "" });
              setModalOpen(true);
            }}
            disabled={!data.topics.length}
          >
            <Plus size={16} /> Add Revision
          </Button>
        </div>
      </div>

      <div className="grid-stats">
        <StatCard label="Today's Revisions" value={data.todayList.length} icon={RefreshCw} accent="primary" />
        <StatCard label="Overdue Revisions" value={data.overdueList.length} accent={data.overdueList.length ? "danger" : "success"} />
        <StatCard label="Total Scheduled" value={data.all.length} accent="info" />
      </div>

      <Card title="All Revision Schedules">
        <DataTable columns={columns} rows={data.all} emptyText="No revisions scheduled yet." />
      </Card>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Schedule Manual Revision">
        <form className="form-stack" onSubmit={handleCreate}>
          <div className="form-group">
            <label className="form-label">Topic</label>
            <select className="form-control" value={form.topic_id} onChange={(e) => setForm({ ...form, topic_id: e.target.value })} required>
              {data.topics.map((t) => <option key={t.id} value={t.id}>{t.topic_name}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Scheduled Date</label>
            <input type="date" className="form-control" value={form.scheduled_date} onChange={(e) => setForm({ ...form, scheduled_date: e.target.value })} required />
          </div>
          <div className="form-group">
            <label className="form-label">Notes</label>
            <textarea className="form-control" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          </div>
          <div className="modal-actions">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit">Schedule</Button>
          </div>
        </form>
      </Modal>

      <Modal isOpen={autoOpen} onClose={() => setAutoOpen(false)} title="Auto-Schedule Spaced Revisions">
        <form className="form-stack" onSubmit={handleAutoSchedule}>
          <div className="form-group">
            <label className="form-label">Topic</label>
            <select className="form-control" value={autoForm.topic_id} onChange={(e) => setAutoForm({ ...autoForm, topic_id: e.target.value })} required>
              {data.topics.map((t) => <option key={t.id} value={t.id}>{t.topic_name}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Day Intervals (comma-separated)</label>
            <input className="form-control" value={autoForm.intervals} onChange={(e) => setAutoForm({ ...autoForm, intervals: e.target.value })} required />
          </div>
          <div className="modal-actions">
            <Button variant="secondary" onClick={() => setAutoOpen(false)}>Cancel</Button>
            <Button type="submit">Generate & Save</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
