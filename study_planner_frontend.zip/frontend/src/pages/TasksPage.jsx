import { useMemo, useState } from "react";
import { CheckCircle2, Circle, Pencil, Plus, Trash2 } from "lucide-react";
import Badge from "../components/ui/Badge";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";
import DataTable from "../components/ui/DataTable";
import ErrorBanner from "../components/ui/ErrorBanner";
import LoadingSpinner from "../components/ui/LoadingSpinner";
import Modal from "../components/ui/Modal";
import { useToast } from "../context/ToastContext";
import { useApiData } from "../hooks/useApiData";
import { subjectsApi, tasksApi, topicsApi } from "../services/studyApi";
import {
  formatDateTime,
  formatLabel,
  formatMinutes,
  priorityVariant,
  statusVariant,
  toDatetimeLocalValue,
} from "../utils/formatters";

export default function TasksPage() {
  const [filters, setFilters] = useState({ subject_id: "", status: "", priority: "", overdue: false });
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({
    subject_id: "",
    topic_id: "",
    title: "",
    description: "",
    priority: "medium",
    due_date: "",
    estimated_minutes: 45,
  });

  const { addToast } = useToast();

  const { data, loading, error, refetch } = useApiData(async () => {
    const params = {};
    if (filters.subject_id) params.subject_id = filters.subject_id;
    if (filters.status) params.status = filters.status;
    if (filters.priority) params.priority = filters.priority;
    if (filters.overdue) params.overdue = "true";

    const [tasks, subjects, topics] = await Promise.all([
      tasksApi.list(params),
      subjectsApi.list(),
      topicsApi.list(),
    ]);
    return { tasks, subjects, topics };
  }, [filters]);

  const subjectMap = useMemo(() => {
    const m = {};
    (data?.subjects || []).forEach((s) => (m[s.id] = s.subject_name));
    return m;
  }, [data]);

  const availableTopics = useMemo(
    () => (data?.topics || []).filter((t) => String(t.subject_id) === String(form.subject_id)),
    [data, form.subject_id]
  );

  const openCreate = () => {
    setEditing(null);
    setForm({
      subject_id: data?.subjects?.[0]?.id || "",
      topic_id: "",
      title: "",
      description: "",
      priority: "medium",
      due_date: "",
      estimated_minutes: 45,
    });
    setModalOpen(true);
  };

  const openEdit = (task) => {
    setEditing(task);
    setForm({
      subject_id: task.subject_id,
      topic_id: task.topic_id || "",
      title: task.title,
      description: task.description || "",
      priority: task.priority,
      due_date: toDatetimeLocalValue(task.due_date),
      estimated_minutes: task.estimated_minutes || "",
    });
    setModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        subject_id: Number(form.subject_id),
        topic_id: form.topic_id ? Number(form.topic_id) : null,
        title: form.title.trim(),
        description: form.description || null,
        priority: form.priority,
        due_date: form.due_date ? new Date(form.due_date).toISOString() : null,
        estimated_minutes: form.estimated_minutes ? Number(form.estimated_minutes) : null,
      };
      if (editing) {
        await tasksApi.update(editing.id, payload);
        addToast("Task updated.", "success");
      } else {
        await tasksApi.create(payload);
        addToast("Task created.", "success");
      }
      setModalOpen(false);
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  const toggleComplete = async (task) => {
    try {
      if (task.status === "completed") {
        await tasksApi.markPending(task.id);
        addToast("Task moved back to pending.", "success");
      } else {
        await tasksApi.markComplete(task.id);
        addToast("Task completed!", "success");
      }
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  const handleDelete = async (id) => {
    try {
      await tasksApi.remove(id);
      addToast("Task deleted.", "success");
      refetch();
    } catch (err) {
      addToast(err.message, "error");
    }
  };

  if (loading) return <LoadingSpinner label="Loading tasks..." />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  const columns = [
    {
      key: "title",
      label: "Task",
      render: (t) => (
        <div style={{ display: "flex", alignItems: "center", gap: "0.6rem" }}>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => toggleComplete(t)}>
            {t.status === "completed" ? (
              <CheckCircle2 size={17} color="var(--success)" />
            ) : (
              <Circle size={17} color="var(--text-muted)" />
            )}
          </button>
          <div>
            <div style={{ fontWeight: 600, textDecoration: t.status === "completed" ? "line-through" : "none" }}>
              {t.title}
            </div>
            <div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>
              {subjectMap[t.subject_id] || "Subject"}
            </div>
          </div>
        </div>
      ),
    },
    {
      key: "priority",
      label: "Priority",
      render: (t) => <Badge variant={priorityVariant(t.priority)}>{t.priority}</Badge>,
    },
    {
      key: "status",
      label: "Status",
      render: (t) => (
        <div style={{ display: "flex", gap: "0.35rem", alignItems: "center" }}>
          <Badge variant={statusVariant(t.status)}>{formatLabel(t.status)}</Badge>
          {t.is_overdue && <Badge variant="danger">Overdue</Badge>}
        </div>
      ),
    },
    {
      key: "due_date",
      label: "Deadline",
      render: (t) => formatDateTime(t.due_date),
    },
    {
      key: "time",
      label: "Est / Actual",
      render: (t) => `${formatMinutes(t.estimated_minutes || 0)} / ${formatMinutes(t.actual_minutes || 0)}`,
    },
    {
      key: "actions",
      label: "Actions",
      render: (t) => (
        <div className="header-actions">
          <Button variant="ghost" size="sm" onClick={() => openEdit(t)}>
            <Pencil size={14} />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => handleDelete(t.id)}>
            <Trash2 size={14} color="var(--danger)" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Task Management</h1>
          <p className="page-subtitle">Filter, prioritize, and complete assignments across all subjects.</p>
        </div>
        <Button onClick={openCreate} disabled={!data.subjects.length}>
          <Plus size={16} /> New Task
        </Button>
      </div>

      <div className="filter-bar">
        <select
          className="form-control"
          value={filters.subject_id}
          onChange={(e) => setFilters({ ...filters, subject_id: e.target.value })}
        >
          <option value="">All Subjects</option>
          {data.subjects.map((s) => (
            <option key={s.id} value={s.id}>{s.subject_name}</option>
          ))}
        </select>

        <select
          className="form-control"
          value={filters.status}
          onChange={(e) => setFilters({ ...filters, status: e.target.value })}
        >
          <option value="">All Statuses</option>
          <option value="pending">Pending</option>
          <option value="in_progress">In Progress</option>
          <option value="completed">Completed</option>
        </select>

        <select
          className="form-control"
          value={filters.priority}
          onChange={(e) => setFilters({ ...filters, priority: e.target.value })}
        >
          <option value="">All Priorities</option>
          <option value="urgent">Urgent</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>

        <label style={{ display: "inline-flex", alignItems: "center", gap: "0.45rem", fontSize: "0.88rem" }}>
          <input
            type="checkbox"
            checked={filters.overdue}
            onChange={(e) => setFilters({ ...filters, overdue: e.target.checked })}
          />
          Overdue only
        </label>
      </div>

      <Card>
        <DataTable columns={columns} rows={data.tasks} emptyText="No tasks match your current filters." />
      </Card>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Task" : "Create Task"}>
        <form className="form-stack" onSubmit={handleSave}>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Subject</label>
              <select
                className="form-control"
                value={form.subject_id}
                onChange={(e) => setForm({ ...form, subject_id: e.target.value, topic_id: "" })}
                required
              >
                {data.subjects.map((s) => (
                  <option key={s.id} value={s.id}>{s.subject_name}</option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Topic (Optional)</label>
              <select
                className="form-control"
                value={form.topic_id}
                onChange={(e) => setForm({ ...form, topic_id: e.target.value })}
              >
                <option value="">None</option>
                {availableTopics.map((t) => (
                  <option key={t.id} value={t.id}>{t.topic_name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Title</label>
            <input
              className="form-control"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea
              className="form-control"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Priority</label>
              <select
                className="form-control"
                value={form.priority}
                onChange={(e) => setForm({ ...form, priority: e.target.value })}
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Estimated Minutes</label>
              <input
                type="number"
                min="1"
                className="form-control"
                value={form.estimated_minutes}
                onChange={(e) => setForm({ ...form, estimated_minutes: e.target.value })}
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Deadline</label>
            <input
              type="datetime-local"
              className="form-control"
              value={form.due_date}
              onChange={(e) => setForm({ ...form, due_date: e.target.value })}
            />
          </div>

          <div className="modal-actions">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit">{editing ? "Save Changes" : "Create Task"}</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
