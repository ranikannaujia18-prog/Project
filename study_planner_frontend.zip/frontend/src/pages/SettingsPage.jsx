import { useEffect, useState } from "react";
import Button from "../components/ui/Button";
import Card from "../components/ui/Card";
import { useAuth } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";
import { useToast } from "../context/ToastContext";
import { goalsApi } from "../services/studyApi";
import { formatDate } from "../utils/formatters";

export default function SettingsPage() {
  const { student, settings, setSettings } = useAuth();
  const { setTheme } = useTheme();
  const { addToast } = useToast();

  const [form, setForm] = useState({
    daily_study_target: 120,
    pomodoro_duration: 25,
    break_duration: 5,
    theme: "light",
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (settings) {
      setForm({
        daily_study_target: settings.daily_study_target,
        pomodoro_duration: settings.pomodoro_duration,
        break_duration: settings.break_duration,
        theme: settings.theme,
      });
    }
  }, [settings]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const updated = await goalsApi.updateSettings({
        daily_study_target: Number(form.daily_study_target),
        pomodoro_duration: Number(form.pomodoro_duration),
        break_duration: Number(form.break_duration),
        theme: form.theme,
      });
      setSettings(updated);
      setTheme(updated.theme);
      addToast("Settings saved successfully!", "success");
    } catch (err) {
      addToast(err.message, "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Profile & Settings</h1>
          <p className="page-subtitle">Configure your daily study goal, Pomodoro timer, and theme.</p>
        </div>
      </div>

      <div className="grid-2">
        <Card title="Student Profile">
          <div className="stack-list">
            <div className="list-row">
              <span style={{ color: "var(--text-muted)" }}>Full Name</span>
              <strong>{student?.name}</strong>
            </div>
            <div className="list-row">
              <span style={{ color: "var(--text-muted)" }}>Email</span>
              <strong>{student?.email}</strong>
            </div>
            <div className="list-row">
              <span style={{ color: "var(--text-muted)" }}>Member Since</span>
              <strong>{formatDate(student?.created_at)}</strong>
            </div>
          </div>
        </Card>

        <Card title="Study & Appearance Preferences">
          <form className="form-stack" onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Daily Study Target (minutes)</label>
              <input
                type="number"
                min="15"
                max="1440"
                className="form-control"
                value={form.daily_study_target}
                onChange={(e) => setForm({ ...form, daily_study_target: e.target.value })}
                required
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Pomodoro Duration (min)</label>
                <input
                  type="number"
                  min="5"
                  max="180"
                  className="form-control"
                  value={form.pomodoro_duration}
                  onChange={(e) => setForm({ ...form, pomodoro_duration: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Break Duration (min)</label>
                <input
                  type="number"
                  min="1"
                  max="60"
                  className="form-control"
                  value={form.break_duration}
                  onChange={(e) => setForm({ ...form, break_duration: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Theme</label>
              <select
                className="form-control"
                value={form.theme}
                onChange={(e) => setForm({ ...form, theme: e.target.value })}
              >
                <option value="light">Light</option>
                <option value="dark">Dark</option>
                <option value="system">System Default</option>
              </select>
            </div>

            <div>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving..." : "Save Settings"}
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}
