import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import ProtectedRoute from "./components/auth/ProtectedRoute";
import ToastContainer from "./components/ui/ToastContainer";
import { AuthProvider } from "./context/AuthContext";
import { ThemeProvider } from "./context/ThemeContext";
import { ToastProvider } from "./context/ToastContext";
import DashboardLayout from "./layouts/DashboardLayout";
import AnalyticsPage from "./pages/AnalyticsPage";
import BacklogRecoveryPage from "./pages/BacklogRecoveryPage";
import DashboardPage from "./pages/DashboardPage";
import ExamsPage from "./pages/ExamsPage";
import GoalsPage from "./pages/GoalsPage";
import LandingPage from "./pages/LandingPage";
import LoginPage from "./pages/LoginPage";
import NotesPage from "./pages/NotesPage";
import RecommendationsPage from "./pages/RecommendationsPage";
import RegisterPage from "./pages/RegisterPage";
import RevisionsPage from "./pages/RevisionsPage";
import SettingsPage from "./pages/SettingsPage";
import StudyPlannerPage from "./pages/StudyPlannerPage";
import StudySessionsPage from "./pages/StudySessionsPage";
import SubjectsPage from "./pages/SubjectsPage";
import SyllabusTrackerPage from "./pages/SyllabusTrackerPage";
import TasksPage from "./pages/TasksPage";
import WeakTopicsPage from "./pages/WeakTopicsPage";

export default function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AuthProvider>
          <BrowserRouter>
            <ToastContainer />
            <Routes>
              {/* Public pages */}
              <Route path="/" element={<LandingPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />

              {/* Authenticated SaaS dashboard shell */}
              <Route element={<ProtectedRoute />}>
                <Route element={<DashboardLayout />}>
                  <Route path="/dashboard" element={<DashboardPage />} />
                  <Route path="/planner" element={<StudyPlannerPage />} />
                  <Route path="/tasks" element={<TasksPage />} />
                  <Route path="/subjects" element={<SubjectsPage />} />
                  <Route path="/syllabus" element={<SyllabusTrackerPage />} />
                  <Route path="/weak-topics" element={<WeakTopicsPage />} />
                  <Route path="/backlog" element={<BacklogRecoveryPage />} />
                  <Route path="/sessions" element={<StudySessionsPage />} />
                  <Route path="/revisions" element={<RevisionsPage />} />
                  <Route path="/exams" element={<ExamsPage />} />
                  <Route path="/analytics" element={<AnalyticsPage />} />
                  <Route path="/notes" element={<NotesPage />} />
                  <Route path="/goals" element={<GoalsPage />} />
                  <Route path="/recommendations" element={<RecommendationsPage />} />
                  <Route path="/settings" element={<SettingsPage />} />
                </Route>
              </Route>

              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </BrowserRouter>
        </AuthProvider>
      </ToastProvider>
    </ThemeProvider>
  );
}
