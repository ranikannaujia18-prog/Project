export default function StatCard({ label, value, subtext, icon: Icon, accent = "primary" }) {
  return (
    <div className="card" style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "0.75rem" }}>
      <div>
        <div style={{ fontSize: "0.8rem", color: "var(--text-muted)", fontWeight: 500 }}>{label}</div>
        <div style={{ fontSize: "1.65rem", fontWeight: 700, marginTop: "0.25rem", letterSpacing: "-0.02em" }}>
          {value}
        </div>
        {subtext && (
          <div style={{ fontSize: "0.78rem", color: "var(--text-secondary)", marginTop: "0.25rem" }}>
            {subtext}
          </div>
        )}
      </div>
      {Icon && (
        <div
          style={{
            width: 40,
            height: 40,
            borderRadius: 10,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: `var(--${accent}-soft)`,
            color: `var(--${accent})`,
            flexShrink: 0,
          }}
        >
          <Icon size={20} />
        </div>
      )}
    </div>
  );
}
