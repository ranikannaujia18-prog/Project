import { Loader2 } from "lucide-react";

export default function LoadingSpinner({ label = "Loading..." }) {
  return (
    <div className="spinner-wrap" role="status">
      <Loader2 size={20} className="spin" />
      <span>{label}</span>
    </div>
  );
}
