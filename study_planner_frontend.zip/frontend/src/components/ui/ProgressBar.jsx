export default function ProgressBar({ value = 0, color = "var(--primary)", showLabel = false }) {
  const clamped = Math.max(0, Math.min(100, Number(value) || 0));
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "0.6rem", width: "100%" }}>
      <div className="progress-track">
        <div className="progress-fill" style={{ width: `${clamped}%`, background: color }} />
      </div>
      {showLabel && (
        <span style={{ fontSize: "0.8rem", fontWeight: 600, minWidth: 38, textAlign: "right" }}>
          {Math.round(clamped)}%
        </span>
      )}
    </div>
  );
}
