export default function EmptyState({ icon: Icon, title, description, action }) {
  return (
    <div className="empty-state">
      {Icon && (
        <div style={{ marginBottom: "0.65rem", color: "var(--text-muted)" }}>
          <Icon size={34} />
        </div>
      )}
      <h4 style={{ fontSize: "1rem", color: "var(--text-primary)", marginBottom: "0.3rem" }}>
        {title}
      </h4>
      {description && (
        <p style={{ fontSize: "0.88rem", maxWidth: 420, margin: "0 auto 1rem" }}>
          {description}
        </p>
      )}
      {action}
    </div>
  );
}
