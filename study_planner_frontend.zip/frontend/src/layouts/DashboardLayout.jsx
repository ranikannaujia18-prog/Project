import { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  AlertTriangle,
  BarChart3,
  BookOpen,
  CalendarDays,
  CheckSquare,
  Clock,
  FileText,
  GraduationCap,
  History,
  LayoutDashboard,
  Lightbulb,
  ListChecks,
  LogOut,
  Menu,
  Moon,
  RefreshCw,
  Settings,
  Sun,
  Target,
  X,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";
import { useToast } from "../context/ToastContext";

const NAV_ITEMS = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/planner", label: "Study Planner", icon: CalendarDays },
  { to: "/tasks", label: "Tasks", icon: CheckSquare },
  { to: "/subjects", label: "Subjects", icon: BookOpen },
  { to: "/syllabus", label: "Syllabus Tracker", icon: ListChecks },
  { to: "/weak-topics", label: "Weak Topics", icon: AlertTriangle },
  { to: "/backlog", label: "Backlog Recovery", icon: History },
  { to: "/sessions", label: "Study Sessions", icon: Clock },
  { to: "/revisions", label: "Revision", icon: RefreshCw },
  { to: "/exams", label: "Exams", icon: GraduationCap },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/notes", label: "Notes", icon: FileText },
  { to: "/goals", label: "Goals", icon: Target },
  { to: "/recommendations", label: "Recommendations", icon: Lightbulb },
  { to: "/settings", label: "Settings", icon: Settings },
];

export default function DashboardLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { student, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { addToast } = useToast();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    addToast("Logged out successfully.", "success");
    navigate("/login");
  };

  const initials = (student?.name || "S")
    .split(" ")
    .map((p) => p[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <div className="app-shell">
      <div
        className={`sidebar-backdrop ${sidebarOpen ? "open" : ""}`}
        onClick={() => setSidebarOpen(false)}
      />

      <aside className={`sidebar ${sidebarOpen ? "open" : ""}`}>
        <div className="sidebar-brand">
          <span className="brand-mark">
            <span className="brand-icon">
              <GraduationCap size={18} />
            </span>
            StudyFlow
          </span>
          <button
            type="button"
            className="btn btn-ghost btn-sm mobile-menu-btn"
            onClick={() => setSidebarOpen(false)}
            aria-label="Close navigation"
          >
            <X size={18} />
          </button>
        </div>

        <nav className="sidebar-nav" aria-label="Main Navigation">
          {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}
              onClick={() => setSidebarOpen(false)}
            >
              <Icon size={17} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-footer">
          <button
            type="button"
            className="btn btn-ghost"
            style={{ width: "100%", justifyContent: "flex-start" }}
            onClick={handleLogout}
          >
            <LogOut size={17} />
            <span>Sign out</span>
          </button>
        </div>
      </aside>

      <div className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <button
              type="button"
              className="btn btn-ghost btn-sm mobile-menu-btn"
              onClick={() => setSidebarOpen(true)}
              aria-label="Open navigation"
            >
              <Menu size={20} />
            </button>
            <span style={{ fontSize: "0.9rem", color: "var(--text-secondary)", fontWeight: 500 }}>
              Study Planner & Task Tracker
            </span>
          </div>

          <div className="topbar-right">
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              onClick={toggleTheme}
              title="Toggle Light / Dark theme"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            <NavLink to="/settings" className="user-pill">
              <span className="user-avatar">{initials}</span>
              <span>{student?.name || "Student"}</span>
            </NavLink>
          </div>
        </header>

        <main className="page-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
