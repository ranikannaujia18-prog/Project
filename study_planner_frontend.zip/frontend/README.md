# StudyFlow — Study Planner & Task Tracker Frontend

Modern React + Vite productivity dashboard connected directly to your Flask REST API backend.

## Quick Start

1. **Make sure your Flask backend is running** on `http://127.0.0.1:5000`:
   ```bash
   python run.py
   ```
2. **Install frontend dependencies**:
   ```bash
   cd frontend
   cp .env.example .env
   npm install
   ```
3. **Start the Vite dev server** (opens at `http://localhost:5173`):
   ```bash
   npm run dev
   ```
4. **Demo Login** (if you ran `python -m backend.database.seed`):
   - Email: `aarav.sharma@college.edu`
   - Password: `StudyPass123!`
